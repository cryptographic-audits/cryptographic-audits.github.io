// CONDITIONAL_OUTPUT_CHECK_BEGIN
// Test-only differential experiment: the original verify_fold and verify_output
// are both used WITHOUT altering their checks.  The controlled challenges are
// applied *after* the original verify_fold returns; this is a conditional
// public-coin experiment, NOT a Fiat-Shamir attack with forced hash output.
// This test is limited to the derived-key build to avoid allocating a >3 GiB
// random commitment key when m=2^18.  The zero-witness commitment equals zero
// for every key, and the audit feature short-circuits precisely that identity.
#[cfg(feature = "derived-key")]
#[test]
fn test_output_challenge_separation() {
    use crate::commitment::CommitmentKey;
    use crate::config::{folded_norm_bound, witness_norm_bound};
    use crate::fold::fold_commitment;
    use crate::output::verify_output;

    init_common();
    let log_m = std::env::var("PIKKU_ATTACK_LOG_M")
        .ok()
        .and_then(|s| s.parse::<usize>().ok())
        .unwrap_or(10);
    assert!((10..=18).contains(&log_m), "test log_m=10 first, then log_m=18");
    let m = 1usize << log_m;
    let rank = commitment_rank(m);
    let zero = RingElement::zero(Representation::IncompleteNTT);
    let one = RingElement::constant(1, Representation::IncompleteNTT);
    let l = lambda();

    // Because the first public evaluation point is the Boolean zero point,
    // any input witness satisfying claim[0] must have witness[0] == Lambda.
    // q == 1 (mod 64), and Lambda's constant coefficient is inv(64) modulo q.
    // Its centered absolute value alone exceeds the *entire* input norm cap.
    assert_eq!(Q % 64, 1);
    let centered_const = (Q - 1) / 64;
    let mut coeff_l = l.clone();
    coeff_l.from_incomplete_ntt_to_even_odd_coefficients();
    assert_eq!(coeff_l.v[0], Q - centered_const);
    assert!((centered_const as f64) > witness_norm_bound(m));
    println!(
        "PASS input relation has NO short opening: |centered Lambda[0]|={} > input_bound={:.6}",
        centered_const, witness_norm_bound(m)
    );

    let mut claims = (0..FOLD_INPUTS)
        .map(|_| EvalClaim {
            point: vec![zero.clone(); log_m],
            value: zero.clone(),
        })
        .collect::<Vec<_>>();
    claims[0].value = l.clone();
    let instance = Instance {
        commitment: HorizontallyAlignedMatrix {
            data: vec![zero.clone(); rank * FOLD_INPUTS],
            width: FOLD_INPUTS,
            height: rank,
        },
        claims,
    };
    assert_eq!(instance.claims.len(), FOLD_INPUTS);
    assert_eq!(instance.commitment.height, rank);
    assert_eq!(instance.commitment.width, FOLD_INPUTS);

    // Extract the first public ternary matrix from the *same transcript seed*
    // that the adversarial prover and unchanged verifier will later use.
    let shape = projection_shape(m).expect("valid projection shape");
    let mut pre_transcript = statement_transcript(m, &instance);
    let matrices = sample_projection_matrices(&shape, &mut pre_transcript);
    let a = kernel_with_fixed_first(&matrices[0]);
    let mut pseudo = VerticallyAlignedMatrix {
        data: vec![zero.clone(); FOLD_INPUTS * m],
        width: FOLD_INPUTS,
        height: m,
        used_cols: FOLD_INPUTS,
    };
    for (j, &coefficient) in a.iter().enumerate() {
        let scalar = RingElement::constant(coefficient, Representation::IncompleteNTT);
        pseudo.data[j] *= (&l, &scalar);
    }
    assert_eq!(pseudo.col(0)[0], l);
    assert!(pseudo.col(1).iter().all(|x| x == &zero));
    assert!(pseudo.col(2).iter().all(|x| x == &zero));

    let proof = prove_adversarial_fold(m, &instance, &pseudo)
        .expect("adversarial prover must build its transcript");
    let expected_rounds = match log_m {
        10 => 28,
        18 => 40,
        _ => {
            let input_vars = (FRESH_INPUTS * m).ilog2() as usize;
            let middle_vars = input_vars - shape[0].ilog2() as usize;
            input_vars + middle_vars + PROJECTION_ROWS.ilog2() as usize
        }
    };
    assert_eq!(proof.round_polynomials.len(), expected_rounds);
    assert!(proof.round_polynomials.iter().any(|pair|
        pair.iter().any(|poly| poly.coeffs != [0, 0])
    ));

    // Unchanged original verifier, normal Fiat-Shamir final challenge.
    let real_output = verify_fold(m, &instance, &proof)
        .expect("original verify_fold must accept full adversarial RingSC");
    assert_eq!(real_output.folded_commitment.len(), rank);
    assert!(real_output.folded_commitment.iter().all(|x| x == &zero));
    assert_eq!(real_output.folded_claim.point.len(), log_m);
    assert_eq!(proof.terminal_values.len(), FOLD_INPUTS);
    assert_eq!(proof.terminal_values[1], zero);
    assert_eq!(proof.terminal_values[2], zero);
    let terminal0 = &proof.terminal_values[0];
    assert_ne!(terminal0, &zero, "unexpected zero terminal in this test instance");
    let mut projected_terminal = zero.clone();
    projected_terminal *= (&l, terminal0);
    assert_eq!(projected_terminal, *terminal0);

    // Retain the actual original public derived-key type, but never materialize
    // key rows: any linear commitment of an all-zero witness is zero.
    let key = CommitmentKey::sample(m, rank);
    let zero_output_witness = VerticallyAlignedMatrix {
        data: vec![zero.clone(); m],
        width: 1,
        height: m,
        used_cols: 1,
    };
    let cap = folded_norm_bound(m);

    // NORMAL SHAKE path: no challenge is replaced anywhere. For an ordinary
    // sample the claim is nonzero, so zero output must be rejected.
    let real_result = verify_output(
        &key,
        &zero_output_witness,
        &real_output.folded_commitment,
        &real_output.folded_claim,
        cap,
    );
    if real_output.folded_claim.value == zero {
        assert!(real_result.is_ok(), "a genuinely favorable FS challenge must accept zero output");
        println!("FS_ZERO_SLOT_EVENT_OBSERVED=true (rare genuine hash outcome)");
    } else {
        let message = real_result.expect_err("normal FS nonzero output must reject zero witness");
        assert!(message.contains("evaluation"), "unexpected normal-output rejection: {message}");
        println!("FS_ZERO_SLOT_EVENT_OBSERVED=false; normal SHAKE output correctly rejected zero witness");
    }

    let good = challenge_galois(1);
    let bad = challenge_galois(3);
    let mut g_l = zero.clone();
    g_l *= (&good, &l);
    assert_eq!(g_l, zero);
    let mut b_l = zero.clone();
    b_l *= (&bad, &l);
    assert_ne!(b_l, zero);

    // CONTROLLED CHALLENGE output (hypothetical): z0=good, z1=bad, z2=1.
    // Only the *post-verification output relation* is changed. Neither the
    // original proof nor verify_fold() is modified or re-executed with forced FS.
    let good_challenges = [good.clone(), bad.clone(), one.clone()];
    let good_commitment = fold_commitment(&instance.commitment, &good_challenges);
    let mut good_value = zero.clone();
    for (value, challenge) in proof.terminal_values.iter().zip(&good_challenges) {
        let mut product = zero.clone();
        product *= (value, challenge);
        good_value += &product;
    }
    assert_eq!(good_commitment.len(), rank);
    assert!(good_commitment.iter().all(|x| x == &zero));
    assert_eq!(good_value, zero);
    let good_claim = EvalClaim {
        point: real_output.folded_claim.point.clone(),
        value: good_value,
    };
    verify_output(&key, &zero_output_witness, &good_commitment, &good_claim, cap)
        .expect("correct zero witness must pass original verify_output for hypothetical good challenge");
    println!("CONDITIONAL_GOOD_CHALLENGE_OUTPUT_ACCEPTED=true");

    // NEGATIVE CONTROL: z0=bad is nonzero in the target CRT slot.
    let bad_challenges = [bad.clone(), good, one];
    let bad_commitment = fold_commitment(&instance.commitment, &bad_challenges);
    let mut bad_value = zero.clone();
    for (value, challenge) in proof.terminal_values.iter().zip(&bad_challenges) {
        let mut product = zero.clone();
        product *= (value, challenge);
        bad_value += &product;
    }
    assert_ne!(bad_value, zero);
    let bad_claim = EvalClaim {
        point: real_output.folded_claim.point,
        value: bad_value,
    };
    let bad_error = verify_output(&key, &zero_output_witness, &bad_commitment, &bad_claim, cap)
        .expect_err("bad challenge must not admit zero output witness");
    assert!(bad_error.contains("evaluation"), "unexpected negative control: {bad_error}");
    println!("CONDITIONAL_BAD_CHALLENGE_OUTPUT_REJECTED=true");
    println!(
        "PASS: original verify_fold {} rounds, full rank {}, original verify_output challenge separation",
        expected_rounds, rank
    );
    println!("SCOPE: one conditional post-folding experiment; no forced SHAKE or practical FS forgery");
}
// CONDITIONAL_OUTPUT_CHECK_END
