# PikkuFold 输出挑战对照：原版输出关系的正常挑战／受控挑战差分实验

## 已知基础

用户在 i9-13980HX、WSL2 Ubuntu、Rust nightly 下，运行原版 `verify_fold()` 对折叠证明复现非零恶意证明的 40 轮测试，`m=2^18`、rank 12 已通过，耗时约 1.98 s；本包是其后的下一项实验。

## 目标和不可混淆的边界

1. 让**真实原版 `verify_fold()`** 在**正常 SHAKE/Fiat–Shamir 挑战**下接受同一个恶意 proof，并取得真实 `VerifierMessage`。
2. 用**真实原版 `verify_output()`** 和长度正确的 rank-12 零承诺检查零见证：**正常挑战**若对应非零输出求值，应拒绝（极小概率碰巧零槽时则接受并报告）。
3. **在后验条件性实验中**，将最终 folding challenge 第一项设为零槽证书有理数范数证书核实的 `z_good`，用原版 `fold_commitment()` 和已验证 proof 的 `terminal_values` 构造输出关系，再交给未修改的 `verify_output()`，应接受零见证。
4. 非零槽 `z_bad` 负对照，应被同一个 `verify_output()` 拒绝。
5. 对错误输入的**短见证不存在**作代码中的直接、严格、无公钥假设证明：公开求值点为全 0，意味着首个见证坐标等于 `Lambda`；其常数项的最小绝对代表已经是 `(q-1)/64 = 17,592,186,044,374`，高于原 `witness_norm_bound(2^18)`。

**注意：**步骤 3 是“如若最终折叠挑战为 `z_good`”的条件性输出关系实验，不是改变原版 `verify_fold()` 来让随机预言机输出预选挑战；因此即使通过，不代表生成实际非交互哈希伪造。它证明原输出关系的条件性可满足性。全零输出见证对**任何**公钥的承诺均为零。

## 为什么需要 `derived-key`

在 `m=2^18` 时，默认 `CommitmentKey::sample(m,rank)` 需要分配约 3 GiB 的 `RingElement` 采样公钥（实际内存视结构体而定）。原项目已有 `derived-key` 编译特性，使公钥按块推导且不存储整个矩阵。

本包仅在**同时**启用 `derived-key` 与 `scalar-commit-audit` 时，为该特性 `commit_column()` 增加数学恒等式：对于零列输入直接返回长度为 rank 的零向量。这一优化与任何 CRS 值无关，不修改输出的数学结果、不调用 AVX-512；非零输入保留原函数。

此优化不构成对全部底层承诺实现的独立等价性验证。输出关系中的折叠承诺维度与 MLE 由原版 `verify_output` 检查；测试不调用原 `prove_fold`。

## 安装

将压缩包解压到 `~/pikkufold-lab/output_challenge`，之后：

```bash
cd ~/pikkufold-lab/original/pikku-main/pikku-fold-schemelet
python3 ~/pikkufold-lab/output-challenge-check/install_output_challenge_test.py \
  --append ~/pikkufold-lab/output-challenge-check/output_challenge_test_append.rs
```

安装器只修改 `src/adversarial_attack_tests.rs`、`src/commitment.rs`，备份并可重复执行。它不触碰 `src/verifier.rs`、`src/output.rs`、`src/fold.rs`、`src/projection.rs`、`src/sumcheck.rs`、`src/transcript.rs`。

## 运行

```bash
cd ~/pikkufold-lab/original/pikku-main/pikku-fold-schemelet
export CARGO_NET_GIT_FETCH_WITH_CLI=true
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export RUSTFLAGS='-C target-cpu=x86-64-v3'
set -o pipefail

cargo +nightly test --locked \
  --features scalar-commit-audit,derived-key --no-run \
  2>&1 | tee ~/pikkufold-lab/output_challenge_compile.log

PIKKU_ATTACK_LOG_M=10 cargo +nightly test --locked \
  --features scalar-commit-audit,derived-key \
  adversarial_attack_tests::test_output_challenge_separation \
  -- --exact --nocapture --test-threads=1 \
  2>&1 | tee ~/pikkufold-lab/output_challenge_small.log

PIKKU_ATTACK_LOG_M=18 cargo +nightly test --locked \
  --features scalar-commit-audit,derived-key \
  adversarial_attack_tests::test_output_challenge_separation \
  -- --exact --nocapture --test-threads=1 \
  2>&1 | tee ~/pikkufold-lab/output_challenge_40round.log
```

先编译，成功后小规模，再大规模。观察 `FS_ZERO_SLOT_EVENT_OBSERVED`、`CONDITIONAL_GOOD_CHALLENGE_OUTPUT_ACCEPTED`、`CONDITIONAL_BAD_CHALLENGE_OUTPUT_REJECTED`。

## 预期状态（未经本地 Rust 实测）

- `verify_fold` 通过全部 sumcheck；
- 典型正常 FS fold 输出非零，零见证被 `verify_output` 正确拒绝；
- 控制良挑战产生零输出，`verify_output` 接受；
- 负对照挑战产生非零输出，`verify_output` 拒绝。

若 `SIGILL` 再出现，使用 GDB 定位后不要直接修改验证规则。本包已在 Python 静态层验证安装器幂等性，但没有在 WSL2 上执行 Cargo 编译或测试。 
