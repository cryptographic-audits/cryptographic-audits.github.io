# PikkuFold verifier reproduction

This module is organized by function:

- `folding-proof-reproduction/`: constructs and verifies the nonzero folding transcript;
- `output-challenge-check/`: compares normal and selected output challenges;
- `conditional-verifier-replay/`: replays supported favorable and unfavorable public coins through the verifier;
- `portable/`: portable arithmetic and verifier helpers.

Start with `install_from_clean.sh`.
