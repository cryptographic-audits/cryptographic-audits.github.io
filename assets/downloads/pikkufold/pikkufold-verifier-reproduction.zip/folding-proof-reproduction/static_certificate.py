#!/usr/bin/env python3
"""Source-scope and exact integer arithmetic checks for the Folding-proof reproduction Rust integration.

This is NOT a Cargo compilation or a proof that the verifier accepts the generated
transcript. Those claims require the user's WSL2 Rust run.
"""
from pathlib import Path
from fractions import Fraction
from math import comb
from hashlib import sha256
import json, sys
root=Path(__file__).resolve().parent
srcs=['install_folding_proof_test.py','adversarial_attack_tests.rs']
for name in srcs:
    assert (root/name).is_file()
q=(1<<50)-2687
beta=739582794740178
assert pow(beta,64,q)==q-1 and pow(beta,128,q)==1
pos=[1,4,5,6,9,13,16,21,22,23,24,25,33,34,35,37,41,42,48,55,58,60,62]
sign=[1,-1,-1,-1,1,1,1,-1,1,-1,1,1,1,-1,-1,1,1,1,-1,-1,-1,1,1]
assert len(pos)==len(sign)==23 and len(set(pos))==23
value=sum(s*pow(beta,i,q) for i,s in zip(pos,sign))%q
value3=sum(s*pow(beta,(3*i)%128,q) for i,s in zip(pos,sign))%q
assert value==0 and value3!=0
# Norm upper bound comes from the independently uploaded and certified
# Zero-slot certificate orbit certificate, with SCALE=2^24.
upper_sq=18549628827680036
assert upper_sq*1000*1000 < 8357*8357*(1<<48)
# Zero-slot certificate counting and degree-sensitive loss comparison.
base=2**23*comb(128,23)
favourable=4337664
lower=Fraction(favourable,base)
assert lower>Fraction(64,q*q)
ratio=Fraction(favourable*q*q,276*base)
assert ratio>100
# For M=2^25..29, the stated norm lower bound for a single-CRT-slot
# idempotent is larger than the extracted fresh cap.
for expM in (25,27,29):
    M=1<<expM
    beta_in_squared=Fraction(2*M*1024**2)*Fraction(3432,10)**3/Fraction(2737,100)**3
    assert beta_in_squared < (1<<62)
    assert q**63 > (1<<48)**64
out={'scope':'Exact integer/static source checks; Rust test not executed here',
     'q':q,'beta':beta,'zero_slot_value':value,'negative_control_slot_value':value3,
     'certified_example_upper_norm_lt_8_357':True,
     'previously_certified_zero_slot_challenges':favourable,
     'probability_lower_exact':str(lower),
     'zero_slot_attack_lower_over_main_nominal_without_kappa_proj':str(ratio),
     'source_sha256':{name:sha256((root/name).read_bytes()).hexdigest() for name in srcs}}
(root/'static_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
