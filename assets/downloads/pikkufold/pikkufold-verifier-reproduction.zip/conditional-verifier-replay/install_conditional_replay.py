#!/usr/bin/env python3
"""Install opt-in test-only conditional public-coin folding replay on Output-challenge check PikkuFold.

This patches ONLY:
  Cargo.toml                      (new OFF-BY-DEFAULT feature)
  src/fold.rs                     (test+feature-only scoped folding-challenge hook)
  src/adversarial_attack_tests.rs (new regression test)

The original verifier/output/sumcheck/transcript source files are never edited.
The hook runs only for the current test thread while an explicit guard exists;
otherwise fold_challenges() follows the original SHAKE sampler path.
"""
import argparse
import hashlib
import shutil
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--append", type=Path, required=True,
                    help="path to conditional_replay_test_append.rs from package")
args = parser.parse_args()
root = Path.cwd()
cargo = root / "Cargo.toml"
fold = root / "src/fold.rs"
tests = root / "src/adversarial_attack_tests.rs"
critical = [root / "src" / s for s in
            ("verifier.rs", "output.rs", "sumcheck.rs", "transcript.rs", "projection.rs")]
if not all(path.exists() for path in (cargo, fold, tests, *critical)):
    parser.error("run from original pikku-fold-schemelet with Output-challenge check installed")

addition = args.append.read_text(encoding="utf-8")
start_marker = "// CONDITIONAL_VERIFIER_REPLAY_BEGIN"
end_marker = "// CONDITIONAL_VERIFIER_REPLAY_END"
if not addition.startswith(start_marker) or not addition.rstrip().endswith(end_marker):
    parser.error("Conditional verifier replay test module has unexpected markers")

old_cargo = cargo.read_text(encoding="utf-8")
for required in ("scalar-commit-audit = []", "derived-key = []"):
    if required not in old_cargo:
        parser.error(f"prior audit feature is missing: {required}")
feature = 'conditional-fold-audit = ["scalar-commit-audit", "derived-key"]'
if "conditional-fold-audit" not in old_cargo:
    if "[features]\n" not in old_cargo:
        parser.error("missing Cargo.toml features section")
    new_cargo = old_cargo.replace("[features]\n", "[features]\n" + feature + "\n", 1)
elif old_cargo.count(feature) == 1:
    new_cargo = old_cargo
else:
    parser.error("existing conditional-fold-audit differs; refuse to overwrite")

old_fold = fold.read_text(encoding="utf-8")
fold_marker = "// TEST_ONLY_FOLD_CHALLENGE_HOOK_BEGIN"
fold_insert = '''// TEST_ONLY_FOLD_CHALLENGE_HOOK_BEGIN
// An explicitly scoped public-coin unit-test hook, never compiled in production.
// It ONLY changes how the last folding challenges are sampled, not any check.
#[cfg(all(test, feature = "conditional-fold-audit"))]
thread_local! {
    static TEST_ONLY_FOLD_CHALLENGES: std::cell::RefCell<Option<Vec<RingElement>>> =
        std::cell::RefCell::new(None);
}

#[cfg(all(test, feature = "conditional-fold-audit"))]
pub(crate) struct AuditFoldChallengeGuard;

#[cfg(all(test, feature = "conditional-fold-audit"))]
impl Drop for AuditFoldChallengeGuard {
    fn drop(&mut self) {
        TEST_ONLY_FOLD_CHALLENGES.with(|slot| {
            slot.borrow_mut().take();
        });
    }
}

#[cfg(all(test, feature = "conditional-fold-audit"))]
pub(crate) fn audit_force_fold_challenges(challenges: Vec<RingElement>) -> AuditFoldChallengeGuard {
    assert_eq!(challenges.len(), FOLD_INPUTS);
    assert_eq!(challenges[ACCUMULATOR_COL],
        RingElement::constant(1, Representation::IncompleteNTT));
    TEST_ONLY_FOLD_CHALLENGES.with(|slot| {
        let mut current = slot.borrow_mut();
        assert!(current.is_none(), "nested conditional challenges forbidden");
        *current = Some(challenges);
    });
    AuditFoldChallengeGuard
}
// TEST_ONLY_FOLD_CHALLENGE_HOOK_END
'''
fn_anchor = 'pub(crate) fn fold_challenges(transcript: &mut HashWrapper) -> Vec<RingElement> {\n'
branch = '''    // TEST_ONLY_FINAL_CHALLENGE_BRANCH_BEGIN
    #[cfg(all(test, feature = "conditional-fold-audit"))]
    if let Some(forced) = TEST_ONLY_FOLD_CHALLENGES.with(|slot| slot.borrow().clone()) {
        return forced;
    }
    // TEST_ONLY_FINAL_CHALLENGE_BRANCH_END
'''
if fold_marker not in old_fold:
    if old_fold.count(fn_anchor) != 1:
        parser.error("fold.rs anchor unexpected; refuse patch")
    new_fold = old_fold.replace(fn_anchor, fold_insert + "\n" + fn_anchor + branch, 1)
else:
    if old_fold.count(fold_marker) != 1 or old_fold.count(branch) != 1 or fold_insert not in old_fold:
        parser.error("Conditional verifier replay fold.rs hook exists but differs; refuse overwrite")
    new_fold = old_fold

old_tests = tests.read_text(encoding="utf-8")
if 'fn test_output_challenge_separation()' not in old_tests:
    parser.error("Output-challenge check test is not installed; refuse patch")
if start_marker not in old_tests:
    new_tests = old_tests.rstrip() + "\n\n" + addition
elif old_tests.count(start_marker) == 1 and addition.rstrip() in old_tests:
    new_tests = old_tests
else:
    parser.error("existing Conditional verifier replay test differs; refuse overwrite")

before_hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in critical}
planned = [(cargo, new_cargo), (fold, new_fold), (tests, new_tests)]
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
for path, content in planned:
    old = path.read_text(encoding="utf-8")
    if old == content:
        print("Unchanged", path.relative_to(root))
    else:
        backup = path.with_name(path.name + ".before_conditional_replay_" + stamp)
        shutil.copy2(path, backup)
        path.write_text(content, encoding="utf-8")
        print("Patched", path.relative_to(root), "backup:", backup.name)
for path in critical:
    relative = str(path.relative_to(root))
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before_hashes[relative], relative
print("Original verifier/output/sumcheck/transcript/projection hashes unchanged")
print("Tests: --features scalar-commit-audit,derived-key,conditional-fold-audit")
print("Filter: adversarial_attack_tests::test_conditional_original_verifier_replay")
