# PikkuFold verifier-path replay module

This module contains the portable helpers and the Round 10–12 test sources for reproducing the adversarial RingSC transcript and the favorable/unfavorable final-challenge branches.

Installation starts from `INSTALL_FROM_CLEAN.sh`. The source-code comments are in English. The important boundaries are:

- Round 10 builds the nonzero 40-round adversarial sumcheck transcript and calls the original `verify_fold()` checks.
- Round 11 compares the normal SHAKE output with supported favorable and unfavorable challenges.
- Round 12 injects the final public coin only under the guarded `conditional-fold-audit` test feature and sends the resulting statement through `verify_output()`.

Use `round12/verify_round12_static.py` for the independent challenge check before compiling Rust. `OBSERVED_WSL_RESULTS.md` records the author-reported Ubuntu/WSL2 results.
