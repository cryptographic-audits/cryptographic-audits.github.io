# PikkuFold Zero-slot certificate: adaptive-zero-projection attack

Target: original Figure 2 with the actual Table 6 challenge sampler, three-layer JL shape, and all three Table 6 input coefficient dimensions/norm budgets. This **does not attack** the author's later modified two-track or exact-strong protocol.

## What is certified

- `verify_many_orbits.py candidates_0_511.txt`: independent integer/interval member certificate for 4,337,664 distinct accepted challenge polynomials with one CRT slot zero. Needs Python, NumPy.
- `first_layer_kernel.cpp`: compile with C++17. Produces a concrete random biased-ternary 256 x 257 matrix and a vector `a` with `a[0]=1`, `J*a=0 mod q`. This finite example does not estimate a probability.
- `verify_zero_slot_parameters.py`: verifies the first-layer certificate, CRT idempotent evaluations, *all three* Table 6 input-norm bounds, the exact binomial rank-tail inequality, and correct nominal knowledge-error arithmetic. Standard Python only.
- `attack_algebra_demo.py`: exact quadratic-field MLE terminal calculations at 12 independent field points; both zero-slot success and non-zero-slot negative controls. Standard Python only.

## Run

```bash
bash verify_all.sh
```

The audit argument proving an accepted *full 40-round RingSC* for the fake opening uses **perfect completeness of the original sumcheck protocol** for its true internal polynomial claims. This package has **not** implemented a full 40-round original Rust proof generator, proof encoding, SHAKE/Fiat-Shamir grinding or a native verifier execution. A genuine ROM single-shot probability event should not be presented as an easy online exploit.

The published probability comparison depends on inserting Heuristic 1's *nominal* `epsilon_C ≈ 64/q²` and its unproved `|C|≥q²` prerequisite. The **abstract theorem with the true (larger) epsilon_C is not refuted** by this particular event. The fixed-key input relation impossibility is unconditional on the commitment key, as long as the canonical coefficient norm bound is that of Table 6.
