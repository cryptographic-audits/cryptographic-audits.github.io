# PikkuFold 50-bit 参数：Gist 证明与完整复现代码

本包是与 GitHub Issue 配套的独立材料。建议把根目录 `PIKKUFOLD_ZERO_SLOT_NOTE.md` 的内容直接粘贴到 GitHub Gist；ZIP 用来保存全部脚本、计算证书和测试集成代码。**不需要为了发布 Gist 再运行一次耗时的 SHAKE 暴力碰撞。**

## 结论及证据边界

- 已认证：实际 `q = 2^50-2687`、权重 23、范数阈值 8.357 下，至少 **4,337,664** 个不同的合法挑战在同一二次 CRT 槽为零。因此零槽概率至少 `2^-84.4637244`；Definition 11 的 `epsilon_C` 也有对应下界。
- 已由用户本机实测：原版 `verify_fold()` 接受 `m=2^18,n=12` 的 40 轮恶意 RingSC；测试特性指定有利末轮挑战后，原验证规则与 `verify_output()` 一起接受零输出见证；不利挑战拒绝。
- 仍未证实：在没有最后一轮测试钩子的正常 SHAKE 流程里直接产生一份可接受的零输出伪造；亦未证实采用**真实** `epsilon_C` 的抽象 Theorem 1 错误。
- `PIKKUFOLD_ZERO_SLOT_NOTE.md` 提供了 CRT 分解、离散挑战计数、无短输入证明、自适应零投影、sumcheck 完备性、成功概率和与论文主张的关系。

## 文件结构

- `PIKKUFOLD_ZERO_SLOT_NOTE.md`：可直接粘贴到 Gist 的英文证明和实验说明。
- `exploratory-certificate/`：实际 50-bit 模数的候选搜索、第一代攻击与排名证书，包含完整原始数据。
- `zero-slot-certificate/`：完整的精确计数、范数有理区间证书、JL 核证书、代数正负对照，以及统一验证入口 `verify_all.sh`。
- `folding-proof-reproduction/`：针对原版 `verify_fold` 的恶意 40 轮 RingSC prover 与安装器（原始交付版本）。
- `output-challenge-check/`：`verify_output` 的条件性正负对照代码。
- `conditional-verifier-replay/`：最终挑战受控重放，验证器原样返回输出关系，带完整支持集检查和钩子恢复断言。
- `portable/`：无 AVX-512 CPU 所需的标量承诺及 MLE 测试补丁，还有形状/输出边界回归测试。
- `upstream/pikku-main(1).zip`：用户原先提供的 PikkuFold 上游快照，仅用于复现和差异核查；上游代码著作权归原作者，发布时请保留来源说明。
- `historical/`：前期其他审计代码（索引、JL、sampler、ROM 和范数界交叉检查），非本攻击的必需部分。
- `install_from_clean.sh`：对未安装过测试补丁的原版 `pikku-fold-schemelet` 按顺序装入可移植后端和第十至十二轮模块。
- `verify_certificates.sh`：不需 Rust 的证书与挑战检查。
- `UBUNTU_WSL_RESULTS.md`：从用户终端回报整理的测试输出（不是在本机重新执行的 Rust 日志）。
- `CHECKSUMS.sha256`：包内除校验文件自身以外的全部文件校验和。

## 只复核数学证书（无需 Rust）

需要 Python 3、NumPy，以及 C++17 编译器。在包根目录：

```bash
bash verify_certificates.sh
```

其中 `zero-slot-certificate/verify_all.sh` 会编译一个小型 C++ 样本核程序，再复核 130,629 个离散候选、17,317 个范数接受者、16,944 个不同轨道、4,337,664 个零槽挑战、256 行核、CRT 与概率算式。`conditional-verifier-replay/verify_challenge_fixtures.py` 会检查范数约为 8.118 的好坏挑战。

## 从上游快照安装 Rust 验证测试

使用已准备好 Rust nightly 的 Ubuntu/WSL2。先解压快照（或将脚本指向已有的**未修改原版**目录）：

```bash
unzip -q 'upstream/pikku-main(1).zip' -d /tmp/pikku-gist-upstream
bash install_from_clean.sh /tmp/pikku-gist-upstream/pikku-main/pikku-fold-schemelet
cd /tmp/pikku-gist-upstream/pikku-main/pikku-fold-schemelet

export CARGO_NET_GIT_FETCH_WITH_CLI=true
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export RUSTFLAGS='-C target-cpu=x86-64-v3'

cargo +nightly test --locked --features conditional-fold-audit --no-run
PIKKU_ATTACK_LOG_M=18 cargo +nightly test --locked \
  --features conditional-fold-audit \
  adversarial_attack_tests::test_conditional_original_verifier_replay \
  -- --exact --nocapture --test-threads=1
```

运行前可配置 `git config --global --add url."https://github.com/".insteadOf 'git@github.com:'`，因为 Rokoko 依赖项的 HEXL 子模块可能使用 GitHub SSH 地址。本包不提供 Git 依赖的离线镜像；上游 Rust 源码依赖 `lattice-arguments/rokoko` 固定提交 `64a9cd49d7d5281b0e174556662ec283e2eb8b3d`。

注意，折叠证明复现原始安装器生成的 `src/adversarial_attack.rs` 少一个 `FRESH_INPUTS` 导入。`install_from_clean.sh` 会自动修正这一点（修复是用户本机已验证过的单行改动）。不要再改动原始 `verifier.rs`、`sumcheck.rs`、`output.rs` 或 transcript 等式。

**安装器未在本交付容器编译 Rust。** 先前的 Cargo 编译、40 轮 `verify_fold()` 和条件性 `verify_output()` 通过记录来自用户的 WSL2 运行结果；本交付在当前容器独立复验了 Zero-slot certificate 计数与静态挑战检查。

## 公开提交建议

先发布 `PIKKUFOLD_ZERO_SLOT_NOTE.md`。如作者需要源码或要第三方复核，提供此 ZIP 或将脚本移入独立复现仓库。发布时应明确区分“受控 public-coin 验证器重放”和“真实 SHAKE 下的哈希伪造”，避免不准确的安全结论。
