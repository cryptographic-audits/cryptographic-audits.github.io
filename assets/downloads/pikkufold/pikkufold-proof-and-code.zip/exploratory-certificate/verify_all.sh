#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python verify_many_orbits.py candidates_0_511.txt > /tmp/pikkufold_exploratory_verify_orbits.log
python - <<'PY'
import json
x=json.load(open('more_orbits_results.json'))
assert x['source_candidates']==130629
assert x['accepted_8357']==17317
assert x['unclassified']==0
assert x['canonical_even_Y_orbits_8357']==16944
assert x['distinct_signed_full_X_rotations_8357']==4337664
assert x['distinct_signed_full_X_rotations_8200']==3093760
print('CERTIFIED CHALLENGE SET: PASS')
PY
python certify_rank12_large_instance.py >/tmp/pikkufold_exploratory_rank12.log
python attack_actual_full_transcript.py --trials 2 --output algebra_two_trials.json >/tmp/pikkufold_exploratory_algebra.log
python - <<'PY'
import json
x=json.load(open('rank12_d3_exact_ledger.json'))
a=json.load(open('algebra_two_trials.json'))
assert x['attack_exceeds_nominal_main'] and x['attack_exceeds_nominal_appendix']
assert x['ratio_attack_to_main_lower_display']>172
assert all(y['all_sumcheck_round_consistency'] for y in a['trials'])
print('RANK12 ARITHMETIC + SMALL DIM ALGEBRA TRANSCRIPT: PASS')
PY
sha256sum -c CHECKSUMS.sha256
