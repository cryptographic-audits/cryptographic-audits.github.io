#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
( cd "$ROOT/zero_slot" && bash verify_all.sh )
python3 "$ROOT/conditional-verifier-replay/verify_challenge_fixtures.py"
echo 'PASS: finite challenge set, CRT, sampled JL kernel, algebra controls and challenge support checked'
