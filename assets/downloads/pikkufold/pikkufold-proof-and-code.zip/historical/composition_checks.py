"""Offline arithmetic checks of composition preconditions; no protocol prover.

Uses Python's standard library only. Exact integer/Fraction outputs are the
certificates; decimal/log outputs are presentation aids.
"""

from fractions import Fraction
from math import isqrt, log2, log, sqrt
from pathlib import Path
import json


def fraction_record(value):
    return {"numerator": value.numerator, "denominator": value.denominator,
            "decimal": float(value)}


def balanced(value, modulus):
    return (value + modulus // 2) % modulus - modulus // 2


def sum_two_squares_prime(q):
    # The final integer identity, rather than this search, is the certificate.
    z = next(z for z in range(2, 1000) if pow(z, (q - 1) // 2, q) == q - 1)
    root = pow(z, (q - 1) // 4, q)
    assert root * root % q == q - 1
    for start in (root, q - root):
        old, rem = q, start
        while rem * rem > q:
            old, rem = rem, old % rem
        other = isqrt(q - rem * rem)
        if rem * rem + other * other == q:
            return sorted((rem, other))
    raise AssertionError("Cornacchia search failed")


def main():
    q = 2**50 - 2687
    phi = 128
    B = 1024
    a, b = sum_two_squares_prime(q)
    assert a*a + b*b == q
    values = range(-B, B + 1)
    mean = Fraction(sum(x*x for x in values), 2*B + 1)
    variance = sum((Fraction(x*x) - mean)**2 for x in values) / (2*B + 1)
    fourth_centered = sum((Fraction(x*x) - mean)**4 for x in values) / (2*B + 1)
    projection_ratio_squared = Fraction(B*B) / mean
    assert projection_ratio_squared > Fraction(173, 100)**2
    jl_tightness = (343.2 / 27.37)**1.5
    gamma = 8.357
    h32_over_rms = sqrt(32 * 2 * 23)
    prior_back_over_rms = 31 * 2 * gamma * sqrt(2) * jl_tightness
    fresh_ratio = sqrt(float(projection_ratio_squared))
    rows = []
    for power in (25, 27, 29):
        M = 2**power
        coeff_squared = M * B*B
        canonical_squared = phi * coeff_squared
        necessary_q_strict_lower = 4 * canonical_squared
        mean_squared = M * mean
        centered_sum_second = M * variance
        centered_sum_fourth = M * fourth_centered + 3*M*(M-1)*variance**2
        # For centered Z, Cauchy + moment interpolation gives
        # Pr[Z>0] >= E[Z^2]^2 / (4 E[Z^4]). No limit theorem is used.
        elementary_lower = centered_sum_second**2 / (4*centered_sum_fourth)
        assert elementary_lower > Fraction(1, 12)
        # Illustrative sufficient Bernstein correction, failure at most 2^-100.
        x = 100 * log(2)
        excess = sqrt(2*M*float(variance)*x) + (2/3)*(B*B-float(mean))*x
        N = M // phi
        basic_air_budget = Fraction(N + int(log2(N)), q*q)
        rows.append({
            "log2_M": power, "M": M, "ring_height": N,
            "fresh_coefficient_norm_squared_max": coeff_squared,
            "fresh_canonical_norm_squared_max": canonical_squared,
            "direct_cited_setting_requires_q_strictly_above": necessary_q_strict_lower,
            "log2_required_strict_lower": int(log2(necessary_q_strict_lower)),
            "current_modulus_violation_ratio": fraction_record(Fraction(necessary_q_strict_lower, q)),
            "canonical_balanced_trace_of_all_B_witness": balanced(canonical_squared, q),
            "rms_coefficient_cap_squared": fraction_record(mean_squared),
            "rms_exceeds_cap_probability_elementary_lower": fraction_record(elementary_lower),
            "fresh_100bit_tail_norm_cap_over_rms_display": sqrt(1 + excess/float(mean_squared)),
            "SALSAA_basic_AIR_lemma_error_budget": fraction_record(basic_air_budget),
            "SALSAA_basic_AIR_budget_bits_display": -log2(float(basic_air_budget)),
        })
    result = {
        "purpose": "Pure mathematical precondition and moment checks, not a cheating prover or protocol attack",
        "q": q, "phi": phi, "coefficient_bound": B,
        "sum_two_squares_identity": {"a": a, "b": b, "sum": a*a+b*b,
                                     "canonical_squared": phi*q,
                                     "balanced_trace": balanced(phi*q, q)},
        "one_coefficient_moments": {"mean_square": fraction_record(mean),
                                    "variance_square": fraction_record(variance),
                                    "fourth_centered_square": fraction_record(fourth_centered)},
        "actual_projection_cap_over_estimator_projection_cap": {
            "squared_exact": fraction_record(projection_ratio_squared),
            "ratio_display": fresh_ratio,
            "JL_tightness_display": jl_tightness,
            "32_round_backward_bound_ratio_even_omitting_actual_final_cap_display":
                fresh_ratio * prior_back_over_rms / (h32_over_rms + prior_back_over_rms),
            "warning": "Norm-budget discrepancy only; no lattice-estimator run or concrete security conclusion.",
        },
        "rows": rows,
    }
    dest = Path(__file__).resolve().parents[1] / "results" / "composition_checks.json"
    dest.parent.mkdir(exist_ok=True)
    dest.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
