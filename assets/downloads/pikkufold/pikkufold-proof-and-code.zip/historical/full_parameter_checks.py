"""Exact parameter check parameter and one-fold classical-ROM loss ledger.

This script runs no downloaded prover or sampler.  All decisive comparisons use
integers/Fraction.  Decimal strings are rounded UP for presentation.  The JL
probability and sampler cardinality/anti-concentration bounds are previously
certified mathematical inputs, explicitly identified in the output; this is a
composition certificate, not a new proof of those inputs or an SIS estimator.

Run from any directory: python historical/full_parameter_checks.py
"""
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction as F
from hashlib import sha256
from math import gcd, isqrt, prod
from pathlib import Path
import json
import re


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "full_parameter_checks.json"
SOURCE = ROOT / "work/downloaded_code/pikku-main/pikku-fold-schemelet/src"
PHI = 128  # Paper p.41, implementation ring of conductor 256.
ALPHA, BETA = F(2737, 100), F(1716, 5)
B_PAPER, B_CONSERVATIVE = 126, 129
JL_LAMBDA, A = 128, 2
Q_E, Q_B = (1 << 50) - 27, (1 << 50) - 2687
N_E = 10593090179186648695925874708572
CBD_B = F(13817713544858977,
          142831362764636918203799633204087166078125000)


def upper_decimal(x, digits=16):
    """A positive decimal upper bound, not a floating-point certificate."""
    x = F(x)
    with localcontext() as ctx:
        ctx.prec = digits
        ctx.rounding = ROUND_CEILING
        return str(Decimal(x.numerator) / Decimal(x.denominator))


def exact(x):
    x = F(x)
    return {"fraction": str(x), "decimal_upper": upper_decimal(x)}


def sqrt_bounds(x, places=35):
    x = F(x)
    scale = 10 ** places
    lower = isqrt(x.numerator * scale * scale // x.denominator)
    lo, hi = F(lower, scale), F(lower + 1, scale)
    assert lo * lo <= x < hi * hi
    return lo, hi


def sqrt_record(x):
    lo, hi = sqrt_bounds(x)
    return {"squared_exact": str(F(x)), "lower": str(lo), "upper": str(hi),
            "decimal_upper": upper_decimal(hi)}


def trial_prime(p):
    return p >= 2 and all(p % d for d in range(2, isqrt(p) + 1))


def lucas_certificate(q, factors, witness):
    """Full q-1 Lucas criterion; all factor primalities are trial-divided."""
    assert prod(p ** power for p, power in factors.items()) == q - 1
    assert all(trial_prime(p) for p in factors)
    assert pow(witness, q - 1, q) == 1
    checks = {str(p): gcd(pow(witness, (q - 1) // p, q) - 1, q)
              for p in factors}
    assert all(v == 1 for v in checks.values())
    order = next(j for j in range(1, 129) if pow(q, j, 256) == 1)
    assert order % A == 0
    return {"q": q, "q_mod_256": q % 256, "q_mod_8": q % 8,
            "q_minus_1_factors": factors, "Lucas_witness": witness,
            "Lucas_gcd_checks": checks, "slot_degree_e": order,
            "CRT_slot_count": PHI // order,
            "subfield_a": A, "a_divides_e": True,
            "coordinates_over_Fq_a": PHI // A,
            "coordinates_per_CRT_slot_over_Fq_a": order // A,
            "trace_dual_basis_available_gcd_q_phi": gcd(q, PHI)}


def read_code_parameters():
    config = (SOURCE / "config.rs").read_text(encoding="utf-8")
    def constant(name):
        found = re.search(r"const " + name + r": usize = (\d+);", config)
        assert found, name
        return int(found.group(1))
    k, depth, mu = (constant(x) for x in
                    ("FRESH_INPUTS", "PROJECTION_LAYERS", "PROJECTION_BATCH_POINTS"))
    assert (k, depth, mu) == (2, 3, 2)
    assert "PROJECTION_ROWS: usize = 2 * DEGREE;" in config
    assert "WITNESS_COEFF_BOUND: u64 = 1 << 10;" in config
    assert "JL_UPPER_TAIL_BETA: f64 = 343.2;" in config
    # These are mathematical formula checks, not a platform f64 certificate.
    assert "((m * DEGREE) as f64).sqrt() * WITNESS_COEFF_BOUND as f64" in config
    assert "JL_UPPER_TAIL_BETA.powf(PROJECTION_LAYERS as f64 / 2.0)" in config
    projection = (SOURCE / "projection.rs").read_text(encoding="utf-8")
    assert "let quotient = shrink_log / coarse_layers;" in projection
    assert "quotient + usize::from(layer < remainder)" in projection
    assert "ProjectionMatrix::new(DEGREE, PROJECTION_ROWS)" in projection
    return k, depth, mu


def instance_parameters(log_M, k, depth, mu, *, rows=256, alpha=ALPHA,
                        beta=BETA, jl_lambda=JL_LAMBDA, a=A,
                        b_paper=B_PAPER, b_conservative=B_CONSERVATIVE):
    M = 1 << log_M
    m = M // PHI
    assert rows > 0 and rows & (rows - 1) == 0
    input_log, output_log = (k * m).bit_length() - 1, rows.bit_length() - 1
    quotient, remainder = divmod(input_log - output_log, depth - 1)
    shrink = [quotient + (j < remainder) for j in range(depth - 1)]
    nus = [input_log]
    for shift in shrink:
        nus.append(nus[-1] - shift)
    assert nus[-1] == output_log
    N = [1 << x for x in nus] + [rows]
    widths = [rows * (1 << shift) for shift in shrink] + [rows]
    reps = [N[j] // widths[j] for j in range(depth)]
    assert reps[-1] == 1
    assert all(reps[j] * widths[j] == N[j] for j in range(depth))
    assert all(reps[j] * rows == N[j + 1] for j in range(depth))
    etas = [PHI * reps[j] for j in range(depth - 1)] + [1]
    kappa_proj = F(sum(etas), 1 << jl_lambda)
    # Distinct sampled entries, not the expanded matrix's repeated entries.
    S_JL = sum(rows * widths[j] for j in range(depth - 1)) + PHI * rows * widths[-1]
    s_M = 2 * S_JL
    # Avoid materializing a 2^(tens of millions) denominator.
    assert s_M >= jl_lambda and sum(etas) >= 1
    beta_squared = F(M * (1 << 20))
    omega_squared = k * beta_squared * beta ** depth
    J_squared = omega_squared / alpha ** depth
    L = sum(nus)
    return {"log2_M_coefficients_per_fresh_witness": log_M,
            "M_coefficients_per_fresh_witness": M, "ring_degree_phi": PHI,
            "paper_commitment_rank_n_reference_only": 12 if log_M <= 27 else 13,
            "m_ring_elements_per_fresh_witness": m, "k": k, "depth_d": depth,
            "mu": mu, "a": a, "JL_lambda": jl_lambda,
            "N_j": N, "nu_j": nus + [output_log],
            "m_j_ring_widths": widths, "n_j_row_counts": [rows] * depth,
            "coefficient_matrix_widths": widths[:-1] + [PHI * widths[-1]],
            "r_j": reps, "eta_j": etas, "coarse_shrink_exponents": shrink,
            "ell_j_squared": [str(alpha)] * depth,
            "u_j_squared": [str(beta)] * depth,
            "b_j_certified_paper": [b_paper] * depth,
            "b_j_conservative_used": [b_conservative] * depth,
            "kappa_j_modular": [str(F(1, 1 << jl_lambda))] * depth,
            "kappa_proj": exact(kappa_proj),
            "honest_upper_tail_union_bound": exact(kappa_proj / 2),
            "S_JL_distinct_ternary_entries": S_JL, "s_M_uniform_raw_bits": s_M,
            "M_repetition_dominated_exact": True,
            "v_trace_variables": output_log, "L_sumcheck_rounds": L,
            "K_tree": (1 << (L + 4)) * (k + 1),
            "extra_two_track_message_bits_at_50bit_encoding": 2 * L * a * 50,
            "beta_in_cap": sqrt_record(beta_squared),
            "omega_projection_cap": sqrt_record(omega_squared),
            "J_joint_fresh_extraction_cap": sqrt_record(J_squared)}


def route_ledger(instance, q, e, gamma, b_D, label):
    k, mu = instance["k"], instance["mu"]
    a = instance["a"]
    assert e % a == 0
    L, v = instance["L_sumcheck_rounds"], instance["v_trace_variables"]
    kproj = F(instance["kappa_proj"]["fraction"])
    trace = F(v ** mu, q ** mu)
    assert F(1, q ** (mu * v)) <= trace
    parts = {"projection_after_repetition_max": kproj,
             "trace_after_repetition_max": trace,
             "fresh_ring_batching": F(1, q ** e),
             "subfield_batching": F(1, q ** a),
             "field_rounds": F(2 * L, q ** a),
             "final_coordinates_including_equal": k * b_D}
    theta = sum(parts.values(), F(0))
    J2 = F(instance["J_joint_fresh_extraction_cap"]["squared_exact"])
    nowrap = []
    for j in range(instance["depth_d"]):
        threshold2 = J2 * F(instance["ell_j_squared"][j]) ** j
        ratio2 = instance["b_j_conservative_used"][j] ** 2 * threshold2 / (q * q)
        assert ratio2 < 1
        nowrap.append({"layer": j, "theta_j": sqrt_record(threshold2),
                       "b_theta_over_q": sqrt_record(ratio2),
                       "b_squared_theta_squared_lt_q_squared": True})
    budgets = []
    for logQ in (32, 64):
        Q = 1 << logQ
        loss = 2 * (Q + 1) * theta
        assert 0 < loss < 1
        Ktree = instance["K_tree"]
        budgets.append({"log2_query_cap": logQ, "Q": Q,
                        "conditional_one_fold_extraction_loss_upper": exact(loss),
                        "expected_black_box_invocations_upper": Ktree + Q * (Ktree - 1)})
    # A useful strict coarse display bound; no arbitrary choice of kappa.
    scaled = theta * q * q
    return {"route": label, "q": q, "e": e, "Gamma": str(gamma),
            "b_D_upper": exact(b_D), "no_wrap_all_layers": nowrap,
            "Theta_components": {name: exact(value) for name, value in parts.items()},
            "Theta_upper": exact(theta), "Theta_times_q_squared_upper": exact(scaled),
            "query_budgets": budgets}


def cube_candidate(k, depth):
    """Independently certify a conservative cube acceptance and full ledger.

    For coefficients uniform in {-1,0,1}, Hoeffding's lemma and
    sum_i cos(theta_i)^2=64 give the stated sixteen-direction root union bound.
    exp's positive Taylor series provides a lower bound with rational input.
    """
    sqrt2_lo = sqrt_bounds(F(2))[0]
    nested_lo = sqrt_bounds(2 + sqrt2_lo)[0]
    exponent_lo = 4 + 2 * nested_lo  # <8*cos(pi/16)^2
    term = exp_lower = F(1)
    for j in range(1, 65):
        term *= exponent_lo / j
        exp_lower += term
    acceptance_lower = 1 - F(1024) / exp_lower
    assert acceptance_lower > F(53, 100)
    cube_cardinality = 3 ** PHI
    assert (cube_cardinality - 1).bit_length() == 203
    accepted_cardinality_lower = (53 * cube_cardinality + 99) // 100
    assert accepted_cardinality_lower > 1 << 201
    b = F(1, accepted_cardinality_lower)
    T, Q, gamma = 32, 1 << 64, F(32)
    results = []
    for log_M in (25, 27, 29):
        item = instance_parameters(log_M, k, depth, 8, rows=512,
                                   alpha=F(1101, 20), beta=F(686),
                                   jl_lambda=256, a=8,
                                   b_paper=224, b_conservative=225)
        route = route_ledger(item, Q_E, 64, gamma, b, "cube_Gamma32_JL256_mu8_a8")
        theta = F(route["Theta_upper"]["fraction"])
        global_loss = T * 2 * (Q + 1) * theta
        assert global_loss < F(1, 1 << 128)
        route["T32_union_ledger_conditional_loss"] = exact(global_loss)
        route["T32_loss_divided_by_2_minus_128"] = exact(global_loss * (1 << 128))
        route["T32_union_ledger_lt_2_minus_128"] = True
        history_tree = item["K_tree"] ** T
        route["T32_global_tree"] = {
            "conditions": "Global fixed key, checked linked history, canonical full-prefix oracle inputs, fixed per-depth domains, and explicit final witness; see history_composition.md",
            "K_history": history_tree,
            "ceil_log2_K_history": (history_tree-1).bit_length(),
            "expected_original_adversary_invocations_upper": history_tree + Q*(history_tree-1),
            "conditional_loss_upper": exact(global_loss),
            "polynomial_variable_depth_extraction_established": False,
        }
        beta2 = F(item["beta_in_cap"]["squared_exact"])
        beta_lo, beta_hi = sqrt_bounds(beta2)
        ratio_lo, ratio_hi = sqrt_bounds((F(686) / F(1101, 20)) ** depth)
        delta_lo = k * gamma * beta_lo * ratio_lo
        delta_hi = k * gamma * beta_hi * ratio_hi
        first_lo = k * gamma * beta_lo * (T + (T - 1) * ratio_lo)
        first_hi = k * gamma * beta_hi * (T + (T - 1) * ratio_hi)
        sis_lo = max(8 * gamma * first_lo, 2 * (first_lo + delta_lo))
        sis_hi = max(8 * gamma * first_hi, 2 * (first_hi + delta_hi))
        assert sis_hi < Q_E
        route["T32_zero_initial_accumulator_radius"] = {
            "B_first_lower": str(first_lo), "B_first_upper": str(first_hi),
            "B_SIS_lower": str(sis_lo), "B_SIS_upper": str(sis_hi),
            "B_SIS_over_q_upper": exact(sis_hi / Q_E),
            "B_SIS_lt_q": True, "SIS_hardness_estimated": False}
        item["route"] = route
        results.append(item)
    return {"q": Q_E, "Gamma": "32", "uniform_unconditioned_cube_size": cube_cardinality,
            "norm_root_angular_bound": "p >= 1 - 1024 exp(-8 cos(pi/16)^2)",
            "rational_exponent_lower": str(exponent_lo),
            "positive_exp_Taylor_terms": 65,
            "certified_acceptance_lower_used": "53/100",
            "acceptance_lower_proved_gt_53_over_100": True,
            "accepted_cardinality_lower": accepted_cardinality_lower,
            "accepted_cardinality_gt_2_pow_201": True,
            "b_D_upper": exact(b), "raw_rank_bits": 203,
            "mu": 8,
            "mu_scope": "mu=8 retains paper Theorem 1's power-of-two restriction. The modified algebra also permits mu=5, but this certificate does not depend on that generalization.",
            "a8_coordinate_count": PHI // 8,
            "a8_coordinates_per_CRT_slot": 64 // 8,
            "composition_boundary": "The numerical loss is also the global complete-tree theorem's loss under history_composition.md's explicit interfaces. The history tree is a product; variable-depth efficient extraction and SIS hardness are not proved.",
            "instances": results}


def main():
    k, depth, mu = read_code_parameters()
    lifting = json.loads((ROOT / "repair-notes/rom_sampler_lifting.json").read_text(encoding="utf-8"))
    assert lifting["fixed_weight_exact_modulus"]["Omega_cardinality_lower"] == N_E
    assert F(lifting["cbd_original_modulus"]["fixed_anchor_nonunit_including_equal_upper_exact"]) == CBD_B
    moduli = {"exact_modulus": lucas_certificate(Q_E, {2: 2, 3: 1, 6637: 1, 40123: 1, 352333: 1}, 6),
              "original_modulus_CBD12": lucas_certificate(Q_B, {2: 7, 653: 1, 13470280279: 1}, 3)}
    assert moduli["exact_modulus"]["slot_degree_e"] == 64
    assert moduli["original_modulus_CBD12"]["slot_degree_e"] == 2
    instances = []
    for log_M in (25, 27, 29):
        item = instance_parameters(log_M, k, depth, mu)
        item["routes"] = [route_ledger(item, Q_E, 64, F(62, 5), F(1, N_E), "exact_modulus"),
                          route_ledger(item, Q_B, 2, F(78), CBD_B, "original_modulus_CBD12")]
        instances.append(item)
    source_paths = ["work/page_08.txt", "work/page_19.txt", "work/page_27.txt", "work/page_41.txt",
                    "work/downloaded_code/pikku-main/pikku-fold-schemelet/src/config.rs",
                    "work/downloaded_code/pikku-main/pikku-fold-schemelet/src/projection.rs",
                    "work/downloaded_code/pikku-main/pikku-fold-schemelet/src/verifier.rs",
                    "results/jl_checks.json", "repair-notes/rom_sampler_lifting.json",
                    "pikku-proof-repair/docs/two_track_rom.md"]
    result = {"scope": "Exact arithmetic composition of certified mathematical inputs; conditional classical-ROM one-fold bound, not security bits or an SIS estimate.",
              "input_certificate_dependencies": {"JL": "scripts/jl_verify.py; results/jl_checks.json; paper Theorem 2",
                                                  "fixed_weight": "scripts/repair_exact_modulus.py; results/repair_exact_modulus.json",
                                                  "CBD12": "scripts/repair_sampler_bounds.py; repair-notes/sampler_bounds.json",
                                                  "compiler": "pikku-proof-repair/docs/two_track_rom.md (T2)-(T3)"},
              "implementation_boundary": "Config formula is interpreted exactly. Rust f64 norm/powf comparison, new CRT arithmetic, complete two-track protocol, and concrete SHAKE are not certified by this script.",
              "source_sha256": {p: sha256((ROOT / p).read_bytes()).hexdigest() for p in source_paths},
              "JL_probabilities_per_256_row_matrix": {"single_row": str(F(1, 1 << 137)),
                                                       "union_all_rows": str(F(1, 1 << 129)),
                                                       "real_upper": str(F(1, 1 << 129)),
                                                       "real_lower": str(F(1, 1 << 129)),
                                                       "real_two_sided": str(F(1, 1 << 128)),
                                                       "modular_lower": str(F(1, 1 << 128))},
              "modulus_certificates": moduli, "instances": instances,
              "stronger_cube_candidate": cube_candidate(k, depth)}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for item in instances:
        print(f"M=2^{item['log2_M_coefficients_per_fresh_witness']} L={item['L_sumcheck_rounds']} "
              f"eta={item['eta_j']} kappa_proj<={item['kappa_proj']['decimal_upper']}")
        for route in item["routes"]:
            loss = [x["conditional_one_fold_extraction_loss_upper"]["decimal_upper"] for x in route["query_budgets"]]
            print(f"  {route['route']}: Theta<={route['Theta_upper']['decimal_upper']}; Q32/Q64={loss}; "
                  f"max b*theta/q<={route['no_wrap_all_layers'][-1]['b_theta_over_q']['decimal_upper']}")
    for item in result["stronger_cube_candidate"]["instances"]:
        r = item["route"]
        print(f"CUBE M=2^{item['log2_M_coefficients_per_fresh_witness']} L={item['L_sumcheck_rounds']}: "
              f"Theta<={r['Theta_upper']['decimal_upper']}; T32 Q64 loss<={r['T32_union_ledger_conditional_loss']['decimal_upper']}; "
              f"radius/q<={r['T32_zero_initial_accumulator_radius']['B_SIS_over_q_upper']['decimal_upper']}")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
