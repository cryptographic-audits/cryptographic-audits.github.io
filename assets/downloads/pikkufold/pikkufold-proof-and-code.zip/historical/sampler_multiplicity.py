"""Exact arithmetic for a stronger deterministic H1 obstruction.

No challenge collisions are searched for, and no protocol is executed.
All bounds are integers/Fractions; floats only label logarithms.
"""
from fractions import Fraction as F
from math import comb, log2
from pathlib import Path
import json


def ceil_div(a, b):
    return (a + b - 1) // b


def balanced_ordered_pairs(N, Q):
    """Minimum sum_v n_v*(n_v-1) for Q fibres totalling N."""
    a, b = divmod(N, Q)
    return Q * a * (a - 1) + 2 * a * b


def anchor_count_bound(N, Q, slots, max_shared):
    S = balanced_ordered_pairs(N, Q)
    return max(0, ceil_div(slots * S, max_shared * N))


q = (1 << 50) - 2687
n, e, slots, weight = 128, 2, 64, 23
full = (1 << weight) * comb(n, weight)
even = (1 << weight) * comb(n // 2, weight)
D2 = 4 * weight
norm_upper = D2 ** (n // 2)
r = 0
while q ** (e * (r + 1)) <= norm_upper:
    r += 1
assert r == 4
assert q**8 <= 92**64 < q**10

# Compare (slots/r)*(N/q-1)/full with slots/q**e.
required_N = F(q) + F(r * full, q ** (e - 1))
required_p = required_N / even
required_integer = required_N.numerator // required_N.denominator + 1
assert F(slots, r) * (F(required_integer, q) - 1) / full > F(slots, q**e)

# Stronger discrete fibre arithmetic gives a slightly smaller sufficient N.
lo, hi = q, required_integer
while lo < hi:
    mid = (lo + hi) // 2
    if anchor_count_bound(mid, q, slots, r) * q**e > slots * full:
        hi = mid
    else:
        lo = mid + 1
discrete_N = lo
assert anchor_count_bound(discrete_N, q, slots, r) * q**e > slots * full
assert anchor_count_bound(discrete_N - 1, q, slots, r) * q**e <= slots * full

conditional_N = ceil_div(even, 10)
conditional_anchor_count = anchor_count_bound(conditional_N, q, slots, r)
conditional_fraction = F(conditional_anchor_count, full)
continuous_conditional = F(slots, r) * (F(even, 10*q)-1) / full
old_threshold = F(q) + F(slots * full, q)

# Four same-support accepted sign patterns follow from +/- a(+/-Y),
# provided the support includes both even and odd exponents.
all_supports = comb(64, 23)
mixed_supports = all_supports - 2 * comb(32, 23)
supports_needed = ceil_div(discrete_N, 4)

# Apply the new theorem to an already deterministic, genuinely rejecting case.
q_small, n_small, e_small, h_small = 257, 1024, 8, 128
C_small = 2**7 * comb(1024, 7)
T_small_lower = 2**7 * comb(128, 7) - 64 * 256 * comb(11, 6)
r_small = 0
while q_small**(e_small*(r_small+1)) <= 28**512:
    r_small += 1
assert r_small == 38
small_anchor = anchor_count_bound(T_small_lower, q_small, h_small, r_small)
small_eps = F(small_anchor, C_small)

no_rejection = []
for s in range(21, 38):
    Cs = 2**s * comb(128, s)
    Ts = 2**s * comb(64, s)
    rs = 0
    while q**(2*(rs+1)) <= (4*s)**64:
        rs += 1
    assert Cs >= q*q
    lower = F(64, rs) * (F(Ts, q)-1) / Cs
    ratio = lower / F(64, q*q)
    assert ratio > 1
    no_rejection.append({'weight':s,'gamma':s,'max_shared_slots':rs,
                         'log2_factor_above_H1_lower_bound':log2(ratio)})

out = {
    'status': 'Deterministic multiplicity/counting theorem; actual acceptance-population size remains unproved.',
    'q': q, 'n': n, 'e': e, 'slots': slots,
    'D_squared': D2, 'max_shared_slots': r,
    'integer_certificate': 'q^8 <= 92^64 < q^10',
    'norm_upper_integer': norm_upper,
    'C_base': full, 'T_base': even,
    'continuous_sufficient_T_threshold_exact': str(required_N),
    'continuous_sufficient_integer_T': required_integer,
    'continuous_threshold_log2': log2(required_N),
    'continuous_sufficient_p_T_exact': str(required_p),
    'continuous_sufficient_p_T': float(required_p),
    'continuous_p_T_threshold_bits': -log2(required_p),
    'discrete_sufficient_integer_T': discrete_N,
    'discrete_sufficient_p_T': float(F(discrete_N, even)),
    'certified_anchor_count_at_discrete_threshold': anchor_count_bound(discrete_N,q,slots,r),
    'required_other_challenges_to_exceed_H1': (slots*full)//q**e + 1,
    'old_to_new_continuous_threshold_ratio': float(old_threshold / required_N),
    'conditional_if_p_T_ge_0_1': {
        'T_lower': conditional_N,
        'integer_anchor_other_count_lower': conditional_anchor_count,
        'epsilon_lower_fraction': str(conditional_fraction),
        'epsilon_lower_bits': -log2(conditional_fraction),
        'continuous_epsilon_lower_bits': -log2(continuous_conditional),
    },
    'unproved_signing_route': {
        'all_supports': all_supports,
        'mixed_parity_supports': mixed_supports,
        'supports_with_one_good_signing_sufficient': supports_needed,
        'fraction_of_all_supports_needed': float(F(supports_needed, all_supports)),
        'fraction_of_mixed_supports_needed': float(F(supports_needed, mixed_supports)),
        'warning': 'No proof supplied that this many supports have a signing with norm <= 8.357.',
    },
    'new_unconditional_gamma6_99_strengthening': {
        'max_shared_slots':r_small,
        'T_accepted_lower':T_small_lower,
        'anchor_other_count_lower':small_anchor,
        'epsilon_lower_exact':str(small_eps),
        'epsilon_lower_bits':-log2(small_eps),
        'factor_above_H1_lower_bound':float(small_eps/F(128,257**8)),
    },
    'actual_modulus_unconditional_gamma_equals_weight':no_rejection,
}
dest = Path(__file__).resolve().parents[1] / 'results' / 'sampler_multiplicity.json'
dest.write_text(json.dumps(out, indent=2), encoding='utf-8')
print(json.dumps(out, indent=2))
