"""Integer/rational certificates for the conservative norm-reset check norm reset.

No prover, attack, or downloaded program is run. The new 128-bit prime is
certified by two Pocklington/order steps. Decisive comparisons use exact
integers or Fractions; square roots use rational enclosures. Probability inputs
are the previously certified JL-256 and cube acceptance >=53/100 bounds.
"""
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction as F
from math import gcd, isqrt
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
PHI, A, E, MU, ROWS = 128, 8, 64, 8, 512
GAMMA, T, K, BASE, DIGITS = 32, 32, 32, 3, 24
R2 = (F(686) / F(1101, 20)) ** 3
Q_AUX = 11487 * 2**112 + 1
Q_RESET = 4 * Q_AUX + 1
Q_OLD = 2**50 - 27
N_CUBE = (53 * 3**128 + 99) // 100
B_D = F(1, N_CUBE)


def show(x):
    x = F(x)
    with localcontext() as ctx:
        ctx.prec = 17
        ctx.rounding = ROUND_CEILING
        return str(Decimal(x.numerator) / Decimal(x.denominator))


def enc(x):
    return {"exact": str(x), "decimal_upper": show(x)}


def sqrt_interval(x):
    x, scale = F(x), 10**35
    r = isqrt(x.numerator * scale * scale // x.denominator)
    lo, hi = F(r, scale), F(r + 1, scale)
    assert lo * lo <= x < hi * hi
    return lo, hi


def enc_sqrt(x):
    lo, hi = sqrt_interval(x)
    return {"squared_exact": str(x), "lower": str(lo), "upper": str(hi),
            "decimal_upper": show(hi)}


def certify_modulus():
    # For any prime divisor p of Q_AUX, the first order check forces
    # 2^112 | (p-1). Since 2^112 > sqrt(Q_AUX), Q_AUX is prime.
    assert Q_AUX - 1 == 11487 * 2**112
    assert (2**112) ** 2 > Q_AUX
    assert pow(5, Q_AUX - 1, Q_AUX) == 1
    assert gcd(pow(5, (Q_AUX - 1) // 2, Q_AUX) - 1, Q_AUX) == 1
    # Now the prime factor Q_AUX of q-1 exceeds sqrt(q). For every prime
    # divisor p of q, the second order check forces Q_AUX | (p-1).
    assert Q_AUX * Q_AUX > Q_RESET
    assert pow(2, Q_RESET - 1, Q_RESET) == 1
    assert gcd(pow(2, 4, Q_RESET) - 1, Q_RESET) == 1
    assert Q_RESET % 8 == 5 and Q_RESET % 256 == 5
    order = next(j for j in range(1, 129) if pow(Q_RESET, j, 256) == 1)
    assert order == E and E % A == 0
    i = pow(2, (Q_RESET - 1) // 4, Q_RESET)
    assert i * i % Q_RESET == Q_RESET - 1
    return {"q": Q_RESET, "bits": Q_RESET.bit_length(),
            "formula": "11487*2^114+5", "auxiliary_prime": Q_AUX,
            "auxiliary_known_factor": 2**112, "auxiliary_witness": 5,
            "main_known_prime_factor": Q_AUX, "main_witness": 2,
            "q_mod_256": Q_RESET % 256, "slot_degree": order,
            "slot_count": PHI // E, "subfield_degree": A,
            "subfield_coordinate_count": PHI // A, "sqrt_minus_one": i,
            "certificate": "Two exact order/Pocklington checks; no probable-prime test is used."}


def fold_shape(log_M, arity, fresh_cap_squared):
    m = 2**log_M // PHI
    nu0 = (arity * m).bit_length() - 1
    quotient, remainder = divmod(nu0 - 9, 2)
    shrink = [quotient + (j < remainder) for j in range(2)]
    nus = [nu0, nu0 - shrink[0], 9]
    boundaries = [2**x for x in nus] + [ROWS]
    widths = [ROWS * 2**s for s in shrink] + [ROWS]
    reps = [boundaries[j] // widths[j] for j in range(3)]
    assert all(reps[j] * ROWS == boundaries[j + 1] for j in range(3))
    eta = [PHI * reps[0], PHI * reps[1], 1]
    L = sum(nus)
    j2 = arity * fresh_cap_squared * R2
    nowrap = []
    for j in range(3):
        theta2 = j2 * F(1101, 20)**j
        assert 225**2 * theta2 < Q_RESET**2
        nowrap.append(enc_sqrt(225**2 * theta2 / Q_RESET**2))
    kproj = F(sum(eta), 2**256)
    sjl = ROWS * (widths[0] + widths[1] + PHI * widths[2])
    assert 2 * sjl >= 256
    assert F(1, Q_RESET**(MU * 9)) <= F(9**MU, Q_RESET**MU)
    theta = (kproj + F(9**MU, Q_RESET**MU) + F(1, Q_RESET**E)
             + F(2*L + 1, Q_RESET**A) + arity * B_D)
    return {"arity": arity, "N_j": boundaries, "m_j": widths,
            "r_j": reps, "eta_j": eta, "L": L,
            "kappa_proj": enc(kproj), "joint_cap": enc_sqrt(j2),
            "JL_no_wrap_ratios": nowrap, "s_M": 2*sjl,
            "Theta": enc(theta), "K_tree": (arity + 1) * 2**(L+4)}


def parameters(log_M):
    M = 2**log_M
    ell = log_M - 7
    beta2 = F(1024**2 * M)
    reset2 = F((K * GAMMA)**2 * M)
    assert reset2 == beta2
    cap2 = 2049**2 * beta2
    trit_limit = (BASE**DIGITS - 1) // (BASE - 1)
    assert cap2 <= trit_limit**2
    h2 = F(BASE**(2*DIGITS) - 1, BASE**2 - 1)
    assert h2.denominator == 1
    jdig2 = K * M * R2
    d2 = h2 * jdig2
    assert cap2 < d2
    assert 2 * d2 < Q_RESET                 # Dedicated normalized-trace proof.
    assert 4 * PHI * d2 < Q_RESET           # Also meets SALSAA's stronger setting.
    assert 4 * d2 < Q_RESET**2              # Two bounded lifts cannot differ by q.
    ordinary = fold_shape(log_M, 2, beta2)
    checkpoint = fold_shape(log_M, K, F(M))
    beta_lo, beta_hi = sqrt_interval(beta2)
    rlo, rhi = sqrt_interval(R2)
    bstar_lo = beta_lo * (2049 + T * 2 * GAMMA * rlo)
    bstar_hi = beta_hi * (2049 + T * 2 * GAMMA * rhi)
    cp_delta_hi = beta_hi * rhi  # Gamma*K*sqrt(M)*R = beta*R.
    fold_sis_hi = max(8*GAMMA*bstar_hi, 2*(bstar_hi + cp_delta_hi))
    d_lo, d_hi = sqrt_interval(d2)
    assert fold_sis_hi < 2*d_lo
    assert 2*d_hi < Q_RESET
    norm_theta = F(2*ell + 1, Q_RESET**A)
    cycle_theta = (T * F(ordinary["Theta"]["exact"])
                   + F(checkpoint["Theta"]["exact"]) + norm_theta)
    query_cap = 2**64
    loss = 2*(query_cap + 1)*cycle_theta
    assert loss < F(1, 2**128)
    max_cycles = int(F(1, 2**128) / loss)
    assert max_cycles * loss < F(1, 2**128)
    assert (max_cycles + 1)*loss >= F(1, 2**128)
    k_norm = 2**(ell+1)
    k_cycle = ordinary["K_tree"]**T * checkpoint["K_tree"] * k_norm
    bits = Q_RESET.bit_length()
    # Conservative fixed-width encodings; verifier challenges are excluded.
    norm_message_bits = (2*PHI + 4*ell*A)*bits
    cp_fold_message_bits = (ROWS + (MU + K + 1)*PHI + 4*checkpoint["L"]*A)*bits
    return {"log2_M": log_M, "M": M, "m": 2**ell, "log2_m": ell,
            "beta_fresh": enc_sqrt(beta2), "beta_reset": enc_sqrt(reset2),
            "B_cap": enc_sqrt(cap2), "digit_count": DIGITS, "padded_arity": K,
            "centered_base": BASE, "trit_max_representable_absolute_value": trit_limit,
            "honest_digit_cap_squared": M, "H_squared": str(h2),
            "J_digits": enc_sqrt(jdig2), "D_recombined": enc_sqrt(d2),
            "normalized_no_wrap_2D_squared_over_q": enc(2*d2/Q_RESET),
            "SALSAA_4phiD_squared_over_q": enc(4*PHI*d2/Q_RESET),
            "old_q_fails_normalized_by_factor": enc(2*d2/Q_OLD),
            "ordinary_fold": ordinary, "checkpoint_fold": checkpoint,
            "B_checkpoint_target": {"lower": str(bstar_lo), "upper": str(bstar_hi),
                                     "decimal_upper": show(bstar_hi)},
            "fold_SIS_radius_upper": enc(fold_sis_hi),
            "norm_SIS_radius": enc_sqrt(4*d2),
            "SIS_history_over_q_upper": enc(2*d_hi/Q_RESET),
            "SIS_dominating_branch": "norm-check binding, coefficient radius 2D",
            "norm_internal_loss": enc(norm_theta), "cycle_internal_loss": enc(cycle_theta),
            "Q_global": query_cap, "cycle_ROM_loss_upper": enc(loss),
            "cycle_loss_lt_2_minus_128": True,
            "max_equal_cycles_under_2_minus_128_at_same_Q": max_cycles,
            "cycle_honest_failure_upper": enc((T*F(ordinary['kappa_proj']['exact'])
                                              + F(checkpoint['kappa_proj']['exact']))/2),
            "K_norm": k_norm, "K_cycle": k_cycle,
            "expected_original_adversary_invocations_upper": k_cycle + query_cap*(k_cycle-1),
            "norm_prover_message_bits_fixed_width": norm_message_bits,
            "decomposition_message_bits_per_ncom_plus_one": (DIGITS-1)*PHI*bits,
            "checkpoint_fold_prover_message_bits_fixed_width": cp_fold_message_bits}


def main():
    result = {"scope": "Dedicated conditional normalized-trace norm-reset protocol, with explicit algebra/ROM/history assumptions; no SIS hardness or production claim.",
              "q_certificate": certify_modulus(),
              "common": {"phi": PHI, "a": A, "e": E, "mu": MU, "rows": ROWS,
                         "Gamma": GAMMA, "ordinary_arity": 2, "ordinary_folds": T,
                         "digit_base": BASE, "digits": DIGITS, "checkpoint_arity": K,
                         "JL_alpha": "55.05", "JL_beta": "686", "JL_b": 225,
                         "R_squared": str(R2), "accepted_cube_cardinality_lower": N_CUBE,
                         "b_D_upper": str(B_D)},
              "instances": [parameters(log_M) for log_M in (25, 27, 29)]}
    output = ROOT / 'results/norm_reset_check.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print('q_reset=', Q_RESET, 'bits=', Q_RESET.bit_length())
    for row in result['instances']:
        print('M=2^'+str(row['log2_M']), 'D<=', row['D_recombined']['decimal_upper'],
              '4phiD2/q<=', row['SALSAA_4phiD_squared_over_q']['decimal_upper'],
              'cycle_loss<=', row['cycle_ROM_loss_upper']['decimal_upper'],
              'SIS/q<=', row['SIS_history_over_q_upper']['decimal_upper'],
              'max_cycles=', row['max_equal_cycles_under_2_minus_128_at_same_Q'])
    print(output)


if __name__ == '__main__':
    main()
