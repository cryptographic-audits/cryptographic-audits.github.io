#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python verify_many_orbits.py candidates_0_511.txt
c++ -std=c++17 -O3 first_layer_kernel.cpp -o /tmp/pikkufold_zero_slot_kernel_exe
/tmp/pikkufold_zero_slot_kernel_exe first_layer_kernel_certificate.txt 20261123
python verify_zero_slot_parameters.py first_layer_kernel_certificate.txt
python attack_algebra_demo.py
sha256sum -c CHECKSUMS.sha256
