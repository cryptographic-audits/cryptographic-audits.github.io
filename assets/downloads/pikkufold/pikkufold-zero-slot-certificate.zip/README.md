# PikkuFold zero-slot certificate

This module contains the exact CRT, accepted-challenge, orbit-counting, kernel, and probability checks.

Run:

```bash
bash verify_all.sh
```

The names describe each file by function; no development-round numbering is used.
