# PikkuFold zero-slot counting certificate

This module contains the finite certificate and independent checks used to establish the lower bound on accepted 50-bit challenges that vanish in one quadratic CRT slot.

Run:

```bash
bash verify_all.sh
```

The main checks are:

- `verify_round9.py`: modulus, CRT idempotent, parameter, rank, and probability arithmetic;
- `verify_many_orbits.py`: accepted candidates and signed-rotation classes;
- `reproduce_enumeration.py`: rational operator-norm enclosures;
- `candidates_0_511.txt`: the explicit candidate set used by the certificate.

The source-code comments are in English. Reference results and logs are included for comparison.
