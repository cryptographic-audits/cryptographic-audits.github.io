# Source provenance and build boundaries

- `upstream/pikku-main(1).zip` is the original 2026-09-17 PikkuFold source snapshot supplied in the conversation, not an independently downloaded current HEAD. The original Rust Cargo manifest pins Rokoko revision `64a9cd49d7d5281b0e174556662ec283e2eb8b3d`.
- `round8/`, `round9/`, `round10/`, `round11/`, `round12/` are complete extracted copies of the previously delivered round-specific code packages. Their own `CHECKSUMS.sha256` files remain included; the top-level `CHECKSUMS.sha256` covers all files as staged for this package.
- `round10/install_adversarial_test.py` is the historical unmodified installer. It generates a Rust file omitting the `FRESH_INPUTS` import; the user corrected it before successful Cargo builds. The top-level `INSTALL_FROM_CLEAN.sh` performs precisely that one-line fix.
- `portable/` contains AVX-512 compatibility scripts and original verifier-only/output-input test modules from the prior audit.
- `GIST_PROOF.md` is a new synthesis, not a verbatim author paper excerpt. Its mathematical counting claims were rechecked with Round9 scripts on 2026-11-23.
- `OBSERVED_WSL_RESULTS.md` transcribes user-reported Rust outputs. These are distinct from direct executable tests in this packaging environment (which has no Rust toolchain).
- `historical/` contains other audit scripts and a prior code archive; they are supplementary, not dependencies of the main zero-slot attack.

For third-party use, please credit the original authors of PikkuFold and respect their source-code licensing; the upstream snapshot is included only for reproducibility and source comparison.
- `upstream/eprint_2026-1809_PikkuFold.pdf` is the source-paper copy supplied in the conversation. It is a reference copy, not an edited PDF.
