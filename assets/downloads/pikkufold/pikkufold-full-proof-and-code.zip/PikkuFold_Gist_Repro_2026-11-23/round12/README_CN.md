# PikkuFold 第十二轮：受控公开随机币的**同一验证器路径**重放

## 核心区别

第十一轮实测已经确认：真实 40 轮恶意 RingSC 被原 `verify_fold()` 接受；正常 SHAKE 挑战下零见证被原 `verify_output()` 拒绝；用预先认证的零槽挑战**后验重算输出关系**后，零见证被原 `verify_output()` 接受。

但第十一轮第三项的挑战是 `verify_fold()` 运行结束后由测试人工代入，不是让 `verify_fold()` 使用该最终挑战。本包补齐**条件性内部一致性测试**：通过测试专用、线程局部、作用域结束即清除的钩子，令原 `verify_fold()` 在**它本身调用 `fold_challenges()` 时**收到指定挑战，并把其真实返回的 `VerifierMessage` 原样交给原 `verify_output()`。这与后验手工重算输出关系有所区别。

**边界务必保留：**该功能修改的是 `src/fold.rs` 中 final folding challenge 的**测试特性分支**，因此属于**受控 public-coin/条件性试验**；它不是不可篡改 SHAKE 的非交互运行，也不是实际哈希攻击。`src/verifier.rs`、`src/output.rs`、`src/sumcheck.rs`、`src/transcript.rs`、`src/projection.rs` 逐字节不变。只有在测试二进制且启用 `conditional-fold-audit` 时才可触发强制挑战。常规编译和测试中无钩子，抽样逻辑仍原样运行。

## 原始参数及接受域验证

运行前、运行时均检查候选挑战属于原采样集合的支持：重量 23、所有非零环系数均为 ±1、negacyclic operator norm 小于 8.357（实际上约为 8.117973728）。`z_good * Lambda = 0`，而 `z_bad * Lambda != 0`。本包另附标准库 Python 独立数值/模数核验。

### 正负对照

1. **正常 SHAKE:** 用原 `verify_fold` 得到输出，原 `verify_output` 检查零见证；若这次随机挑战不在目标零槽，则拒绝。无强制挑战。
2. **条件性有利挑战:** `z0=z_good, z1=z_bad, z2=1`，在原 `verify_fold` 最后一次挑战生成位置注入；原 `verify_fold` 成功后，输出值必须为 0，原 `verify_output` 必须接受真正零见证。
3. **条件性不利挑战:** `z0=z_bad, z1=z_good, z2=1`，原 `verify_fold` 仍通过，但 `verify_output` 必须拒绝零见证。
4. **钩子恢复:** 作用域结束后重新调用原 `verify_fold`；要求挑战派生输出与正常 SHAKE 基线逐项相同。

全部对照共享**同一公开实例、同一份恶意 RingSC proof、相同的 40 轮证明消息、完全相同的终端点**。测试再次证明输入短见证不存在：第一个输入求值点全零，因此首环系数的中心代表至少为 `(q-1)/64 = 17,592,186,044,374`，超过整个输入范数界。`derived-key`/标量后端对零见证仅使用线性承诺恒等式 `K0=0`，不构成任意非零见证承诺后端等价验证。

## 在已经通过第十一轮的 Ubuntu 环境安装

下载压缩包到 Windows Downloads，解压到 `~/pikkufold-lab/round12`，然后：

```bash
cd ~/pikkufold-lab/original/pikku-main/pikku-fold-schemelet
python3 ~/pikkufold-lab/round12/install_round12.py \
  --append ~/pikkufold-lab/round12/round12_test_append.rs
```

安装脚本检查第十一轮基础、自动备份更改文件、重复运行不重复修改；安装前后检查关键验证源码哈希不变。取消更改时，使用它打印的 `*.before_round12_...` 备份恢复三项文件。

## 运行

先做不需要 Rust 的独立检查：

```bash
python3 ~/pikkufold-lab/round12/verify_round12_static.py
```

本包的测试特性名为 `conditional-fold-audit`，它自动启用 `scalar-commit-audit` 和 `derived-key`。

```bash
cd ~/pikkufold-lab/original/pikku-main/pikku-fold-schemelet
export CARGO_NET_GIT_FETCH_WITH_CLI=true
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export RUSTFLAGS='-C target-cpu=x86-64-v3'
set -o pipefail

cargo +nightly test --locked --features conditional-fold-audit --no-run \
  2>&1 | tee ~/pikkufold-lab/round12_compile.log

PIKKU_ATTACK_LOG_M=10 cargo +nightly test --locked \
  --features conditional-fold-audit \
  adversarial_attack_tests::test_round12_conditional_original_verifier_replay \
  -- --exact --nocapture --test-threads=1 \
  2>&1 | tee ~/pikkufold-lab/round12_small.log

PIKKU_ATTACK_LOG_M=18 cargo +nightly test --locked \
  --features conditional-fold-audit \
  adversarial_attack_tests::test_round12_conditional_original_verifier_replay \
  -- --exact --nocapture --test-threads=1 \
  2>&1 | tee ~/pikkufold-lab/round12_40round.log
```

**预期而非已实测**的关键输出：

```
R12_GOOD_CHALLENGE_WEIGHT=23; SPECTRAL_NORM=8.117973728; LIMIT=8.357
R12_BAD_CHALLENGE_WEIGHT=23; SPECTRAL_NORM=8.117973728; LIMIT=8.357
R12_GOOD_ORIGINAL_VERIFY_FOLD_AND_OUTPUT_ACCEPTED=true
R12_BAD_ORIGINAL_VERIFY_FOLD_ACCEPTED_OUTPUT_REJECTED=true
R12_FS_STATE_RESTORED_IDENTICALLY=true
R12_PASS m=2^18, rounds=40, rank=12
R12_SCOPE: conditional public-coin verification; NOT a SHAKE forgery
```

`R12_NORMAL_FS_ZERO_SLOT=false` 是概率极高的正常情形，但不是测试强行保证的结果。若幸运地出现真零槽事件会单独记录。

## 执行状况与科研结论

安装器已在第十轮源代码及第十一轮补丁的**本地副本**上进行静态安装与重复安装检查，且 Python challenge 检查通过。交付环境没有用户的 Rust 工具链，**本包 Rust 代码尚未编译或运行**。请用上面的 `--no-run` 检查实际接口，再报告终端输出。

即便本轮完全通过，也只能断言**条件于一个位于原采样支持集内的预先给定有利末轮挑战，验证器链可接受无短输入关系的攻击 transcript**。抽象知识健全性定理允许按真正的 `epsilon_C` 支付这类失败概率；本实验不能直接推翻该定理。已核算的约 `2^-84.46` 下界属于先前独立挑战计数证书，而非本轮某次 FS 成功观测，也不意味着实际生成了一份可脱离测试钩子验证的哈希伪造证明。
