#!/usr/bin/env python3
"""Append the opt-in conditional output challenge test without changing verifier logic.

Run from original pikku-fold-schemelet crate root:
  python3 /path/to/install_round11.py --append /path/to/round11_test_append.rs

Only src/adversarial_attack_tests.rs and src/commitment.rs are changed.  This
adds an exact zero-commitment fast path for a ZERO witness in the project's
pre-existing derived-key code, which is mathematical for any commitment key.
No proof-verifier algorithm or Fiat-Shamir function is patched.
"""
import argparse
import shutil
from datetime import datetime, timezone
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--append',type=Path,required=True)
a=p.parse_args()
root=Path.cwd()
tests=root/'src/adversarial_attack_tests.rs'
commit=root/'src/commitment.rs'
cargo=root/'Cargo.toml'
if not all(x.exists() for x in [tests,commit,cargo]):
    raise SystemExit('Run from original schemelet with Round10 installed.')
if 'scalar-commit-audit = []' not in cargo.read_text(encoding='utf-8'):
    raise SystemExit('Requires prior scalar-commit-audit feature.')
if 'derived-key = []' not in cargo.read_text(encoding='utf-8'):
    raise SystemExit('Requires original derived-key feature.')

addition=a.append.read_text(encoding='utf-8')
marker='// ROUND11_CONDITIONAL_OUTPUT_AUDIT_BEGIN'
assert addition.startswith(marker) and addition.rstrip().endswith('// ROUND11_CONDITIONAL_OUTPUT_AUDIT_END')
t=tests.read_text(encoding='utf-8')
assert 'fn test_adversarial_40_rounds()' in t
if marker not in t:
    new_tests=t.rstrip()+'\n\n'+addition
else:
    if not t.rstrip().endswith(addition.rstrip()):
        raise SystemExit('Round11 marker already exists with different content; refusing edit.')
    new_tests=t

old='''    #[cfg(feature = "derived-key")]
    pub(crate) fn commit_column(&self, column: &[RingElement]) -> (Vec<RingElement>, Duration) {
        use rokoko::common::sampling::{AesCtrPublicSampler, PUBLIC_CRS_SEED};
        assert_eq!(column.len(), self.height);
'''
new=old+'''        // ROUND11_DERIVED_ZERO_REFERENCE_BEGIN
        // Audit-only exact identity: the commitment of the zero column is zero
        // for EVERY derived/public CRS.  Avoid key generation and AVX-512.
        // Nonzero columns retain the original implementation unchanged.
        #[cfg(feature = "scalar-commit-audit")]
        {
            let zero = RingElement::zero(Representation::IncompleteNTT);
            if column.iter().all(|x| x == &zero) {
                return (vec![zero; self.rank], Duration::ZERO);
            }
        }
        // ROUND11_DERIVED_ZERO_REFERENCE_END
'''
s=commit.read_text(encoding='utf-8')
if 'ROUND11_DERIVED_ZERO_REFERENCE_BEGIN' in s:
    if new not in s:
        raise SystemExit('Existing derived-key zero-reference differs; refusing edit.')
    new_commit=s
else:
    if s.count(old)!=1:
        raise SystemExit('Unexpected commitment.rs derived-key anchor; refusing edit.')
    new_commit=s.replace(old,new,1)

changes=[(tests,new_tests),(commit,new_commit)]
now=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
for path,text in changes:
    current=path.read_text(encoding='utf-8')
    if current!=text:
        backup=path.with_name(path.name+'.before_round11_'+now)
        shutil.copy2(path,backup)
        path.write_text(text,encoding='utf-8')
        print(f'Patched {path.relative_to(root)}; backup {backup.name}')
    else:
        print(f'Already installed {path.relative_to(root)}')
print('Only test module and audit-only zero-witness commitment arithmetic have changed.')
print('Run with --features scalar-commit-audit,derived-key and test filter:')
print('adversarial_attack_tests::test_round11_output_challenge_separation')
