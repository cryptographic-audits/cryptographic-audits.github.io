# PikkuFold 第十轮：原版验证器上的恶意 40 轮 sumcheck 集成（待本机执行）

**状态：实现与静态/整数检查已完成；本环境没有 Rust/Cargo，尚未得到 Rust 编译及运行结果。** 该包不能被称为“已成功伪造 Rust 证明”。请优先执行编译与 `m=2^10` 测试，观察第一条失败信息，确认后再上 `m=2^18`。

## 研究对象与限定

- 原始 `pikku-main(1).zip` 的 `pikku-fold-schemelet`，固定 Rokoko rev `64a9cd49d7d5281b0e174556662ec283e2eb8b3d`。
- 仅增加测试专用恶意 prover；**不改变** `verifier.rs`、`sumcheck.rs`、`fold.rs`、`projection.rs`、`transcript.rs` 的验证与随机性算法。
- 在测试特性 `scalar-commit-audit` 下，从原 `prover.rs`、`witness_stage.rs` 生成两份独立测试模块，替换三个 SIMD 操作：（1）第一层投影（由事先校验的核向量证明其结果为零）；（2）原 i16 batching→一般环系数的标量 batching；（3）AVX-512 witness MLE contraction→标量 `evaluate_column`。
- 原始 `HashWrapper` 生成三层投影矩阵、sumcheck 随机点和最终 folding 挑战；不注入预先选好的挑战。
- **测试目标 1：**真实 `verify_fold(m,instance,proof)` 接受一个具有非零恶意 sumcheck 消息、3 个完整输入声明与正常 rank 的 `FoldProof`。
- **测试目标 2（分开检查）：**从上一轮认证集挑出的一个挑战满足 `z*Lambda=0`，因此若最终挑战有此性质，零输出关系成立。本测试不会实际强制 SHAKE 命中这一低概率事件。
- 模块内的测试不生成零输出的最终 Fiat–Shamir 伪造 proof；也没有给出在线攻击成本。

## 安装（你的已修补 WSL2 工作目录）

先在 Windows 下载本包并解压，例如到 `~/pikkufold-lab/round10`。再运行：

```bash
cd ~/pikkufold-lab/original/pikku-main/pikku-fold-schemelet

python3 ~/pikkufold-lab/round10/install_adversarial_test.py \
  --test-module ~/pikkufold-lab/round10/adversarial_attack_tests.rs
```

这个命令会生成：

```text
src/adversarial_attack.rs
src/witness_stage_attack.rs
src/adversarial_attack_tests.rs
```

并只在 `src/main.rs` 注册三个 `#[cfg(all(test, feature="scalar-commit-audit"))]` 模块。已有文件改变时，安装器会拒绝覆盖；原有 `main.rs` 会备份。重复运行相同包应保持字节不变。

## 先编译，不运行任何测试

```bash
export CARGO_NET_GIT_FETCH_WITH_CLI=true
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export RUSTFLAGS="-C target-cpu=x86-64-v3"

cargo +nightly test --locked --features scalar-commit-audit --no-run \
  2>&1 | tee ~/pikkufold-lab/round10_compile.log
```

注意此前用户的 `scalar-commit-audit` 已实现标量 `verify_output` 与 `eval::mle_evaluate`；若工作目录没有这些补丁，安装器会拒绝执行。

## 再运行小维度，确认 prover/验证器的真实交互

```bash
set -o pipefail
PIKKU_ATTACK_LOG_M=10 cargo +nightly test --locked \
  --features scalar-commit-audit \
  adversarial_attack_tests::test_adversarial_40_rounds \
  -- --exact --nocapture --test-threads=1 \
  2>&1 | tee ~/pikkufold-lab/round10_small.log
```

通过后再在 16 GB 主机、WSL 7.6 GiB 限额下尝试 `m=2^18`：

```bash
PIKKU_ATTACK_LOG_M=18 cargo +nightly test --locked \
  --features scalar-commit-audit \
  adversarial_attack_tests::test_adversarial_40_rounds \
  -- --exact --nocapture --test-threads=1 \
  2>&1 | tee ~/pikkufold-lab/round10_40round.log
```

后者使用 `FOLD_INPUTS*m` 个 ring elements，内存需求明显高于零见证冒烟测试。先确保 WSL 可用内存足够，并且不要并行构建 Nova 等其他大型 Rust 项目。出现 SIGILL 时，用 GDB 捕获新的调用栈，不要把 SIGILL 当成代数拒绝。

## 判据与失败分层

依次应通过：

1. `Lambda^2=Lambda` 与 `(X^2-BETA)*Lambda=0`；这确保环表示正确。
2. 实际 transcript 导出的第一层矩阵有 `J0*a=0` 且 `a0=1`。
3. test-only honest-computation-style 恶意 prover 产生正确轮数和非零多项式系数。
4. **原版 `verify_fold` 返回 `Ok`。** 这是最关键的、当前尚未执行的检查。
5. 其输出承诺为零、终端求值落在 `Lambda` 理想内。
6. 上一轮已认证的挑战 `z_good` 满足 `z_good*Lambda=0`；非零槽对照 `z_bad` 不满足。

这些检查分别区别“错误输入关系”“完整协议消息可接受”“条件挑战下输出关系可满足”。**第 4 项通过也不意味着随机 Fiat–Shamir 最终 challenge 必然有利。**

## 目前已有的外部证据

- 第九轮 WSL 运行：130,629 个候选、17,317 个认证接受、16,944 个 signed rotation 轨道、4,337,664 个合法零槽挑战。
- 本包 `static_certificate.py`：仅对单个已认证挑战的槽值、范数整数包络和定量比较进行独立复算。
- 按原论文的基本计数，非交互式真实随机挑战命中事件的理论下界是 `4337664/(2^23*binom(128,23))`；本次**没有**通过重复哈希实际观察如此低概率的事件。

## 已知开发风险

生成模块严格复制原始 sumcheck 状态机，减少协议时序差异，但由于没有在此环境编译，可能仍需修改 Rust 类型、借用或 API 兼容细节。另一个需实测的地方是 `RingElement` 对 even/odd 系数的内部排列；第一项环恒等式断言会在其不匹配时直接失败而非静默得出结论。用户应先返回第一条编译错误或者第一条失败断言，不应跳过它们。
