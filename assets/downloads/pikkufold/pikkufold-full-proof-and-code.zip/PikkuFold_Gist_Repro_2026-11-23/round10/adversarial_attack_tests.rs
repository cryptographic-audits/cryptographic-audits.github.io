//! Native 40-round malicious-transcript test for the ORIGINAL PikkuFold verifier.
//!
//! This is a *test-only* adversarial prover.  The ordinary verifier and the
//! ordinary Fiat-Shamir sampling path are unchanged.  A pre-certified zero-slot
//! challenge is examined separately: this test does not force the random oracle
//! to output a rare challenge and is NOT a practical FS proof forgery.
use crate::config::{commitment_rank, FOLD_INPUTS, FRESH_INPUTS, PROJECTION_ROWS};
use crate::adversarial_attack::prove_adversarial_fold;
use crate::projection::{projection_shape, sample_projection_matrices};
use crate::statement::{EvalClaim, Instance};
use crate::transcript::statement_transcript;
use crate::verifier::verify_fold;
use rokoko::common::config::MOD_Q;
use rokoko::common::init_common;
use rokoko::common::matrix::{HorizontallyAlignedMatrix, VerticallyAlignedMatrix};
use rokoko::common::projection_matrix::ProjectionMatrix;
use rokoko::common::ring_arithmetic::{Representation, RingElement};

const Q: u64 = (1u64<<50)-2687;
const BETA: u64 = 739582794740178;

fn mul(a:u64,b:u64)->u64 { ((a as u128*b as u128) % (Q as u128)) as u64 }
fn sub(a:u64,b:u64)->u64 { if a>=b {a-b} else {a+Q-b} }
fn add(a:u64,b:u64)->u64 { let v=a+b; if v>=Q {v-Q} else {v} }
fn exp(mut a:u64, mut n:u64)->u64 {
    let mut r=1u64;
    while n>0 { if n&1==1 { r=mul(r,a); } a=mul(a,a); n>>=1; }
    r
}
fn element_from_even_powers(values:&[(usize,u64)])->RingElement {
    let mut v=RingElement::zero(Representation::IncompleteNTT);
    v.from_incomplete_ntt_to_even_odd_coefficients();
    for &(index,coeff) in values {
        assert!(index<64);
        v.v[index]=coeff;
    }
    v.from_even_odd_coefficients_to_incomplete_ntt_representation();
    v
}
fn lambda()->RingElement {
    assert_eq!(MOD_Q,Q);
    assert_eq!(exp(BETA,64),Q-1);
    assert_eq!(exp(BETA,128),1);
    // Lambda(X)=(1/64)*sum_{t=0}^{63} BETA^{-t} X^{2t}.
    let inv_beta=exp(BETA,Q-2);
    let inv_64=exp(64,Q-2);
    let mut p=1u64;
    let mut coefficients=Vec::with_capacity(64);
    for t in 0..64 { coefficients.push((t,mul(inv_64,p))); p=mul(p,inv_beta); }
    let l=element_from_even_powers(&coefficients);
    let zero=RingElement::zero(Representation::IncompleteNTT);
    let one=RingElement::constant(1,Representation::IncompleteNTT);
    assert_ne!(l,zero); assert_ne!(l,one);
    let mut square=zero.clone(); square*=(&l,&l);
    assert_eq!(square,l,"CRT projector must be an idempotent");
    let x2=element_from_even_powers(&[(1,1)]);
    let mut left=zero.clone(); left*=(&x2,&l);
    let mut right=zero.clone(); right*=(&RingElement::constant(BETA,Representation::IncompleteNTT),&l);
    assert_eq!(left,right,"Lambda must live only in X^2-BETA CRT slot");
    l
}
fn ternary_at(m:&ProjectionMatrix,row:usize,col:usize)->i8 {
    let (pos,nz)=m.row_chunks(row);
    let b=col>>3; let bit=col&7;
    if (nz[b]>>bit)&1==0 {0} else if (pos[b]>>bit)&1==1 {1} else {-1}
}

/// Solve J0*(1,a1,...)=0 over F_q, using the actual transcript-derived JL matrix.
/// The first 512 extra columns suffice with overwhelming probability.
fn kernel_with_fixed_first(matrix:&ProjectionMatrix)->Vec<u64> {
    let rows=matrix.projection_height;
    assert_eq!(rows,PROJECTION_ROWS);
    let cols=(matrix.projection_height*matrix.projection_ratio-1).min(512);
    assert!(cols>=rows);
    let rhs=cols;
    let mut a=vec![vec![0u64;cols+1];rows];
    for i in 0..rows {
        a[i][rhs]=match ternary_at(matrix,i,0) {1=>Q-1,-1=>1,_=>0};
        for j in 0..cols {
            a[i][j]=match ternary_at(matrix,i,j+1) {1=>1,-1=>Q-1,_=>0};
        }
    }
    let mut pivots=Vec::with_capacity(rows);
    for col in 0..cols {
        if pivots.len()==rows {break;}
        let r=pivots.len();
        let mut pivot=r;
        while pivot<rows && a[pivot][col]==0 {pivot+=1;}
        if pivot==rows {continue;}
        a.swap(pivot,r);
        let inv=exp(a[r][col],Q-2);
        for c in col..=rhs {a[r][c]=mul(a[r][c],inv);}
        for i in r+1..rows {
            let factor=a[i][col];
            if factor==0 {continue;}
            for c in col+1..=rhs {
                a[i][c]=sub(a[i][c],mul(factor,a[r][c]));
            }
            a[i][col]=0;
        }
        pivots.push(col);
    }
    assert_eq!(pivots.len(),rows,"first 512 extra columns were not full rank; try a different public statement seed");
    let mut coeff=vec![0u64;cols+1];
    coeff[0]=1;
    let mut x=vec![0u64;cols];
    for i in (0..rows).rev() {
        let c=pivots[i];
        let mut value=a[i][rhs];
        for j in c+1..cols { if x[j]!=0 && a[i][j]!=0 {value=sub(value,mul(a[i][j],x[j]));} }
        x[c]=value;
    }
    coeff[1..].copy_from_slice(&x);
    for row in 0..rows {
        let mut image=0u64;
        for (col,&v) in coeff.iter().enumerate() {
            image=match ternary_at(matrix,row,col) {
                1=>add(image,v),-1=>sub(image,v),_=>image,
            };
        }
        assert_eq!(image,0,"actual J0 kernel certificate failed on row {row}");
    }
    println!("PASS exact transcript-derived J0 kernel: {} rows, {} coefficients",rows,coeff.len());
    coeff
}

// A pre-certified challenge from Round 9's complete rational-norm certificate.
// Its 23 nonzero coefficients lie at the even X degrees 2*POSITION.
const GOOD_POS:[usize;23]=[
    1,4,5,6,9,13,16,21,22,23,24,25,33,34,35,37,41,42,48,55,58,60,62,
];
const GOOD_SIGN:[i8;23]=[
    1,-1,-1,-1,1,1,1,-1,1,-1,1,1,1,-1,-1,1,1,1,-1,-1,-1,1,1,
];
fn challenge_galois(power:usize)->RingElement {
    let mut data=Vec::new();
    for i in 0..23 {
        let x_degree=(2*GOOD_POS[i]*power)%256;
        let neg=x_degree>=128;
        let idx=(x_degree%128)/2;
        let positive=(GOOD_SIGN[i]>0)^neg;
        data.push((idx,if positive {1} else {Q-1}));
    }
    assert_eq!(data.len(),23);
    element_from_even_powers(&data)
}

#[test]
fn test_adversarial_40_rounds() {
    init_common();
    let log_m=std::env::var("PIKKU_ATTACK_LOG_M").ok()
        .and_then(|s| s.parse::<usize>().ok()).unwrap_or(10);
    assert!((10..=18).contains(&log_m),"start with log_m=10; then test 18");
    let m=1usize<<log_m;
    let zero=RingElement::zero(Representation::IncompleteNTT);
    let l=lambda();
    let rank=commitment_rank(m);
    let mut claims=(0..FOLD_INPUTS).map(|_| EvalClaim {
        point: vec![zero.clone();log_m],value:zero.clone()
    }).collect::<Vec<_>>();
    claims[0].value=l.clone();
    let instance=Instance {
        commitment: HorizontallyAlignedMatrix {
            data:vec![zero.clone();rank*FOLD_INPUTS],width:FOLD_INPUTS,height:rank
        },claims
    };
    assert_eq!(instance.claims.len(),3);
    let ratios=projection_shape(m).expect("shape");
    let mut transcript=statement_transcript(m,&instance);
    let matrices=sample_projection_matrices(&ratios,&mut transcript);
    let a=kernel_with_fixed_first(&matrices[0]);
    let mut witness=VerticallyAlignedMatrix {
        data:vec![zero.clone();FOLD_INPUTS*m],width:FOLD_INPUTS,height:m,used_cols:FOLD_INPUTS
    };
    for (j,&coef) in a.iter().enumerate() {
        let scalar=RingElement::constant(coef,Representation::IncompleteNTT);
        let mut value=zero.clone(); value*=(&l,&scalar);
        witness.data[j]=value;
    }
    assert_eq!(witness.col(0)[0],l);
    assert!(witness.col(1).iter().all(|x|x==&zero));
    assert!(witness.col(2).iter().all(|x|x==&zero));
    println!("Generating true adversarial sumcheck for m=2^{log_m} (not a zero transcript)");
    let proof=prove_adversarial_fold(m,&instance,&witness)
        .expect("test-only malicious prover should construct a proof");
    let expected_rounds=match log_m {18=>40,10=>28,_=>{
        let input=(FRESH_INPUTS*m).ilog2() as usize;
        let middle=input-ratios[0].ilog2() as usize;
        input+middle+PROJECTION_ROWS.ilog2() as usize
    }};
    assert_eq!(proof.round_polynomials.len(),expected_rounds);
    assert!(proof.round_polynomials.iter().any(|pair|pair.iter().any(|x| x.coeffs!=[0,0])),
        "attack must contain nonzero sumcheck messages");
    let output=verify_fold(m,&instance,&proof)
        .expect("unchanged original verify_fold rejected the malicious transcript");
    assert_eq!(output.folded_commitment.len(),rank);
    assert!(output.folded_commitment.iter().all(|value|value==&zero));
    assert_eq!(output.folded_claim.point.len(),log_m);
    let mut in_ideal=zero.clone();
    in_ideal*=(&l,&output.folded_claim.value);
    assert_eq!(in_ideal,output.folded_claim.value,
        "terminal malicious value must stay in target CRT ideal");

    let good=challenge_galois(1);
    let bad=challenge_galois(3);
    let mut good_product=zero.clone(); good_product*=(&good,&l);
    let mut bad_product=zero.clone(); bad_product*=(&bad,&l);
    assert_eq!(good_product,zero,"certified zero-slot challenge should annihilate Lambda");
    assert_ne!(bad_product,zero,"negative-control challenge should not annihilate Lambda");
    let mut conditional_output=zero.clone();
    conditional_output*=(&good,&output.folded_claim.value);
    assert_eq!(conditional_output,zero,"good z makes zero-output evaluation valid");
    println!("PASS: real original verify_fold accepted {expected_rounds} malicious sumcheck rounds, rank={rank}");
    println!("CRITICAL SCOPE: zero-slot challenge is a separate conditional algebra check;");
    println!("normal SHAKE/Fiat-Shamir fold challenge was NOT overridden and not claimed favorable.");
}
