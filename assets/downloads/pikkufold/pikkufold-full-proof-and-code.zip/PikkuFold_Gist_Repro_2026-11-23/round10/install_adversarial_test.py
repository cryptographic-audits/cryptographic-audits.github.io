#!/usr/bin/env python3
"""Generate an opt-in independent malicious-witness prover from this exact PikkuFold source.

Does not edit verifier.rs, sumcheck.rs, projection.rs, transcript.rs, or fold.rs.
It derives its test-only prover from original sources to preserve their logic and
replaces only SIMD witness preprocessing, SIMD witness contraction, and the folded
witness output.  Fails closed if source anchors change.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, shutil, sys

parser=argparse.ArgumentParser()
parser.add_argument('--test-module',type=Path,required=True)
args=parser.parse_args()
root=Path.cwd(); src=root/'src'
if not (src/'prover.rs').is_file() or not (src/'witness_stage.rs').is_file():
    sys.exit('Run from original pikku-fold-schemelet crate directory.')
if 'scalar-commit-audit = []' not in (root/'Cargo.toml').read_text():
    sys.exit('Install previous scalar-commit-audit feature first.')

original_p=(src/'prover.rs').read_text()
original_w=(src/'witness_stage.rs').read_text()

p=original_p

def replace_once(content,a,b,where):
    if content.count(a)!=1: raise ValueError(f'{where}: expected one anchor, got {content.count(a)}: {a[:90]!r}')
    return content.replace(a,b,1)

p=replace_once(p,'use crate::witness_stage::run_witness_stage;',
                 'use crate::witness_stage_attack::run_witness_stage_attack;\nuse crate::prover::FoldProof;', 'prover import')
begin=p.index('#[derive(Clone)]\npub(crate) struct FoldProof {')
end=p.index('// Rounds over the internal boundary variables.',begin)
p=p[:begin]+p[end:]
p=replace_once(p,'pub(crate) fn prove_fold(', 'pub(crate) fn prove_adversarial_fold(', 'function name')
p=replace_once(p,') -> Result<ProverMessage, String> {',') -> Result<FoldProof, String> {', 'return type')
p=replace_once(p,
'''    let (mut levels, projection_trace, witness_16) = project_witness(witness, &matrices);''',
'''    // The test independently checks J_0 * a = 0, so every actual image is zero.
    // This avoids invoking the short-i16/AVX-512 projection implementation.
    let zero = RingElement::zero(Representation::IncompleteNTT);
    let image0_height = FRESH_INPUTS * m / coarse_ratios[0];
    let image1_height = image0_height / coarse_ratios[1];
    assert_eq!(image1_height, matrices[PROJECTION_LAYERS - 1].projection_height);
    let mut levels: Vec<VerticallyAlignedMatrix<RingElement>> = [image0_height, image1_height]
        .iter().map(|&height| VerticallyAlignedMatrix {
            data: vec![zero.clone(); height], width: 1, height, used_cols: 1,
        }).collect();
    let projection_trace = vec![zero.clone(); crate::projection::TRACE_RING_LEN];''', 'project_witness replacement')
p=replace_once(p,'    let stage = run_witness_stage(', '    let stage = run_witness_stage_attack(', 'witness stage call')
p=replace_once(p,'        &witness_16,\n','', 'remove short witness arg')
p=replace_once(p,
'''    let fold_start = std::time::Instant::now();
    let challenges = fold_challenges(&mut transcript);
    let folded_witness = fold_witness(witness, &challenges);
    let fold_time = fold_start.elapsed();
    Ok(ProverMessage {
        proof: FoldProof {
            projection_trace,
            batched_projection,
            round_polynomials,
            terminal_values,
        },
        folded_witness,
        timings: ProverTimings {
            projection: projection_time,
            sumcheck: sumcheck_time,
            fold: fold_time,
        },
    })''',
'''    // No folding output is synthesized here: the REAL verifier derives z from
    // the completed transcript.  A zero output exists only for a zero-slot z.
    Ok(FoldProof { projection_trace, batched_projection, round_polynomials, terminal_values })''', 'remove native fold_pass')
p='// GENERATED TEST-ONLY DERIVATIVE of original src/prover.rs.\n// The original verifier and Fiat-Shamir sampling are not changed.\n'+p

w=original_w
w=replace_once(w,'use crate::ifma::{contract_pass, dot_rows_pass, DEGREE};','// no IFMA: all witness operations here are scalar', 'witness ifma')
w=replace_once(w,'use crate::vnni::{contract_i16, dot_rows_i16};','// no VNNI', 'witness vnni')
w=replace_once(w,'use rokoko::protocol::project_coarse::Signed16RingElement;','', 'witness i16 import')
w=replace_once(w,'pub(crate) fn run_witness_stage(', 'pub(crate) fn run_witness_stage_attack(', 'witness fn')
w=replace_once(w,'    witness_16: &[Signed16RingElement],\n','', 'witness no i16')
w=replace_once(w,
'''    let [d0, d1] = SlotBatcher::coefficient_rows(delta);
    let [p0, p1] = SlotBatcher::coefficient_rows(&delta_proj);
    let rows: [[u64; DEGREE]; 4] = [d0, d1, p0, p1];
    let [f0, f1, q0, q1] = unsafe { dot_rows_i16(witness_16, &rows) };
    let [a0, a1] = unsafe { dot_rows_pass(witness.col(ACCUMULATOR_COL), &delta_batcher.rows()) };''',
'''    // Exact portable slot batching of GENERAL RingElement data, including
    // coefficients that cannot be represented by i16.  Skipping zero ring
    // elements is an algebraically exact optimization for sparse test witnesses.
    let zero = RingElement::zero(rokoko::common::ring_arithmetic::Representation::IncompleteNTT);
    let mut f0 = vec![0u64; FRESH_INPUTS*m];
    let mut f1 = vec![0u64; FRESH_INPUTS*m];
    let mut q0 = vec![0u64; FRESH_INPUTS*m];
    let mut q1 = vec![0u64; FRESH_INPUTS*m];
    for col in 0..FRESH_INPUTS {
        for (idx, element) in witness.col(col).iter().enumerate() {
            if element == &zero { continue; }
            let d = delta_batcher.apply(element);
            let p = proj_batcher.apply(element);
            let j = col*m+idx;
            f0[j]=d.coeffs[0]; f1[j]=d.coeffs[1];
            q0[j]=p.coeffs[0]; q1[j]=p.coeffs[1];
        }
    }
    let mut a0=vec![0u64;m];
    let mut a1=vec![0u64;m];
    for (i, element) in witness.col(ACCUMULATOR_COL).iter().enumerate() {
        if element == &zero { continue; }
        let d=delta_batcher.apply(element);
        a0[i]=d.coeffs[0]; a1[i]=d.coeffs[1];
    }''','portable batching')
w=replace_once(w,
'''    let alpha = embed_qe(&QuadraticExtension { coeffs: [0, 1] });
    let mut partial: Vec<Vec<RingElement>> = unsafe { contract_i16(witness_16, &low_eq, &alpha) }
        .chunks_exact(block_eq.len() / FRESH_INPUTS)
        .map(|column| column.to_vec())
        .collect();
    partial.push(unsafe { contract_pass(witness.col(ACCUMULATOR_COL), &low_eq, &alpha) });''',
'''    // Scalar replacement for both VNNI contract_i16 and IFMA contract_pass.
    // QeVec is ordered in MS-first lexicographic order; each low block is
    // contracted with exactly the same equality vector as the original code.
    let chunks_per_col = block_eq.len() / FRESH_INPUTS;
    let low_width = low_eq.len();
    assert_eq!(chunks_per_col * low_width, m);
    let mut partial: Vec<Vec<RingElement>> = Vec::with_capacity(FOLD_INPUTS);
    for col in 0..FOLD_INPUTS {
        let mut reduced = Vec::with_capacity(chunks_per_col);
        for top in 0..chunks_per_col {
            let start=top*low_width;
            let end=start+low_width;
            let values=&witness.col(col)[start..end];
            if values.iter().all(|x| x==&zero) {
                reduced.push(zero.clone());
            } else {
                reduced.push(evaluate_column(values, &low_eq));
            }
        }
        partial.push(reduced);
    }''','portable low contraction')
w='// GENERATED TEST-ONLY DERIVATIVE of original src/witness_stage.rs.\n// Changes restricted to the SIMD witness batching and contraction.\n'+w

mod=args.test_module.read_text()
if 'test_adversarial_40_rounds' not in mod:
    raise ValueError('Unexpected test module content')

extra='''
#[cfg(all(test, feature = "scalar-commit-audit"))]
mod witness_stage_attack;
#[cfg(all(test, feature = "scalar-commit-audit"))]
mod adversarial_attack;
#[cfg(all(test, feature = "scalar-commit-audit"))]
mod adversarial_attack_tests;
'''
main=(src/'main.rs').read_text()
if 'mod adversarial_attack_tests;' not in main:
    main+=extra

outputs=[(src/'witness_stage_attack.rs',w),(src/'adversarial_attack.rs',p),
         (src/'adversarial_attack_tests.rs',mod),(src/'main.rs',main)]
# Fail-closed, do not overwrite independently changed artifacts.
for path, data in outputs:
    if path.exists() and path.name not in ('main.rs',) and path.read_text()!=data:
        raise ValueError(f'Existing {path} differs; refusing to overwrite')
for path,data in outputs:
    if path.exists() and path.read_text()!=data:
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        shutil.copy2(path,path.with_name(path.name+'.before_attack_test_'+stamp))
    path.write_text(data)
    print('Installed',path.relative_to(root),len(data),'bytes')
print('Compile/run the single malicious-transcript test with --features scalar-commit-audit')
