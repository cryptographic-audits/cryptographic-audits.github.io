"""Exact-strong modulus and deterministic rejection-cardinality certificates.
No Monte Carlo. Parameter search uses mpmath; every reported probability lower
bound is recertified using python-flint Arb. Prime verified by full Lucas certificate.
"""
from pathlib import Path
from math import comb, isqrt
from flint import arb,ctx,fmpq
import mpmath as mp
import sympy as sp
import json
ctx.prec=160; mp.mp.dps=50
N=128
root=Path(__file__).resolve().parents[1]
q=2**50-3
while not sp.isprime(q): q-=8
factors=sp.factorint(q-1)
# A primitive root modulo q with complete factorization of q-1 certifies primality:
# order of g modulo every prime divisor of q is q-1, hence that divisor >=q.
g=2
while not (pow(g,q-1,q)==1 and all(sp.gcd(pow(g,(q-1)//int(r),q)-1,q)==1 for r in factors)):g+=1
assert all(int(p)>=2 and all(int(p)%d for d in range(2,isqrt(int(p))+1)) for p in factors)
assert sp.n_order(q,256)==64 and q%8==5
result={'n':N,'q':q,'distance_below_2pow50':2**50-q,'q_mod_8':q%8,'slot_degree':64,'slot_count':2,'subfield_degree_a':2,'primality_certificate':{'full_factorization_q_minus_1':{str(k):int(v) for k,v in factors.items()},'Lucas_witness':g,'pow_g_q_minus_1':pow(g,q-1,q),'gcd_checks':{str(r):int(sp.gcd(pow(g,(q-1)//int(r),q)-1,q)) for r in factors}},'scans':[]}

def choose(s,gamma):
 best=None
 for M in range(4,33,2):
  c=mp.cos(mp.pi/M); x=mp.mpf(gamma)*c/s
  if x>=1:continue
  try: t=mp.findroot(lambda t:mp.besseli(1,t)/mp.besseli(0,t)-x,(mp.mpf('.1'),mp.mpf('4')))
  except ValueError: continue
  t=mp.mpf(round(t*1000))/1000
  u=(N//2)*M*mp.exp(-t*mp.mpf(gamma)*c)*mp.besseli(0,t)**s
  if best is None or u<best[0]:best=(u,M,t)
 return best

def certify(s,gamma):
 predicted,M,t=choose(s,gamma)
 T=arb(str(t)); G=arb(gamma); pi=arb.pi(); c=(pi/M).cos()
 total=arb(0)
 for j in range(M):
  theta=2*pi*j/M
  avg=sum(((T*(pi*p/N-theta).cos()).cosh() for p in range(N)),arb(0))/N
  total+=avg**s
 U=(N//2)*(-T*G*c).exp()*total
 p=1-U
 # To make the cardinality check an elementary exact integer inequality,
 # round the proven lower bound down to a rational with denominator 1e9.
 pnum=max(0,int(float(p.lower())*10**9)-1)
 p_rat=arb(fmpq(pnum,10**9))
 if pnum: assert p_rat<p
 base=2**s*comb(N,s)
 accepted_integer_lower=(base*pnum+10**9-1)//10**9
 bits=arb(accepted_integer_lower).log()/arb(2).log() if accepted_integer_lower else None
 row={'s':s,'gamma':gamma,'directions_M':M,'t':str(t),'failure_upper_arb':str(U),'acceptance_lower_arb':str(p),'acceptance_lower_rational':[pnum,10**9],'base_cardinality':str(base),'accepted_cardinality_integer_lower':str(accepted_integer_lower),'accepted_bits_lower':str(bits) if bits is not None else None,'certifies_100_bits':accepted_integer_lower>=2**100,'certifies_128_bits':accepted_integer_lower>=2**128,'expected_attempts_upper':str(arb(10**9)/pnum) if pnum else None}
 return row
for s,gamma in [(23,x) for x in ['8.357','10','11','12','12.2','12.3','12.4','12.5','13','14']]+[(s,x) for s,x in [(21,'14'),(22,'12.5'),(24,'12.5'),(31,'15'),(32,'15'),(32,'16')]]:
 row=certify(s,gamma);result['scans'].append(row)
 print(s,gamma,'p>=',row['acceptance_lower_rational'][0]/1e9,'bits>=',row['accepted_bits_lower'],flush=True)
(root/'results'/'repair_exact_modulus.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('prime',q,'d',2**50-q,'factors',factors,'witness',g,flush=True)

# Simpler analytic route: pair directions separated by pi/2 to obtain
# A_theta(t) <= cosh(t/2)^2 <= exp(t^2/4), uniformly in theta.
# Both ensuing bounds are independently certified by Arb.
result['simple_scans']=[]
for s,gamma in [(23,x) for x in ['12.4','12.5','12.6','12.7','12.8','12.9','13','13.1','14']]+[(31,'15'),(32,'15')]:
 G=arb(gamma)
 best_h=None; best_c=None
 for M in range(4,41):
  r=G*(arb.pi()/M).cos()/s
  if not r<1:continue
  log_rate=(1+r)*(1+r).log()+(1-r)*(1-r).log()
  u_c=(N//2)*M*(-s*log_rate).exp()
  u_h=(N//2)*M*(-s*r*r).exp()
  if best_c is None or float(u_c.upper())<float(best_c[1].upper()):best_c=(M,u_c)
  if best_h is None or float(u_h.upper())<float(best_h[1].upper()):best_h=(M,u_h)
 row={'s':s,'gamma':gamma}
 for label,best in [('cosh',best_c),('hoeffding',best_h)]:
  M,U=best;p=1-U
  num=max(0,int(float(p.lower())*10**9)-1)
  if num:assert arb(fmpq(num,10**9))<p
  count=(2**s*comb(N,s)*num+10**9-1)//10**9
  row[label]={'M':M,'failure_upper_arb':str(U),'acceptance_lower_rational':[num,10**9],'accepted_cardinality_integer_lower':str(count),'accepted_bits_lower':str(arb(count).log()/arb(2).log()) if count else None,'certifies_100_bits':count>=2**100,'certifies_128_bits':count>=2**128}
 result['simple_scans'].append(row)
 print('simple',s,gamma,'cosh',row['cosh'],'hoeffding',row['hoeffding'],flush=True)
(root/'results'/'repair_exact_modulus.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
