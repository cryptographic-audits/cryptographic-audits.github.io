param(
    [Parameter(Mandatory = $true)][string]$BundlePath,
    [Parameter(Mandatory = $true)][ValidatePattern('^[0-9a-f]{40}$')][string]$SourceCommit
)
$ErrorActionPreference = 'Stop'
$bundleAbsolute = (Resolve-Path -LiteralPath $BundlePath).Path
$bundleSha = (Get-FileHash -LiteralPath $bundleAbsolute -Algorithm SHA256).Hash.ToLowerInvariant()
$bundlePayload = [Convert]::ToBase64String([IO.File]::ReadAllBytes($bundleAbsolute))
$remoteScript = @'
import base64, hashlib, json, subprocess
from pathlib import Path

base = Path('/root/rivermind-data/pikkufold-repair-lab')
if not base.is_dir():
    raise SystemExit('The explicitly provisioned workspace is missing')
commit = '__COMMIT__'
expected = '__SHA256__'
data = base64.b64decode('__PAYLOAD__', validate=True)
if hashlib.sha256(data).hexdigest() != expected:
    raise SystemExit('Bundle transport checksum mismatch')
bundle = base / 'bundles' / (commit + '.bundle')
release = base / 'releases' / commit
if bundle.exists():
    if bundle.read_bytes() != data:
        raise SystemExit('Refusing to overwrite a different existing bundle')
else:
    with bundle.open('xb') as stream:
        stream.write(data)
if release.exists():
    raise SystemExit('Release already exists; refusing to reuse a mutable checkout')
subprocess.run(['git', 'clone', '--branch', 'folding-reference', str(bundle), str(release)],
               check=True, timeout=60)
actual = subprocess.check_output(['git', '-C', str(release), 'rev-parse', 'HEAD'], text=True).strip()
if actual != commit:
    raise SystemExit('Unexpected source revision after clone')
status = subprocess.check_output(['git', '-C', str(release), 'status', '--porcelain'], text=True)
if status:
    raise SystemExit('Unexpected dirty checkout after clone')
record = {'release': str(release), 'source_commit': actual, 'bundle_sha256': expected,
          'source_verified_by': 'Git bundle clone, exact HEAD and clean working tree',
          'scope': 'Source staging only; no protocol execution'}
manifest = base / 'inventory' / (commit + '-deployment.json')
with manifest.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
'@
$remoteScript = $remoteScript.Replace('__COMMIT__', $SourceCommit).Replace('__SHA256__', $bundleSha).Replace('__PAYLOAD__', $bundlePayload)
$remoteScript | ssh gpuhome "python3 -"
if ($LASTEXITCODE -ne 0) { throw 'Remote Git bundle staging failed' }
