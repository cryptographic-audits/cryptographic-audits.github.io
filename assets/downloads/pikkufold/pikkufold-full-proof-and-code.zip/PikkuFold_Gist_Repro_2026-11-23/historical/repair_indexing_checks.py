"""Exact regression checks for the lexicographic MLE block convention.
No protocol implementation is exercised. No random sampling is used.
Run: python scripts/repair_indexing_checks.py
"""
from itertools import product
from pathlib import Path
import json

def nbits(n):
    assert n >= 1 and n & (n - 1) == 0
    return n.bit_length() - 1

def index_bits(i, width):
    assert 0 <= i < 1 << width
    return tuple((i >> (width-1-j)) & 1 for j in range(width))

def eq(a,b):
    assert len(a)==len(b)
    v=1
    for aj,bj in zip(a,b):
        v *= aj*bj+(1-aj)*(1-bj)
    return v

def mle(v,x):
    assert len(v)==1 << len(x)
    return sum(value*eq(index_bits(i,len(x)),x) for i,value in enumerate(v))

def mle_matrix(A,x,y):
    assert len(A)==1<<len(x) and all(len(row)==1<<len(y) for row in A)
    return sum(A[i][j]*eq(index_bits(i,len(x)),x)*eq(index_bits(j,len(y)),y)
               for i in range(len(A)) for j in range(len(A[0])))

def same(a,b,modulus):
    return a==b if modulus is None else (a-b)%modulus==0

def points(width):
    # Include every Boolean point and two non-Boolean points.
    return list(product((0,1),repeat=width))+[tuple(2+j for j in range(width)),tuple(-1-j for j in range(width))]

checks=0
cases=[]
for k,m in product((1,2,4,8),(1,2,4,8)):
    a,b=nbits(k),nbits(m)
    W=[[11*i+3*j-7 for j in range(m)] for i in range(k)]
    flat=[v for row in W for v in row]
    count=0
    for modulus in (None,17,15):
        for x,y in product(points(a),points(b)):
            # The paper's terminal reconstruction, using the same lex order.
            left=mle(flat,x+y)
            right=sum(eq(index_bits(i,a),x)*mle(W[i],y) for i in range(k))
            assert same(left,right,modulus)
            count+=1
        for i in range(k):
            for s in points(b):
                # Corrected Figure 2 block selection + input evaluation.
                left=sum(mle(flat,bits+inner)*eq(bits,index_bits(i,a))*eq(inner,s)
                         for bits in product((0,1),repeat=a)
                         for inner in product((0,1),repeat=b))
                assert same(left,mle(W[i],s),modulus)
                count+=1
        # Recover all vector entries exactly on the Boolean cube.
        for i in range(k):
            for j in range(m):
                bits=index_bits(i,a)+index_bits(j,b)
                assert bits==index_bits(i*m+j,a+b)
                assert same(mle(flat,bits),W[i][j],modulus)
                count+=1
    cases.append({'k':k,'m':m,'checks':count})
    checks+=count

# Identity-block layout used by the terminal layered-matrix evaluation.
matrix_checks=0
for r,n,m in product((1,2,4),(1,2,4),(1,2,4)):
    A=[[2*i-3*j+1 for j in range(m)] for i in range(n)]
    B=[[A[i%n][j%m] if i//n==j//m else 0 for j in range(r*m)] for i in range(r*n)]
    x0=tuple(j+2 for j in range(nbits(r)))
    y0=tuple(-j-1 for j in range(nbits(r)))
    x1=tuple(j+3 for j in range(nbits(n)))
    y1=tuple(-j-2 for j in range(nbits(m)))
    left=mle_matrix(B,x0+x1,y0+y1)
    right=eq(x0,y0)*mle_matrix(A,x1,y1)
    assert left==right
    matrix_checks+=1

# The prior counterexample becomes consistent after the selector correction.
flat=(0,1,2,3)
corrected=[sum(mle(flat,b)*eq(b,index_bits(i,2)) for b in product((0,1),repeat=2)) for i in range(4)]
assert corrected==list(flat)
old_permuted_claims=(0,2,1,3)
assert [i for i in range(4) if corrected[i]!=old_permuted_claims[i]]==[1,2]
result={'all_checks_passed':True,'case_count':len(cases),'block_checks':checks,
        'matrix_layout_checks':matrix_checks,'moduli':['integers',17,15],
        'cases':cases,'corrected_four_input_selection':corrected,
        'scope':'Deterministic regression tests of MLE identities; proofs are in protocol_repair.md.'}
out=Path(__file__).resolve().parents[1]/'results'/'repair_indexing_checks.json'
out.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))

