"""Exact finite coin-domain accounting for sampler lifting, not an FS proof.

Only existing certified rational sampler bounds are used. No oracle, hash or
protocol attack is implemented. Outputs do not claim SHAKE/ROM equivalence.
"""
from fractions import Fraction as F
from math import comb, log2
from pathlib import Path
import json


def ceil_fraction(x):
    return -(-x.numerator // x.denominator)


def bits(x):
    return log2(x.numerator) - log2(x.denominator)


n, s, eta = 128, 23, 12
N = 2**s * comb(n, s)
L_fw = (N-1).bit_length()
p_fw = F(91548697, 10**9)
Omega_fw = ceil_fraction(p_fw*N)
raw_density_fw = F(Omega_fw, 2**L_fw)
assert L_fw == 107
assert Omega_fw == 10593090179186648695925874708572
assert Omega_fw > 2**103

L_cbd = 2*eta*n
p_cbd = F(526413293, 10**9)
Omega_cbd = ceil_fraction(p_cbd * 2**L_cbd)
peak_coefficient = F(comb(2*eta,eta), 2**(2*eta))
base_collision_coefficient = F(comb(4*eta,2*eta), 2**(4*eta))
atom_upper = peak_coefficient**n / p_cbd
pair_equal_upper = min(atom_upper, base_collision_coefficient**n / p_cbd**2)
q_cbd = 2**50-2687
A_multiplier = F(1004337139,10**9)
b_cbd = 64*A_multiplier**2/(p_cbd*q_cbd**2)
assert b_cbd == F(13817713544858977,142831362764636918203799633204087166078125000)
assert Omega_cbd > 2**3071
assert atom_upper < b_cbd
assert pair_equal_upper <= atom_upper
assert 4*b_cbd < F(1,2**91)

# A fixed raw-bit cap is an explicit approximation/abort budget.
# CBD p>1/2 gives failure<2^-T; FW raw density>1/16 gives failure<(15/16)^T.
assert raw_density_fw > F(1,16)
T_fw = 1
while F(15,16)**T_fw > F(1,2**128):
    T_fw += 1
assert F(15,16)**T_fw <= F(1,2**128)

out = {
    'scope':'Finite coin-domain identities and exact conservative constants only; all other AAB/ROM obligations remain external.',
    'fixed_weight_exact_modulus': {
        'q':2**50-27,'weight':s,'gamma':'62/5',
        'base_cardinality':N,'raw_bits':L_fw,
        'p_base_norm_acceptance_lower':str(p_fw),
        'Omega_cardinality_lower':Omega_fw,
        'log2_Omega_lower':log2(Omega_fw),
        'raw_bits_acceptance_lower_exact':str(raw_density_fw),
        'raw_bits_acceptance_lower':float(raw_density_fw),
        'expected_raw_attempts_upper':float(1/raw_density_fw),
        'b_and_pair_equal_upper_exact':str(F(1,Omega_fw)),
        'two_distinct_coin_predicate_failure_density':0,
        'raw_cap_for_single_evaluation_abort_at_most_2_minus_128_using_density_1_over_16':T_fw,
    },
    'cbd_original_modulus': {
        'q':q_cbd,'eta':eta,'gamma':78,'raw_bits':L_cbd,
        'p_acceptance_lower_exact':str(p_cbd),
        'Omega_cardinality_lower':Omega_cbd,
        'log2_Omega_lower':log2(Omega_cbd),
        'expected_raw_attempts_upper':float(1/p_cbd),
        'decoded_max_atom_upper_exact':str(atom_upper),
        'decoded_max_atom_upper_bits':-bits(atom_upper),
        'two_independent_decoded_equal_upper_exact':str(pair_equal_upper),
        'two_independent_decoded_equal_upper_bits':-bits(pair_equal_upper),
        'fixed_anchor_nonunit_including_equal_upper_exact':str(b_cbd),
        'fixed_anchor_nonunit_upper_bits':-bits(b_cbd),
        'k2_AAB_inner_final_layer_upper_exact':str(2*b_cbd),
        'k2_AAB_inner_final_layer_upper_bits':-bits(2*b_cbd),
        'predicate_density_formula':'pch_2 <= b_D - 1/|Omega|, with ACTUAL |Omega|, not its lower bound',
        'raw_cap_128_bound':'per evaluation abort < 2^-128 from p>1/2',
    },
    'warning':'Cardinality lower bounds upper-bound 1/|Omega|; they must not be substituted into a subtracted 1/|Omega| term.',
}
path = Path(__file__).resolve().parents[1]/'repair-notes'/'rom_sampler_lifting.json'
path.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({
    'FW_log2_Omega_lower':out['fixed_weight_exact_modulus']['log2_Omega_lower'],
    'FW_raw_acceptance_lower':float(raw_density_fw),
    'FW_expected_raw_attempts_upper':float(1/raw_density_fw),
    'CBD_log2_Omega_lower':out['cbd_original_modulus']['log2_Omega_lower'],
    'CBD_decoded_max_atom_upper_bits':-bits(atom_upper),
    'CBD_pair_equal_upper_bits':-bits(pair_equal_upper),
    'CBD_fixed_anchor_bad_upper_bits':-bits(b_cbd),
    'k2_AAB_inner_final_layer_upper_bits':-bits(2*b_cbd),
    'FW_cap_using_density_1_over_16':T_fw,
},indent=2))
