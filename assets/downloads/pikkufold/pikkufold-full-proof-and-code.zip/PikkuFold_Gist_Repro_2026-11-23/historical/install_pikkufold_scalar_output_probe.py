#!/usr/bin/env python3
"""Install strictly opt-in scalar commitment checks for output semantics.

Run from the PikkuFold schemelet directory:
 python ~/pikkufold-lab/install_pikkufold_scalar_output_probe.py --module ~/pikkufold-lab/pikkufold_output_semantics_probe.rs

This modifies only Cargo.toml, src/commitment.rs, src/main.rs and writes
src/output_semantics_probe.rs. It creates timestamped backups of modified files.
The original AVX-512 implementation remains intact when the feature is OFF.
"""
import argparse
import datetime
from pathlib import Path
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--module', type=Path, required=True)
args = parser.parse_args()
root = Path.cwd()
assert (root / 'Cargo.toml').is_file() and (root / 'src/commitment.rs').is_file()
source = args.module.read_text(encoding='utf-8')
assert 'complete_output_accepts_correct_zero_opening' in source
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')

cargo = root / 'Cargo.toml'
comm = root / 'src/commitment.rs'
main = root / 'src/main.rs'
module = root / 'src/output_semantics_probe.rs'

c = cargo.read_text(encoding='utf-8')
needle = '[features]\n'
assert needle in c
if 'scalar-commit-audit' not in c:
    c_new = c.replace(needle, needle + 'scalar-commit-audit = []\n', 1)
else:
    c_new = c

s = comm.read_text(encoding='utf-8')
old = '''        let out = unsafe { commit_pass(&self.rows, self.height, self.rank, &[column]) };
        (out, Duration::ZERO)'''
new = '''        // Audit-only reference backend, selected explicitly by Cargo feature.
        // Default production builds preserve the original IFMA kernel.
        #[cfg(feature = "scalar-commit-audit")]
        {
            let mut out = vec![RingElement::zero(Representation::IncompleteNTT); self.rank];
            let mut product = RingElement::zero(Representation::IncompleteNTT);
            for row in 0..self.rank {
                for col in 0..self.height {
                    product *= (&self.rows[row * self.height + col], &column[col]);
                    out[row] += &product;
                }
            }
            return (out, Duration::ZERO);
        }
        #[cfg(not(feature = "scalar-commit-audit"))]
        {
            let out = unsafe { commit_pass(&self.rows, self.height, self.rank, &[column]) };
            (out, Duration::ZERO)
        }'''
if 'Audit-only reference backend' in s:
    s_new = s
else:
    assert s.count(old) == 1, 'Unexpected commitment.rs; refusing to patch'
    s_new = s.replace(old,new,1)

m = main.read_text(encoding='utf-8')
append = '\n#[cfg(all(test, feature = "scalar-commit-audit"))]\nmod output_semantics_probe;\n'
m_new = m if 'mod output_semantics_probe;' in m else m + append

for path, newtext in ((cargo,c_new),(comm,s_new),(main,m_new)):
    if path.read_text(encoding='utf-8') != newtext:
        backup = path.with_name(path.name + f'.before_scalar_audit_{stamp}')
        shutil.copy2(path,backup)
        path.write_text(newtext,encoding='utf-8')
        print('Patched',path.relative_to(root),'backup:',backup.name)
    else:
        print('Already set:',path.relative_to(root))
if module.exists() and module.read_text(encoding='utf-8') != source:
    raise RuntimeError('Refusing to overwrite existing different src/output_semantics_probe.rs')
module.write_text(source, encoding='utf-8')
print('Installed src/output_semantics_probe.rs')
print('Run: CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 RUSTFLAGS="-C target-cpu=x86-64-v3" cargo +nightly test --locked --features scalar-commit-audit output_semantics_probe:: -- --nocapture --test-threads=1')
