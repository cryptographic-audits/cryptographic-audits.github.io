"""Independent interval audit of PikkuFold Section 4; python-flint required.
All leaf inequalities use Arb balls at 128 bits. Box endpoints/centres are exact rationals.
The finite cover uses Phi and derivative formulas derived from Eq. (3), not author code.
"""
from flint import arb, fmpq, ctx
from pathlib import Path
from itertools import product
from math import comb, factorial
import json,time,sys
ctx.prec=128
out=Path(__file__).resolve().parents[1]/'results'/'jl_checks.json'
slo=arb('2.31057135675369424420')
shi=arb('2.31057135675369424421')
f=lambda x:(1+x)*(1+(-x).exp())**2-4
assert f(slo)<0 and f(shi)>0
s=arb('2.310571356753694244205 +/- 5.00000001e-21')
env=(1+(-s).exp())/2
mu=arb(fmpq(9,20)); mu2=fmpq(81,400)
pi=arb.pi()
tail=(pi/(2*mu*s.sqrt())).erfc()
psi=arb('0.5508')
assert env+tail < psi
kappa=1/(2*arb(1).erfc())
summary={'precision_bits':ctx.prec,'s_bracket':[str(slo),str(shi)],'env':str(env),'gaussian_tail':str(tail),'sum':str(env+tail),'table':[],'certificate':[]}
rows=[(64,'6.97','13.53','171.8',73,16,'7.34','5.37'),(96,'8.43','20.45','257.5',100,23,'8.83','5.99'),(128,'9.66','27.37','343.2',126,30,'10.08','6.53'),(192,'11.75','41.21','514.6',176,44,'12.20','7.44'),(256,'13.51','55.05','686.0',224,58,'13.98','8.22')]
for lam,g,al,be,b,T,D,r in rows:
 g,al,be,D,r=map(arb,[g,al,be,D,r]); ell=al.sqrt()
 single=kappa*g.erfc(); target=arb(2)**(-lam-1)/(2*lam)
 assert single<target
 # Exact p minimizer selected by (lam+p)/beta ratio.
 p=int(float(be))-lam+1
 ub=arb(factorial(lam+p-1)//factorial(lam-1))/be**p
 assert ub<arb(2)**(-lam-1)
 low=(al*s).exp()*psi**(2*lam)
 assert low<arb(2)**(-lam-1)
 binom_num=sum(comb(2*lam,i) for i in range(T))
 assert binom_num <= 2**lam
 A=r*D; C=D/(1-1/r**2).sqrt(); delta=arb('0.52')*arb(2).sqrt()/(r*r-1).sqrt(); tau=kappa*(D/2).erfc()
 bounds=[ell/(1-g/D),2*A*ell/arb(T).sqrt(),2*C*ell/(pi.sqrt()*(1/arb(2).sqrt()-2*delta-tau))]
 assert all(v<b for v in bounds)
 summary['table'].append({'lambda':lam,'single_row_margin_bits':str(-(single/target).log()/arb(2).log()),'upper_moment_p':p,'upper_tail_log2':str(ub.log()/arb(2).log()),'lower_tail_log2':str(low.log()/arb(2).log()),'binomial_log2':str(arb(fmpq(binom_num,2**(2*lam))).log()/arb(2).log()),'required_b_values':list(map(str,bounds))})
out.write_text(json.dumps(summary,indent=2),encoding='utf-8')
print('Table checks passed',flush=True)
M1=2*(s/pi).sqrt(); M2=2*s; M3=2*(2/pi).sqrt()*(2*s)**fmpq(3,2); M4=12*s*s
Lambda=(s/pi).sqrt()/(2*mu)+s/2
hdiag=M4/16+M3/(8*mu)+M2/(8*mu**2)+M1/(8*mu**3)
hoff=M4/16+M3/(8*mu)+M2/(16*mu**2)

def evaluate(c,terms):
 xs=[arb(v) for v in c]; ws=[x.sqrt() for x in xs]
 A=1+s*(1-sum(xs)); rootA=A.sqrt(); fval=arb(0); grad=[arb(0) for _ in xs]
 for sig,weight in terms:
  z=sum((w*v for w,v in zip(ws,sig)),arb(0)); t=weight*(-s*z*z/A).exp()/rootA
  fval+=t
  common=s/(2*A)-s*s*z*z/(A*A)
  for j in range(len(xs)):
   grad[j]+=t*(common-s*z*sig[j]/(A*ws[j]))
 return fval,grad

for d in (2,3,4):
 start=time.time(); H=hdiag+(d-1)*hoff
 terms=[]
 for sig in product((-1,0,1),repeat=d):
  den=1
  for v in sig: den*=2 if v==0 else 4
  terms.append((sig,arb(fmpq(1,den))))
 stack=[([mu2]*d,[1-(d-1)*mu2]*d)]
 nodes=leaves=discarded=0; maxub=0.0; minmargin=1.0
 while stack:
  lo,hi=stack.pop(); nodes+=1
  if sum(lo)>1: discarded+=1; continue
  hi=[min(h,1-sum(lo)+l) for h,l in zip(hi,lo)]
  mid=[(l+h)/2 for l,h in zip(lo,hi)]
  if sum(mid)>1:
   scale=(1-sum(lo))/(sum(mid)-sum(lo))
   c=[l+scale*(m-l) for l,m in zip(lo,mid)]
  else: c=mid
  assert all(l<=v<=h for l,v,h in zip(lo,c,hi)) and sum(c)<=1
  rad=[arb(max(v-l,h-v)) for l,v,h in zip(lo,c,hi)]
  fval,grad=evaluate(c,terms)
  rsum=sum(rad)
  ub1=fval+Lambda*rsum
  ub2=fval+sum(abs(g)*r for g,r in zip(grad,rad))+H*rsum*rsum/2
  # Each upper bound separately encloses a valid bound. Success means strict ball separation.
  if ub1<env or ub2<env:
   leaves+=1
   ub=min(float(ub1.upper()),float(ub2.upper()))
   maxub=max(maxub,ub)
   minmargin=min(minmargin,float(env.lower())-ub)
   continue
  if nodes>2000000: raise RuntimeError('node budget exceeded')
  j=max(range(d),key=lambda j:hi[j]-lo[j]); cut=(hi[j]+lo[j])/2
  hi1=hi.copy(); hi1[j]=cut
  lo2=lo.copy(); lo2[j]=cut
  stack.append((lo2,hi.copy())); stack.append((lo.copy(),hi1))
  if nodes%20000==0: print('d',d,'nodes',nodes,'pending',len(stack),flush=True)
 result={'d':d,'nodes':nodes,'leaves':leaves,'discarded':discarded,'max_accepted_bound_display_float':maxub,'min_margin_display_float':minmargin,'elapsed_seconds':time.time()-start,'all_leaf_comparisons':'strict Arb interval comparisons'}
 summary['certificate'].append(result)
 out.write_text(json.dumps(summary,indent=2),encoding='utf-8')
 print(result,flush=True)
