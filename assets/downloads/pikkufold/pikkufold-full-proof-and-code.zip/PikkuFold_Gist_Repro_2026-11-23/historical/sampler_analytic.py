"""Exact, offline arithmetic for the PikkuFold sampler audit.

No Monte Carlo, FFT, or external service is used.  Floating point appears
only in human-readable logarithms of already established rational bounds.
Run: python -X utf8 scripts/sampler_analytic.py
"""
from fractions import Fraction
from math import comb, log2, gcd
from pathlib import Path
import json


def log2_fraction(x):
    return log2(x.numerator) - log2(x.denominator)


def ceil_div(a, b):
    return (a + b - 1) // b


def prime_by_trial(n):
    if n < 2:
        return False
    d = 2
    while d * d <= n:
        if n % d == 0:
            return False
        d += 1
    return True


def main():
    # Exact rational inequalities supporting the short-arc proof.
    # The standard elementary bound 3.14 < pi gives both grid bounds.
    cos_upper = 1 - Fraction(1, 98) + Fraction(1, 24 * 2401)
    assert cos_upper < Fraction(99, 100)
    assert Fraction(2048, 1) / (7 * Fraction(314, 100)) < 94
    assert Fraction(256, 1) / (7 * Fraction(314, 100)) < 12
    assert prime_by_trial(257)
    assert pow(257, 8, 2048) == 1
    assert all(pow(257, j, 2048) != 1 for j in range(1, 8))

    q, n, s, e = 257, 1024, 7, 8
    full = 2**s * comb(n, s)
    sub = 2**s * comb(n // e, s)
    prediction = Fraction(n // e, q**e)
    assert full >= q**e
    base_numerator = ceil_div(sub, q) - 1
    base_bound = Fraction(base_numerator, full)

    # There are n/2 distinct embeddings up to complex conjugation.
    # A bad challenge maps its seven signed positions into one arc.
    # Choose the first grid point (2*n possibilities) then six points
    # within the next L positions.  Dropping the no-antipodes constraint
    # only enlarges this union bound.
    rejected_full = (n // 2) * (2 * n) * comb(93, 6)
    m = n // e
    rejected_sub = (m // 2) * (2 * m) * comb(11, 6)
    accepted_full_lower = full - rejected_full
    accepted_sub_lower = sub - rejected_sub
    assert accepted_full_lower > q**e
    numerator = ceil_div(accepted_sub_lower, q) - 1
    bound = Fraction(numerator, full)

    # Nonempty rejection set: real part of 1+z+...+z^6 for
    # z=exp(pi*i/1024), using cos(t)>=1-t^2/2 and pi<22/7.
    witness_real_lower = 7 - Fraction(91, 2 * 1024**2) * Fraction(22, 7)**2
    assert witness_real_lower > Fraction(699, 100)

    q_actual = 2**50 - 2687
    # Elementary Pocklington certificate.  A prime divisor p of q must
    # have ord_p(2) divisible by r, hence p >= r+1 > sqrt(q).
    r = 13470280279
    assert prime_by_trial(r)
    assert q_actual - 1 == 128 * 653 * r
    assert r * r > q_actual
    assert pow(2, q_actual - 1, q_actual) == 1
    assert gcd(pow(2, (q_actual - 1) // r, q_actual) - 1, q_actual) == 1
    assert q_actual % 256 == 129
    full_actual = 2**23 * comb(128, 23)
    sub_actual = 2**23 * comb(64, 23)
    # If p_T exceeds this sufficient threshold, then
    # (p_T*T/q - 1)/C > 64/q^2.  This is not an estimate of p_T.
    threshold = Fraction(q_actual, sub_actual) + Fraction(
        64 * full_actual, q_actual * sub_actual
    )
    conditional_bound = (Fraction(sub_actual, 10 * q_actual) - 1) / full_actual

    result = {
        'proof_basis': 'Exact integers/rationals; pi bounds 3.14<pi<22/7; see audit/sampler_math.md',
        'gamma7': {
            'C': full, 'T': sub, 'q_to_e': q**e,
            'epsilon_numerator': base_numerator, 'epsilon_denominator': full,
            'log2_epsilon_lower_bound': log2_fraction(base_bound),
            'log2_heuristic_prediction': log2_fraction(prediction),
            'factor_above_prediction': float(base_bound / prediction),
        },
        'gamma6_99_stronger_bound': {
            'full_rejected_upper': rejected_full,
            'subfamily_rejected_upper': rejected_sub,
            'C_accepted_lower': accepted_full_lower,
            'T_accepted_lower': accepted_sub_lower,
            'epsilon_numerator': numerator, 'epsilon_denominator': full,
            'log2_epsilon_lower_bound': log2_fraction(bound),
            'factor_above_prediction': float(bound / prediction),
            'rejected_witness_real_part_lower': str(witness_real_lower),
        },
        'actual_parameters_conditional': {
            'q': q_actual, 'q_mod_256': q_actual % 256,
            'C_base': full_actual, 'T_base': sub_actual,
            'log2_C_base': log2(full_actual), 'log2_T_base': log2(sub_actual),
            'p_T_sufficient_to_exceed_prediction_exact': str(threshold),
            'p_T_sufficient_to_exceed_prediction': float(threshold),
            'p_C_required_for_H1_cardinality': float(Fraction(q_actual**2, full_actual)),
            'log2_epsilon_lower_IF_p_T_ge_0_1': log2_fraction(conditional_bound),
            'status': 'Conditional only: this script proves no unconditional lower bound on actual p_T.',
        },
    }
    out = Path(__file__).resolve().parents[1] / 'results' / 'sampler_analytic.json'
    out.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
