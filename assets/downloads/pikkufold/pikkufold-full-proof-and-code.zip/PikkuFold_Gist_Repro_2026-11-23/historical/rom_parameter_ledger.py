"""Exact rational-interval ROM norm ledger; no lattice hardness estimator.

All '<q' and Tmax decisions are certified with rational endpoints. Decimal
printing is only presentation. Inputs are the formulas explicitly requested
for a zero initial accumulator, k=2 and three identical JL ratio layers.
"""
from fractions import Fraction as F
from math import isqrt
from decimal import Decimal, localcontext
from pathlib import Path
import json


def sqrt_enclosure(x, digits=40):
    scale=10**digits
    floor=isqrt((x.numerator*scale*scale)//x.denominator)
    lo,hi=F(floor,scale),F(floor+1,scale)
    assert lo*lo<=x<hi*hi
    return lo,hi


def scale(a,x):
    assert a>=0
    return a*x[0],a*x[1]


def add(x,y):
    return x[0]+y[0],x[1]+y[1]


def mul(x,y):
    assert x[0]>=0 and y[0]>=0
    return x[0]*y[0],x[1]*y[1]


def max_interval(x,y):
    return max(x[0],y[0]),max(x[1],y[1])


def decimal(x,digits=18):
    with localcontext() as ctx:
        ctx.prec=digits+10
        return format(Decimal(x.numerator)/Decimal(x.denominator),f'.{digits}g')


def encode(x):
    return {'lower':str(x[0]),'upper':str(x[1]),
            'midpoint_display':decimal((x[0]+x[1])/2)}


sqrt2=sqrt_enclosure(F(2))
R_squared=F(34320,2737)**3
R=sqrt_enclosure(R_squared)
assert R[0]>44
k,T=2,32
routes=[
 ('original_H1_reference',F(8357,1000),(1<<50)-2687,
  'Norm reference only; H1 sampler guarantee is not certified.'),
 ('exact_modulus',F(62,5),(1<<50)-27,
  'Certified strong sampler; no complete SIS/ROM security claim.'),
 ('original_modulus_CBD12',F(78),(1<<50)-2687,
  'Certified CBD12 sampler; no complete SIS/ROM security claim.'),
]


def caps(gamma,beta,t):
    assert t>=1
    final=scale(t*k*gamma,beta)
    delta=scale(k*gamma,mul(R,beta))
    first=add(final,scale(t-1,delta))
    # Check the requested closed form with common dependencies preserved.
    closed=scale(k*gamma,mul(beta,add((F(t),F(t)),scale(t-1,R))))
    assert first==closed
    single_first=scale(8*gamma,first)
    single_second=scale(2*(k+1)*(2*gamma)**k,first)
    two_second=scale(2,add(first,delta))
    return {'B_T':final,'delta_back_per_fold':delta,'B_first':first,
            'single_fresh_term':single_first,'single_acc_term':single_second,
            'single_radius':max_interval(single_first,single_second),
            'two_fresh_term':single_first,'two_acc_term':two_second,
            'two_radius':max_interval(single_first,two_second)}


def classify(x,q):
    if x[1]<q:return True
    if x[0]>=q:return False
    raise ArithmeticError('Insufficient precision to certify comparison')


def max_rounds(gamma,beta,q,key):
    if not classify(caps(gamma,beta,1)[key],q):
        return 0
    lo,hi=1,2
    while classify(caps(gamma,beta,hi)[key],q):
        lo,hi=hi,2*hi
    while lo+1<hi:
        mid=(lo+hi)//2
        if classify(caps(gamma,beta,mid)[key],q):lo=mid
        else:hi=mid
    assert classify(caps(gamma,beta,lo)[key],q)
    assert not classify(caps(gamma,beta,lo+1)[key],q)
    return lo


rows=[]
for name,gamma,q,status in routes:
    for exponent in (25,27,29):
        # M has odd exponent: beta=2^a sqrt(2), beta'=2^(a+1)R exactly.
        a=10+exponent//2
        beta=scale(1<<a,sqrt2)
        beta_concat=scale(1<<(a+1),R)
        requested_product=mul(mul(sqrt2,R),beta)
        assert requested_product[0]<=beta_concat[1]
        assert requested_product[1]>=beta_concat[0]
        values=caps(gamma,beta,T)
        row={'route':name,'status':status,'q':q,'Gamma':str(gamma),
             'M_exponent':exponent,'M':1<<exponent,'k':k,'T':T,
             'beta_in':encode(beta),'beta_in_prime_concat':encode(beta_concat),
             **{name:encode(value) for name,value in values.items()}}
        for kind,key in [('single','single_radius'),('two','two_radius')]:
            row[f'{kind}_radius_over_q']=encode(scale(F(1,q),values[key]))
            row[f'{kind}_strictly_below_q']=classify(values[key],q)
            tmax=max_rounds(gamma,beta,q,key)
            row[f'{kind}_Tmax_q_only']=tmax
            row[f'{kind}_Tmax_certificate']={
                'radius_at_Tmax':encode(caps(gamma,beta,tmax)[key]) if tmax else None,
                'radius_at_Tmax_plus_1':encode(caps(gamma,beta,tmax+1)[key]),
            }
        # At T=32 all listed single bounds are controlled by the accumulator
        # term and all two-track bounds by 8*Gamma*B_first.
        assert values['single_acc_term'][0]>values['single_fresh_term'][1]
        assert values['two_fresh_term'][0]>values['two_acc_term'][1]
        rows.append(row)

result={'scope':'Only deterministic norm caps and the necessary ordinary-SIS radius<q check. No estimator or security-level conclusion.',
        'initial_accumulator_norm':0,
        'projection_ratio_R_squared':str(R_squared),
        'projection_ratio_R':encode(R),'sqrt2':encode(sqrt2),
        'rational_bracket_decimal_places':40,
        'formulas':{
            'beta_in':'1024 sqrt(M)',
            'beta_in_prime_concat':'sqrt(k) R beta_in',
            'B_T':'T k Gamma beta_in',
            'backward_increment':'Gamma sqrt(k) beta_in_prime = k Gamma R beta_in',
            'B_first':'k Gamma beta_in [T+(T-1)R]',
            'single':'max(8 Gamma B_first, 2(k+1)B_first(2 Gamma)^k)',
            'two':'max(8 Gamma B_first, 2(B_first+Gamma sqrt(k)beta_in_prime))',
        },'rows':rows}
dest=Path(__file__).resolve().parents[1]/'repair-notes'/'rom_parameter_ledger.json'
dest.write_text(json.dumps(result,indent=2),encoding='utf-8')
print('R in',R)
print('sqrt(2) in',sqrt2)
for row in rows:
    print(row['route'],f"M=2^{row['M_exponent']}",
          'single/q='+row['single_radius_over_q']['midpoint_display'],
          'two/q='+row['two_radius_over_q']['midpoint_display'],
          'Tmax='+str((row['single_Tmax_q_only'],row['two_Tmax_q_only'])))
