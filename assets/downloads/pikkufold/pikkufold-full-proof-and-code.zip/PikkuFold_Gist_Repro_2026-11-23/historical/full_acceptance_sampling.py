"""Independent statistical check of the actual H1 cardinality prerequisite.
All sampled memberships are certified; population conclusions remain statistical.
"""
from pathlib import Path
import json, math
import numpy as np
from reproduce_enumeration import certified_unit_table,SCALE

N=1<<18
rng=np.random.Generator(np.random.PCG64(20261115))
re,im=certified_unit_table(128)
limit=(8357**2*SCALE*SCALE)//1000**2
accepted=unknown=0
for start in range(0,N,1024):
    supports=np.empty((1024,23),dtype=np.int64)
    signs=np.empty((1024,23),dtype=np.int64)
    for i in range(1024):
        supports[i]=rng.choice(128,size=23,replace=False)
        signs[i]=2*rng.integers(0,2,size=23)-1
    vr=np.sum(re[supports]*signs[:,:,None],axis=1)
    vi=np.sum(im[supports]*signs[:,:,None],axis=1)
    high=np.max((np.abs(vr)+23)**2+(np.abs(vi)+23)**2,axis=1)
    low=np.max(np.maximum(np.abs(vr)-23,0)**2+np.maximum(np.abs(vi)-23,0)**2,axis=1)
    accepted+=int(np.sum(high<=limit))
    unknown+=int(np.sum((low<=limit)&(high>limit)))
q=(1<<50)-2687
base=2**23*math.comb(128,23)
p0=q*q/base
phat=accepted/N
kl=phat*math.log(phat/p0)+(1-phat)*math.log((1-phat)/(1-p0))
assert phat>p0
out={'samples':N,'seed':20261115,'rng':'NumPy PCG64',
     'certified_accepted':accepted,'undecided':unknown,'observed_acceptance':phat,
     'minimum_population_acceptance_for_cardinality_q_squared':p0,
     'iid_binomial_chernoff_tail_bits_under_cardinality_failure':N*kl/math.log(2),
     'scope':'Statistical corroboration of |C|>=q^2 only; fixed seed is not an unconditional proof.'}
(Path(__file__).resolve().parents[1]/'results'/'full_acceptance_sampling.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
