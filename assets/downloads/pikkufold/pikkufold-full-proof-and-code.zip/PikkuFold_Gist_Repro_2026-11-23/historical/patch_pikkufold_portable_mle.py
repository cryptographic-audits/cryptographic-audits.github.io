#!/usr/bin/env python3
"""Opt-in portable MLE evaluation for the original PikkuFold schemelet.

Only patches src/eval.rs; preserves the AVX-512 code in builds without the
existing `scalar-commit-audit` feature. Does not alter verifier checks.

Run from pikku-fold-schemelet/, after installing the scalar commitment probe:
    python3 /path/to/patch_pikkufold_portable_mle.py
"""
from pathlib import Path
from datetime import datetime, timezone
import shutil

root = Path.cwd()
path = root / "src" / "eval.rs"
cargo_path = root / "Cargo.toml"
if not path.is_file() or not cargo_path.is_file():
    raise SystemExit("Run this script from the pikku-fold-schemelet crate directory")
if 'scalar-commit-audit = []' not in cargo_path.read_text(encoding='utf-8'):
    raise SystemExit("Missing scalar-commit-audit feature: install the previous scalar commitment probe first")

original = path.read_text(encoding="utf-8")
marker = 'Portable test-only MLE path; normal builds retain AVX-512 contract_pass.'
if marker in original:
    print("Portable MLE test path already installed; no changes made")
    raise SystemExit(0)

expected = '''use crate::field_sumcheck::diagonal_value;
use crate::ifma::contract_pass;
use crate::proj_sumcheck::embed_qe;
use crate::qe_vec::expand_eq_soa;
use rokoko::common::ring_arithmetic::{QuadraticExtension, RingElement};

// The point is diagonal, so the eq table is F_{q^2}-valued.
pub(crate) fn mle_evaluate(values: &[RingElement], point: &[RingElement]) -> RingElement {
    assert_eq!(values.len(), 1 << point.len());
    let layers: Vec<QuadraticExtension> = point.iter().map(diagonal_value).collect();
    let alpha = embed_qe(&QuadraticExtension { coeffs: [0, 1] });
    unsafe { contract_pass(values, &expand_eq_soa(&layers), &alpha) }.remove(0)
}
'''
if original.strip() != expected.strip():
    raise SystemExit("Unexpected src/eval.rs content; refusing to overwrite. Inspect manually.")

modified = '''use crate::field_sumcheck::diagonal_value;
#[cfg(feature = "scalar-commit-audit")]
use crate::field_sumcheck::evaluate_column;
#[cfg(not(feature = "scalar-commit-audit"))]
use crate::ifma::contract_pass;
#[cfg(not(feature = "scalar-commit-audit"))]
use crate::proj_sumcheck::embed_qe;
use crate::qe_vec::expand_eq_soa;
use rokoko::common::ring_arithmetic::{QuadraticExtension, RingElement};

// The point is diagonal, so the eq table is F_{q^2}-valued.
pub(crate) fn mle_evaluate(values: &[RingElement], point: &[RingElement]) -> RingElement {
    assert_eq!(values.len(), 1 << point.len());
    let layers: Vec<QuadraticExtension> = point.iter().map(diagonal_value).collect();
    let weights = expand_eq_soa(&layers);
    // Portable test-only MLE path; normal builds retain AVX-512 contract_pass.
    #[cfg(feature = "scalar-commit-audit")]
    {
        evaluate_column(values, &weights)
    }
    #[cfg(not(feature = "scalar-commit-audit"))]
    {
        let alpha = embed_qe(&QuadraticExtension { coeffs: [0, 1] });
        unsafe { contract_pass(values, &weights, &alpha) }.remove(0)
    }
}

#[cfg(all(test, feature = "scalar-commit-audit"))]
#[test]
fn portable_mle_boolean_index_regression() {
    use rokoko::common::ring_arithmetic::Representation;
    rokoko::common::init_common();
    let zero = RingElement::zero(Representation::IncompleteNTT);
    let one = RingElement::constant(1, Representation::IncompleteNTT);
    let mut values = vec![zero.clone(); 8];
    values[5] = one.clone(); // lexicographic index 5 has bits 101.
    for index in 0..8usize {
        let point: Vec<RingElement> = (0..3)
            .map(|j| RingElement::constant(((index >> (2 - j)) & 1) as u64, Representation::IncompleteNTT))
            .collect();
        let got = mle_evaluate(&values, &point);
        assert_eq!(got, if index == 5 { one.clone() } else { zero.clone() });
    }
}
'''

stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup = path.with_name('eval.rs.before_portable_mle_' + stamp)
shutil.copy2(path, backup)
path.write_text(modified, encoding='utf-8')
print('Patched:', path)
print('Backup:', backup)
print('Default build: original AVX-512 path preserved')
print('Audit feature: uses field_sumcheck::evaluate_column')
