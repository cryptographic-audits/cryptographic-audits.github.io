"""Static algebraic consistency checks for the printed PikkuFold indexing.
This is a mathematical relation check, not an implementation or network test.
Run: python scripts/protocol_indexing_check.py
"""
from fractions import Fraction
from itertools import product
from pathlib import Path
import json

k, m, n, phi = 4, 1, 1, 2
f = 4
q = (1 << 61) - 1
# Exact Lucas-Lehmer certificate for M_61 (61 is prime).
s = 4
for _ in range(61 - 2):
    s = (s*s - 2) % q
assert s == 0
assert all(61 % d for d in range(2, 8))
assert f % 4 != 2
assert q % 4 == 3  # X^2+1 is irreducible; e=2, a=1.
C = tuple(range(16))
Gamma = max(abs(c) for c in C)
assert all(0 < abs(c-d) < q for c in C for d in C if c != d)

lex = list(product((0, 1), repeat=2))
little = [tuple((i >> j) & 1 for j in range(2)) for i in range(k)]
perm = [lex.index(b) for b in little]
w = (0, 1, 2, 3)
y = w
t_honest = w
t_permuted = tuple(w[j] for j in perm)
printed_claim_lhs = t_permuted
assert perm == [0, 2, 1, 3]
assert printed_claim_lhs != t_honest
assert printed_claim_lhs == t_permuted
# For m=n=1 and F=1, the two exact congruences require y_i=t_i.
inconsistent_inputs = [i for i in range(k) if (y[i]-t_permuted[i]) % q]
assert inconsistent_inputs == [1, 2]

beta_in = 3
beta_acc = 1
beta_out = beta_acc + k*Gamma*beta_in
beta_out_prime = beta_out
beta_bind = (k+1)*beta_out_prime*(2*Gamma)**k
rho_bind = (2*Gamma)**k
beta_sis = max(8*Gamma*beta_out_prime, 2*beta_bind*rho_bind)
beta_sis_appendix = 6*Gamma*beta_out_prime
assert 0 < beta_sis < q
assert 0 < beta_sis_appendix < q
# Any nonzero x in Z[i] with x=0 mod q has coefficient norm >= q, so both break relations are empty.

# A single fine layer, f=4, phi=2, r_0=1, m_0=4, n_0=256.
# The 256 x 8 coefficient matrix acts on (0,0,1,0,2,0,3,0).
# Only the four constant coefficients contribute to each row.
rows = 256
alpha2 = Fraction('27.37')
upper2 = Fraction('343.2')
margin = 126
omega2 = k*beta_in**2*upper2
beta_in_prime2 = omega2/alpha2
assert beta_in_prime2 * margin**2 <= q*q
# Deterministic norm check for EVERY allowed ternary projection matrix.
max_row_abs = max(abs(sum(a*b for a,b in zip(row,w))) for row in product((-1,0,1), repeat=k))
max_projection_norm2 = rows*max_row_abs**2
assert max_projection_norm2 < omega2
# Static folded equality: y_i=w_i and terminal claims t'_i=w_i (m=1).
# All output witnesses are nonnegative and <= sum(max C * w_i).
max_folded_abs = max(C)*sum(w)
assert max_folded_abs <= beta_out_prime

kappa_proj = Fraction(1, 2**128)
nu0, nu1, mu = 2, 8, 1
kappa = Fraction(k,len(C)) + kappa_proj + Fraction(nu1,q)**mu + Fraction(1,q*q) + Fraction(2*nu0+1,q)
kappa_appendix = Fraction(2*k,len(C)) + kappa_proj + Fraction(13,q) + Fraction(1,q*q)
assert kappa < Fraction(1,3)
assert kappa_appendix < Fraction(2,3)
result = {
 'scope':'Static mathematical relation and parameter verification only',
 'q':q,'lucas_lehmer_residue':s,'f':f,'phi':phi,
 'lex_order':lex,'little_endian_order':little,'selected_indices':perm,
 'w_and_y':w,'honest_t':t_honest,'permuted_t':t_permuted,
 'printed_claim_lhs':printed_claim_lhs,'inconsistent_input_indices':inconsistent_inputs,
 'challenge_size':len(C),'Gamma':Gamma,'beta_out':beta_out,
 'beta_sis_original':beta_sis,'beta_sis_appendix':beta_sis_appendix,
 'omega_squared':str(omega2),'beta_in_prime_squared':str(beta_in_prime2),
 'max_row_abs':max_row_abs,'max_projection_norm_squared':max_projection_norm2,
 'max_folded_abs':max_folded_abs,
 'knowledge_error_original':str(kappa),'knowledge_error_original_float':float(kappa),
 'knowledge_error_appendix':str(kappa_appendix),'knowledge_error_appendix_float':float(kappa_appendix),
 'all_checks_passed':True
}
root=Path(__file__).resolve().parents[1]
out=root/'results'/'protocol_indexing_check.json'
out.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
