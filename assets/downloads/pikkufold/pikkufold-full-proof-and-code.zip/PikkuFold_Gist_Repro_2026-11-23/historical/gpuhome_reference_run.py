"""Run the exact, already-staged reference checkout and retain evidence.

Run on gpuhome with its isolated venv Python. This is a correctness campaign,
not an original PikkuFold performance reproduction.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET


BASE = Path('/root/rivermind-data/pikkufold-repair-lab')


def git_output(release, *args):
    return subprocess.check_output(['git', '-C', str(release), *args], text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    args = parser.parse_args()
    if len(args.commit) != 40 or any(c not in '0123456789abcdef' for c in args.commit):
        parser.error('commit must be a full lowercase SHA-1')
    release = BASE / 'releases' / args.commit
    if git_output(release, 'rev-parse', 'HEAD') != args.commit:
        raise RuntimeError('Source HEAD mismatch')
    if git_output(release, 'status', '--porcelain'):
        raise RuntimeError('Source checkout must be clean')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    campaign = BASE / 'runs' / (stamp + '-reference-' + uuid.uuid4().hex[:8])
    campaign.mkdir()
    inventory = campaign / 'environment.json'
    probe = subprocess.run(
        [sys.executable, str(release / 'experiments/environment_probe.py'), '--output', str(inventory)],
        cwd=release, capture_output=True, text=True, timeout=150,
    )
    (campaign / 'inventory.stderr.log').write_text(probe.stderr)
    if probe.returncode:
        raise RuntimeError('Runtime inventory failed; see retained stderr')
    packages = subprocess.check_output([sys.executable, '-m', 'pip', 'list', '--format=json'], text=True)
    (campaign / 'packages.json').write_text(packages)
    config = {
        'argv': [sys.executable, '-m', 'pytest', '-q', '--junitxml=' + str(campaign / 'junit.xml')],
        'cwd': str(release), 'timeout': 600, 'repetitions': 1,
        'label': 'full-reference-and-harness-tests', 'source_revision': args.commit,
        'evidence_scope': 'Portable Python reference and experiment-tool tests; no original native performance claim',
        'environment_inventory': str(inventory),
        'cpu_affinity': [min(os.sched_getaffinity(0))],
        'expectations': {'exit_codes': [0], 'stdout_contains': ['passed']},
        'metadata': {'source_check': 'Wrapper verified exact Git HEAD and clean tree before execution'},
    }
    config_path = campaign / 'config.json'
    config_path.write_text(json.dumps(config, indent=2) + '\n')
    for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[name] = '1'
    run = subprocess.run(
        [sys.executable, '-m', 'experiments.harness', str(config_path), '--output-dir', str(campaign / 'processes')],
        cwd=release, capture_output=True, text=True, timeout=630,
    )
    (campaign / 'harness.stdout.json').write_text(run.stdout)
    (campaign / 'harness.stderr.log').write_text(run.stderr)
    if run.returncode:
        raise RuntimeError('Reference campaign failed; inspect retained process logs: ' + str(campaign))
    summary = json.loads(run.stdout)
    run_dir = Path(summary['runs'][0]['directory'])
    record = json.loads((run_dir / 'record.json').read_text())
    xml = ET.parse(campaign / 'junit.xml').getroot()
    cases = list(xml.iter('testcase'))
    failures = sum(case.find('failure') is not None for case in cases)
    errors = sum(case.find('error') is not None for case in cases)
    skipped = sum(case.find('skipped') is not None for case in cases)
    if not cases or failures or errors:
        raise RuntimeError('JUnit result did not confirm a passing suite')
    clean_after = not git_output(release, 'status', '--porcelain')
    result = {
        'campaign': str(campaign), 'source_commit': args.commit,
        'campaign_runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_exact_head_verified': True, 'source_clean_before': True,
        'source_clean_after': clean_after, 'python_executable': sys.executable,
        'pytest': {'total': len(cases), 'passed': len(cases)-skipped, 'skipped': skipped,
                   'failures': failures, 'errors': errors},
        'requested_cpu_affinity': config['cpu_affinity'],
        'thread_environment': {name: os.environ[name] for name in
                               ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')},
        'wall_seconds_whole_test_command': record['wall_seconds'],
        'max_rss_bytes': record['resources']['max_rss_bytes'],
        'rss_unavailable_reason': record['resources']['unavailable_reason'],
        'scope': 'Correctness tests only; test duration is not prover or verifier time',
    }
    (campaign / 'campaign.json').write_text(json.dumps(result, indent=2) + '\n')
    if not clean_after:
        raise RuntimeError('Source tree changed during tests; see campaign record')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
