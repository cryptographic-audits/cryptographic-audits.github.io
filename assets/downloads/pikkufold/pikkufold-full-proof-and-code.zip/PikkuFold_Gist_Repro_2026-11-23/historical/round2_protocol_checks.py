"""Round-two static mathematical checks. No prover or exploit implementation.
Checks small finite resampling laws and the ROM note's stated predicate densities.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import gcd
import hashlib,json
root=Path(__file__).resolve().parents[1]
q=(1<<61)-1
ll=4
for _ in range(59): ll=(ll*ll-2)%q
assert ll==0 and q%4==3

def add(x,y): return tuple(a+b for a,b in zip(x,y))
def mul(x,y): return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def scale(a,x): return (a*x[0],a*x[1])

i=(0,1); zero=(0,0)
B=10
beta_in_prime_squared=F(34320,2737)
assert 20**2>beta_in_prime_squared
# d-level: same fresh candidate, changing accumulator candidate across lower subtrees.
rows=[]
for a in range(15):
    fresh=(20,0); acc=(-10*(2*a+1),0)
    u=add(acc,scale(a,fresh)); v=add(acc,scale(a+1,fresh))
    assert u==(-10,0) and v==(10,0)
    assert add(v,scale(-1,u))==fresh
    Eproj=(0,-1); Efresh=zero; Eacc=acc
    dproj=(0,10*(2*a+1))
    assert add(mul(dproj,Eproj),Eacc)==zero
    assert Eproj!=zero and Eacc!=zero
    rows.append({'central_challenge':a,'fresh_candidate':fresh,'accumulator_candidate':acc,
                 'central_output':u,'sibling_output':v,'batch_projection_coefficient':dproj,
                 'batch_discrepancy':zero})
assert len({tuple(row['batch_projection_coefficient']) for row in rows})==15
c_density=1-F(1,q**8)
d_density=F(15*q*q-1,q**4)
assert c_density>F(8,q)
assert d_density>F(1,q*q)
# The c-level first candidate is (0,20), and D has last coordinate 20.
# The Boolean point 0^8 kills its MLE, but D is nonzero.
assert 20*0**8==0

# Exhaust all success indicators for three small challenge/prefix configurations.
cases=0; max_cost_ratio=F(0); records=0
for g_count,s_count,k in [(2,2,2),(2,3,1),(1,3,2)]:
    states=list(product(range(s_count),repeat=k))
    nu=[F(g+1,g_count*(g_count+1)//2) for g in range(g_count)]
    for weights in ([1]*s_count,list(range(1,s_count+1))):
        D=[F(w,sum(weights)) for w in weights]
        mass={z:__import__('functools').reduce(lambda a,b:a*b,(D[x] for x in z),F(1)) for z in states}
        b=max(sum((D[u] for u in range(s_count) if gcd(u-a,6)!=1),F(0)) for a in range(s_count))
        for mask in range(1<<(g_count*len(states))):
            success={(g,z):(mask>>(g*len(states)+j))&1 for g in range(g_count) for j,z in enumerate(states)}
            pz={z:sum((nu[g]*success[g,z] for g in range(g_count)),F(0)) for z in states}
            prefix_cost=sum((mass[z] for z in states if pz[z]),F(0))
            total=F(1)+prefix_cost
            for coordinate in range(k):
                cost=F(0); bad=F(0)
                for g,z in product(range(g_count),states):
                    entry=nu[g]*mass[z]*success[g,z]
                    if not entry:continue
                    continuations=[z[:coordinate]+(u,)+z[coordinate+1:] for u in range(s_count)]
                    pi=sum((D[u]*success[g,continuations[u]] for u in range(s_count)),F(0))
                    assert pi>0
                    # The second selected-prefix entry mass cancels to the same raw successful mass.
                    selected_second=mass[z]*pz[z]*nu[g]*success[g,z]/pz[z]
                    assert selected_second==entry
                    cost+=entry/pi
                    bad+=entry/pi*sum((D[u]*success[g,continuations[u]] for u in range(s_count) if gcd(u-z[coordinate],6)!=1),F(0))
                assert cost<=1 and bad<=b
                total+=2*cost
            assert total<=2*k+2
            max_cost_ratio=max(max_cost_ratio,total/F(2*k+2))
            cases+=1

# Literal omission of positivity in Definition 16, not a positive-JL counterexample.
formal={'chi':'point mass at zero','alpha':-1,'upper':1,'b':1,'kappa':F(1,100),
        'beta_in_prime':-1,'comment':'Excluded by the intended positive lower-factor convention.'}
manifest={}
for p in [Path(r'C:\Users\72880\Desktop\Sonata\references\pdf\eprint_2026-1809_PikkuFold.pdf'),
          Path(r'C:\Users\72880\Downloads\pikku_3sqrt3.pdf'),
          Path(r'C:\Users\72880\Downloads\pikkufold_rom_proof.pdf'),
          Path(r'C:\Users\72880\Downloads\2024-311.pdf')]:
    manifest[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else 'unavailable (optional source PDF not present)'
out={'scope':'Static predicate-density and finite probability accounting only; not a protocol-security counterexample.',
     'q':q,'prime_certificate_lucas_lehmer_residue':ll,'norm_threshold_squared':str(beta_in_prime_squared),
     'c_level_actual_lower_density':str(c_density),'c_level_claimed_bound':str(F(8,q)),
     'd_level_actual_lower_density':str(d_density),'d_level_claimed_bound':str(F(1,q*q)),
     'd_level_property_reading':'Unconditional truth of all original claims; gated interpretation needs a different recursive proof.',
     'd_level_rows':rows,'exhausted_success_models':cases,'max_cost_to_2k_plus_2_ratio':str(max_cost_ratio),
     'all_checks_passed':True,'source_sha256':manifest,
     'negative_lower_factor_note':{key:str(value) for key,value in formal.items()}}
(root/'results'/'round2_protocol_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({key:out[key] for key in ['q','exhausted_success_models','max_cost_to_2k_plus_2_ratio','all_checks_passed','source_sha256']},indent=2))
