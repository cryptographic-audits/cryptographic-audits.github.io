"""Independent repeatable diagnostic, NOT a deterministic population count.

The finite-norm membership is integer-certified. The frequency and confidence
interpretation still require an ideal iid-uniform sampling model; fixed-seed
PCG64 is not a mathematical source of ideal independent randomness.
"""
from pathlib import Path
import json, math
import numpy as np
from reproduce_enumeration import certified_unit_table,SCALE

def run():
    seed=20261114
    count=1<<18
    rng=np.random.Generator(np.random.PCG64(seed))
    re,im=certified_unit_table(64)
    thresholds=[(830,100),(8357,1000)]
    limits=[(a*a*SCALE*SCALE)//(b*b) for a,b in thresholds]
    passed=[0,0]; uncertain=[0,0]; max_accepted_sq=0
    assert 2*(23*SCALE+23)**2<2**63
    for start in range(0,count,1024):
        supports=np.empty((1024,23),dtype=np.int64)
        signs=np.empty((1024,23),dtype=np.int64)
        for i in range(1024):
            supports[i]=rng.choice(64,size=23,replace=False)
            signs[i]=2*rng.integers(0,2,size=23)-1
        vr=np.sum(re[supports]*signs[:,:,None],axis=1)
        vi=np.sum(im[supports]*signs[:,:,None],axis=1)
        high=np.max((np.abs(vr)+23)**2+(np.abs(vi)+23)**2,axis=1)
        low=np.max(np.maximum(np.abs(vr)-23,0)**2+np.maximum(np.abs(vi)-23,0)**2,axis=1)
        for j,limit in enumerate(limits):
            passed[j]+=int(np.sum(high<=limit))
            uncertain[j]+=int(np.sum((low<=limit)&(high>limit)))
        selected=high[high<=limits[0]]
        if len(selected):max_accepted_sq=max(max_accepted_sq,int(max(selected)))
    p=passed[0]/count
    q=(1<<50)-2687
    full=2**23*math.comb(128,23)
    even=2**23*math.comb(64,23)
    conditional_lb=(even/(10*q)-1)/full
    return {'samples':count,'seed':seed,'rng':'NumPy Generator PCG64; uniform support via choice(replace=False), independent sign draws',
            'accepted_certified_8_30':passed[0], 'accepted_certified_8_357':passed[1],
            'undecided':[int(x) for x in uncertain],
            'observed_fraction_8_30':p,
            'largest_norm_upper_bound_8_30':math.sqrt(max_accepted_sq)/SCALE,
            'hoeffding_tail_bits_if_p_at_most_0_1':2*count*(p-.1)**2/math.log(2),
            'epsilon_lower_bound_bits_CONDITIONAL_on_population_p_at_least_0_1':-math.log2(conditional_lb),
            'full_base_cardinality':full,'even_base_cardinality':even,
            'interpretation':'Certified membership, statistical population inference only; no protocol attack lower bound.'}

if __name__=='__main__':
    out=run()
    (Path(__file__).resolve().parents[1]/'results'/'actual_parameter_sampling.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
