"""Exact finite-probability checks for the local RoKoko Lemma 5 instance.

This checks mathematical inequalities only. It does not run a protocol or prover.
The strict witness is reused with attribution from the user's LaBRADOR audit.
"""

import argparse
from fractions import Fraction
import json
from math import comb, log2
from pathlib import Path


def require(condition, label):
    if not condition:
        raise ArithmeticError(label)


def probability_record(value):
    return {
        "numerator": str(value.numerator),
        "denominator": str(value.denominator),
        "negative_log2_display_only": log2(value.denominator) - log2(value.numerator),
        "ratio_to_2_pow_minus_128_display_only": float(value * 2**128),
    }


def certificate():
    rows, dimension, small_coordinates = 256, 128, 100
    modulus, amplitude = 4294967197, 2**21
    target = Fraction(1, 2**128)
    closed = Fraction(sum(comb(rows, k) for k in range(31)), 2**rows)
    tail29 = Fraction(sum(comb(rows, k) for k in range(30)), 2**rows)
    conditional_negative = Fraction(2**6000 - comb(6000, 3000), 2**6001)
    strict = tail29 + Fraction(comb(rows, 30), 2**rows) * conditional_negative

    # J entries are independently 0 with probability 1/2 and +/-1 with 1/4.
    # Closed witness e_1, theta=1: its projected squared norm is Bin(256,1/2).
    require(125 < modulus, "closed theta < q/125")
    require(2 < modulus, "closed witness has no modular wrap")
    require(closed > target, "closed probability exceeds claimed bound")

    # Strict witness (B, 1^100, 0^27), theta=B. For each row write BA_j+D_j.
    # K=sum A_j^2, H=sum A_j D_j, L=sum D_j^2 <= 256*100^2.
    l_max = rows * small_coordinates**2
    require(1 + small_coordinates + 27 == dimension, "witness dimension")
    require(125 * amplitude < modulus, "strict theta < q/125")
    require(2 * (amplitude + small_coordinates) < modulus, "no modular wrap")
    require(amplitude**2 + small_coordinates > amplitude**2, "norm > theta")
    require(
        29 * amplitude**2 + 2 * amplitude * 29 * small_coordinates + l_max
        < 30 * amplitude**2,
        "event K<=29 implies strict small projection",
    )
    require(
        30 * amplitude**2 - 2 * amplitude + l_max < 30 * amplitude**2,
        "event K=30,H<=-1 implies strict small projection",
    )
    require(strict > Fraction(1, 2**127), "strict lower bound exceeds even 2^-127")
    require(strict > target, "strict lower bound exceeds claimed bound")

    return {
        "scope": "RoKoko local 63-page PDF, page 19, Lemma 5 concrete instance",
        "pdf_sha256": "325817d34687378949cf2157e14baa178dbe177a0fe0f16bf11da24cfbfb3acf",
        "distribution": {"zero": "1/2", "plus_one": "1/4", "minus_one": "1/4"},
        "rows": rows,
        "dimension": dimension,
        "modulus": modulus,
        "claimed_kappa": "2^-128",
        "closed_witness": {
            "description": "e_1 in Z^128, theta=1",
            "probability_kind": "exact event probability",
            "event": "K<=30, K~Bin(256,1/2)",
            **probability_record(closed),
        },
        "strict_witness": {
            "description": "(2^21, 1 repeated 100 times, 0 repeated 27 times), theta=2^21",
            "attribution": "User's LaBRADOR research, notes/continued_audit_2026-11-14.md, section 1",
            "probability_kind": "rigorous lower bound, not exact full failure probability",
            "event": "K<=29 OR (K=30 AND H<=-1)",
            "conditional_law": "H | K=30 ~ Bin(6000,1/2)-3000",
            "squared_norm": amplitude**2 + small_coordinates,
            "projection_squared_norm_on_event": "<30*theta^2<30*norm(w)^2",
            **probability_record(strict),
        },
        "all_integer_and_rational_checks_passed": True,
        "consequence": "Both concrete probability clauses fail; dependent projection budgets need reproving.",
        "excluded_conclusion": "No full-protocol attack probability or deployed security break is established.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().parents[1] / "results" / "rokoko_jl_dependency_certificate.json",
    )
    args = parser.parse_args()
    result = certificate()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "checks_passed": result["all_integer_and_rational_checks_passed"],
        "closed_event_bits_display": result["closed_witness"]["negative_log2_display_only"],
        "strict_lower_bound_bits_display": result["strict_witness"]["negative_log2_display_only"],
        "output": str(args.output),
    }, ensure_ascii=False))
