"""Independent exhaustive, integer-certified norm counts; no reviewer code used.

Normalize a weight-four polynomial to have constant coefficient +1.
For any signed-monomial invariant set, full size = normalized size * 2*n/4.
For a non-invariant predicate, sum its truth over all 2*n signed rotations of
each normalized polynomial and divide by 4. This is incidence double counting,
not an assumption that the group action is free.
"""
from fractions import Fraction as F
from itertools import combinations, islice, product
from pathlib import Path
import json, math, time
import numpy as np

SCALE = 1 << 24

def atan_bounds(inv, terms=80):
    x = F(1, inv)
    val = sum(((-1)**k*x**(2*k+1)/F(2*k+1) for k in range(terms)), F(0))
    rem = x**(2*terms+1)/F(2*terms+1)
    return val, val+rem  # even number of terms ends with a negative term

def certified_unit_table(n):
    a,b = atan_bounds(5)
    c,d = atan_bounds(239)
    pi_lo,pi_hi = 16*a-4*d,16*b-4*c
    # Compress the exact enclosure to an 80-bit dyadic interval; this avoids
    # huge denominators in repeated Taylor powers without weakening rigor.
    dyadic=1<<80
    pi_lo=F((pi_lo*dyadic).__floor__(),dyadic)
    pi_hi=F((pi_hi*dyadic).__ceil__(),dyadic)
    mid=(pi_lo+pi_hi)/2
    tab=[]
    # Degree-40 Taylor polynomials; Lagrange error <= pi^41/41!.
    for k in range(2*n):
        t=k if k<=n else k-2*n
        angle=mid*F(t,n)
        angle_error=(pi_hi-pi_lo)/2*abs(F(t,n))
        co=sum(((-1)**j*angle**(2*j)/math.factorial(2*j) for j in range(21)),F(0))
        si=sum(((-1)**j*angle**(2*j+1)/math.factorial(2*j+1) for j in range(20)),F(0))
        err=pi_hi**41/math.factorial(41)+angle_error
        vals=[]
        for v in (co,si):
            fixed=round(v*SCALE)
            assert abs(F(fixed,SCALE)-v)+err < F(1,SCALE)
            vals.append(fixed)
        tab.append(vals)
    # Every component is certified within one integer unit; no float trig used.
    tab=np.array(tab,dtype=np.int64)
    phases=(np.arange(n)[:,None]*(2*np.arange(n//2)[None,:]+1))%(2*n)
    return tab[phases,0],tab[phases,1]

def root_order_128(q):
    for g in range(2,q):
        z=pow(g,(q-1)//128,q)
        if pow(z,64,q)==q-1: return z
    raise AssertionError('no root')

def count(n, q=None):
    real,imag=certified_unit_table(n)
    limit=(1369*SCALE*SCALE)//100  # (37/10)^2, compare integer squares
    # All squared bounds are < 2*(4*SCALE+4)^2 < 2^63.
    assert 2*(4*SCALE+4)**2 < 2**63
    signs=np.array(list(product([-1,1],repeat=3)),dtype=np.int64)
    if q:
        assert n==64
        assert q>2 and all(q%d for d in range(2,math.isqrt(q)+1))
        assert q%256==129  # ord_256(q)=2, and alpha^2 belongs to F_q
        z=root_order_128(q)
        roots=np.array([pow(z,2*j+1,q) for j in range(64)],dtype=np.int64)
        power=np.array([[pow(int(r),i,q) for r in roots] for i in range(64)],dtype=np.int64)
        anchor=(1+power[1]+power[2]-power[3])%q
        assert np.all(anchor!=0)
        lookup=np.full((64,q),-1,dtype=np.int16)
        for j,r in enumerate(roots):
            for t in range(128): lookup[j,int(anchor[j])*pow(int(r),(-t)%128,q)%q]=t
    accepted=ambiguous=total=hits=0
    it=iter(combinations(range(1,n),3))
    start=time.time()
    while True:
        block=list(islice(it,2048))
        if not block: break
        support=np.repeat(np.array(block),8,axis=0)
        ss=np.tile(signs,(len(block),1))
        re=SCALE+np.sum(real[support]*ss[:,:,None],axis=1)
        im=np.sum(imag[support]*ss[:,:,None],axis=1)
        hi=(np.abs(re)+4)**2+(np.abs(im)+4)**2
        lo=np.maximum(np.abs(re)-4,0)**2+np.maximum(np.abs(im)-4,0)**2
        good=np.all(hi<=limit,axis=1)
        bad=np.any(lo>limit,axis=1)
        ambiguous+=int(np.sum(~good & ~bad))
        accepted+=int(good.sum());total+=len(good)
        if q and np.any(good):
            vals=(1+np.sum(power[support[good]]*ss[good,:,None],axis=1))%q
            ts=np.sort(lookup[np.arange(64)[None,:],vals],axis=1)
            hits+=int(np.sum((ts[:,0]>=0)))
            hits+=int(np.sum((ts[:,1:]>=0)&(ts[:,1:]!=ts[:,:-1])))
    assert total==8*math.comb(n-1,3)
    assert ambiguous==0, 'increase SCALE or refine uncertain cases'
    out={'n':n,'normalized_total':total,'normalized_accepted':accepted,
         'full_total':total*2*n//4,'full_accepted':accepted*2*n//4,
         'ambiguous':ambiguous,'seconds':time.time()-start}
    if q:
        assert hits%4==0
        out.update(q=q,primitive_root_128=int(z),signed_rotation_incidence_hits=hits,
                   full_anchor_collisions_excluding_self=hits//4-1)
    return out

if __name__=='__main__':
    result={'certificate':'Machin rational pi bounds + rational Taylor + fixed-point integer squared norms',
            'scale':SCALE,'norm_component_error_units':4,'gamma':'37/10',
            'full':count(128),'even_subfamily':count(64,7297)}
    numerator=result['even_subfamily']['full_anchor_collisions_excluding_self']
    denominator=result['full']['full_accepted']
    result.update(epsilon_lower_bound=numerator/denominator,
                  lower_bound_bits=-math.log2(numerator/denominator),
                  ratio_to_heuristic=(numerator*7297**2)/(denominator*64))
    path=Path(__file__).resolve().parents[1]/'results'/'independent_enumeration.json'
    path.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
