"""Arb-certified conservative CBD sampler parameters; no sampling/attack code.

Requires python-flint. All acceptance/fibre bounds follow the proved formulas
in repair-notes/sampler_routes.md. This certifies arithmetic, not full protocol
parameters, novelty, or formal proof-assistant verification.
"""
from fractions import Fraction
from math import comb, factorial
from pathlib import Path
import json
from flint import arb, fmpq, ctx

ctx.prec = 192
q = (1 << 50) - 2687
n, m = 128, 64
pi = arb.pi()
ln2 = arb(2).log()
lam = pi**2 * (-(arb(q).log()) / 32).exp()

# Pure-rational elementary certificates for the hand-checkable baseline.
assert 3**32 > 2**50
assert Fraction(314, 100)**2 > Fraction(39, 4)
exp3lower = sum((Fraction(3**j, factorial(j)) for j in range(9)), Fraction(0))
assert exp3lower > 20
assert 20**13 > 2**56
assert Fraction(20**2 * 3, 2) > 512
# M=12, eta=12, Gamma=78: cos^2(pi/12)=(2+sqrt(3))/4>933/1000.
assert Fraction(1732, 1000)**2 < 3
exp78 = Fraction(2 * 78**2 * 933, 1000 * n * 12)
exp78lower = sum((exp78**j / factorial(j) for j in range(61)), Fraction(0))
assert exp78lower > 1536

def row(eta, gamma, directions=12):
    c = (pi / directions).cos()
    fail = (arb(n) / 2) * directions * (-2 * gamma**2 * c**2 / (n * eta)).exp()
    p = 1 - fail
    assert p > 0
    slot_numerator = 1 + (q - 1) * (-eta * lam).exp()
    b = m * slot_numerator**2 / (p * arb(q)**2)
    rho = (arb(comb(2 * eta, eta)) / arb(2)**(2 * eta))**n / p
    target = arb(2)**-91
    certified_target = bool(4 * b < target)
    return {
        'eta': eta, 'gamma': gamma, 'angular_directions': directions,
        'acceptance_lower_bound_interval': str(p),
        'scalar_slot_probability_multiplier_interval': str(slot_numerator),
        'nonunit_including_equality_upper_bound_interval': str(b),
        'negative_log2_b_lower_bound_interval': str(-b.log() / ln2),
        'negative_log2_4b_lower_bound_interval': str(-(4 * b).log() / ln2),
        'certifies_4b_less_than_2_to_minus_91': certified_target,
        'negative_log2_atom_upper_bound_interval': str(-rho.log() / ln2),
        'gamma_ratio_to_original_8_357_interval': str(arb(gamma) / arb(fmpq(8357,1000))),
    }

rows = [row(11,76), row(11,78), row(12,78), row(12,80), row(13,81), row(13,104)]
assert all(r['certifies_4b_less_than_2_to_minus_91'] for r in rows)
coarse = arb(fmpq(4225,32)) / arb(q)**2
out = {
    'precision_bits': ctx.prec,
    'scope': 'Rigorous sampler bounds only; no end-to-end protocol or novelty claim.',
    'q': q, 'n': n, 'm': m, 'lambda_interval': str(lam),
    'general_b_formula': 'm*(1+(q-1)*exp(-eta*pi^2*q^(-2/m)))^e/(p*q^e), e=2',
    'p_formula': '1-(n/2)*M*exp(-2*Gamma^2*cos(pi/M)^2/(n*eta))',
    'hand_checkable_eta12_gamma78': {
        'p_greater_than': '1/2',
        'scalar_multiplier_less_than': '65/64',
        'b_less_than_exact': f'4225/(32*{q}^2)',
        'negative_log2_b_interval': str(-coarse.log()/ln2),
        'angular_failure_rational_certificate_terms': 61,
    },
    'rows': rows,
}
dest = Path(__file__).resolve().parents[1] / 'repair-notes' / 'sampler_bounds.json'
dest.parent.mkdir(exist_ok=True)
dest.write_text(json.dumps(out, indent=2), encoding='utf-8')
print(json.dumps(out, indent=2))
