#!/usr/bin/env python3
"""Runnable FULL ALGEBRAIC TRANSCRIPT for the actual-q PikkuFold fixed-key attack.

Models the original Figure 2 at k=2,m=2,d=1,mu=2,phi=128,q=2^50-2687.
Includes genuine sampled biased-ternary fine JL matrix, trace-dual fine ring
lift, trace batching, ring claim batching, a F_(q^2)-linear CRT-slot batching
map, all 2 rounds of degree-two sumcheck, terminal reconstruction and final
folding relation. The prover uses a false internal opening for input0 and an
explicit accepted challenge vanishing at one CRT slot. Fixed random public
commitment key F never changes.

This is an exact algebraic protocol model, not Rust wire-protocol/Fiat-Shamir
byte forgery; verifier challenges here are sampled using Python Random as an
experiment rather than extracted from an actual hash transcript.
"""
from pathlib import Path
from random import Random
from fractions import Fraction
import argparse,json
from attack_fixed_key_actual_q50 import (
    Q,N,BETA,ONE,ZERO,add,neg,sub,mul,scale,matvec,random_invertible_key,
    make_idempotent,poly_slot,unit
)
from verify_actual_q50_zeros import run as certify_zero_candidates

# F_(q^2) = F_q[T]/(T^2-BETA); BETA nonsquare in F_q.
def fa(x,y):return ((x[0]+y[0])%Q,(x[1]+y[1])%Q)
def fn(x):return ((-x[0])%Q,(-x[1])%Q)
def fs(x,y):return fa(x,fn(y))
def fm(x,y):return ((x[0]*y[0]+BETA*x[1]*y[1])%Q,(x[0]*y[1]+x[1]*y[0])%Q)
def fscale(x,n):return (x[0]*n%Q,x[1]*n%Q)
F0=(0,0);F1=(1,0)

def eqweights(bits):
    out=[F1]
    for a in bits:
        out=[fm(v,term) for v in out for term in (fs(F1,a),a)]
    return out

def scalar_bits_weights(bits):
    out=[1]
    for a in bits:out=[v*factor%Q for v in out for factor in ((1-a)%Q,a)]
    return out

def poly_by_4(table,x0,x1):
    ws=eqweights((x0,x1))
    out=F0
    for a,b in zip(table,ws):out=fa(out,fm(a,b))
    return out

def sample_r(rng):return rng.randrange(Q),rng.randrange(Q)

def represent_challenge(a):
    poly=[0]*N
    for idx,c in enumerate(a):poly[2*idx]=c
    return tuple(poly)

def make_jl_lifted(rng):
    """J ∈ {-1,0,1}^{256×(4×128)} biased ternary; fine lift M.
    In power basis b_i=X^i, trace dual: b_0^vee=1/128;
    b_i^vee=−X^(128−i)/128 for i≥1.
    """
    inv128=pow(128,-1,Q)
    Mat=[];tr=[]
    for row in range(256):
        js=[(-1,0,0,1)[rng.randrange(4)] for _ in range(4*N)]
        rings=[]
        for block in range(4):
            coeff=[0]*N
            coeff[0]=js[block*N]*inv128%Q
            for pos in range(1,N):
                coeff[N-pos]=(-js[block*N+pos]*inv128)%Q
            rings.append(tuple(coeff))
        Mat.append(rings)
        tr.append(js[0]+js[3*N]) # fake w_all=(1,0,0,1)
    assert sum(x*x for x in tr)<Fraction(13728,5)
    return Mat,tr

def CRT_field_image(poly,slot):
    """theta_slot maps X ↦ BETA^slot*T, T²=BETA; slot=0,...,63.
    The chosen roots of X^128+1 are X²↦BETA^(2slot+1).
    """
    r=pow(BETA,2*slot+1,Q)
    a=b=0;power=1
    for j in range(64):
        a+=poly[2*j]*power;b+=poly[2*j+1]*power
        power=power*r%Q
    return (a%Q,(b*pow(BETA,slot,Q))%Q)

def batch_slot_images(polys,delta):
    return [sum_field(fm(delta[s],CRT_field_image(g,s)) for s in range(64)) for g in polys]

def sum_field(items):
    a=b=0
    for x,y in items:a+=x;b+=y
    return a%Q,b%Q

def run_one(seed,first_signed):
    rng=Random(seed)
    roots=[pow(BETA,2*j+1,Q) for j in range(64)]
    F,draws=random_invertible_key(roots,seed+78273)
    lam,dinv=make_idempotent(BETA)
    assert unit((sub(mul(F[0][0],F[1][1]),mul(F[0][1],F[1][0]))),roots)
    wfake=(ONE,ZERO,ZERO,ONE) # (w0=(1,0),w1=(0,1))
    y0=matvec(F,(dinv,ZERO));y1=matvec(F,(ZERO,ONE))
    assert matvec(F,(ONE,ZERO))!=y0

    M,tr=make_jl_lifted(rng)
    vproj=[add(row[0],row[3]) for row in M]
    # Trace is 128 times constant coefficient for this negacyclic ring.
    assert all(tr[j]%Q==(128*vproj[j][0])%Q for j in range(256))

    # The 2 independently sampled trace-check points follow v_tr.
    mu=2
    ci=[[rng.randrange(Q) for _ in range(8)] for _ in range(mu)]
    vectors=[scalar_bits_weights(bits) for bits in ci]
    vbtd=[];A=[]
    for weights in vectors:
        proj=[0]*N
        for j in range(256):
            if weights[j]:
                for t in range(N):proj[t]+=weights[j]*vproj[j][t]
        proj=tuple(x%Q for x in proj)
        vbtd.append(proj)
        assert (128*proj[0])%Q==sum(w*tr[t] for t,w in enumerate(weights))%Q
        mblock=[]
        for block in range(4):
            vec=[0]*N
            for j in range(256):
                if weights[j]:
                    for t in range(N):vec[t]+=weights[j]*M[j][block][t]
            mblock.append(tuple(x%Q for x in vec))
        A.append(mblock)
        assert add(mblock[0],mblock[3])==proj

    # The mu projection + 2 fresh evaluation claims are batched by mu+2
    # independent UNIFORM R_q coefficients. Accumulator coeff fixed 1, claim=0.
    d=[tuple(rng.randrange(Q) for _ in range(N)) for _ in range(mu+2)]
    table=[ZERO]*4
    for j in range(4):
        sums=[mul(d[i],A[i][j]) for i in range(mu)]
        if j==0:sums.append(d[mu])  # input0 source s0=0,t0=1
        if j==2:sums.append(d[mu+1])  # input1 source s1=0,t1=0
        table[j]=sum_poly(sums)
    batched_public=sum_poly([mul(d[i],vbtd[i]) for i in range(mu)]+[d[mu]])
    assert add(table[0],table[3])==batched_public

    # Genuine random subfield-batching vector over (F_(q²))^64 and
    # 2-round sumcheck over F_(q²), using actual ring CRT isomorphism.
    delta=[sample_r(rng) for _ in range(64)]
    batched_table=batch_slot_images(table,delta)
    initial_claim=sum_field(fm(delta[s],CRT_field_image(batched_public,s)) for s in range(64))
    assert initial_claim==fa(batched_table[0],batched_table[3])
    def g(x0,x1):
        b=poly_by_4(batched_table,x0,x1)
        w=fa(fm(fs(F1,x0),fs(F1,x1)),fm(x0,x1))
        return fm(b,w)
    claim=initial_claim
    rounds=[];points=[]
    inv2=pow(2,-1,Q)
    for j in range(2):
        def p(t):
            if j==0:return fa(g(t,F0),g(t,F1))
            return g(points[0],t)
        p0,p1,p2=p(F0),p(F1),p((2,0))
        assert fa(p0,p1)==claim
        c2=fscale(fa(fs(p2,fscale(p1,2)),p0),inv2)
        c1=fs(fs(claim,fscale(p0,2)),c2)
        assert fa(fa(p0,c1),c2)==p1
        r=sample_r(rng)
        claim=fa(fa(p0,fm(c1,r)),fm(c2,fm(r,r)))
        assert claim==p(r)
        rounds.append([p0,c2]);points.append(r)
    r0,r1=points
    t0=fs(F1,r1) # honest MLE[wfake0](r1)
    t1=r1        # honest MLE[wfake1](r1)
    w_terminal=fa(fm(fs(F1,r0),t0),fm(r0,t1))
    batched_terminal=poly_by_4(batched_table,r0,r1)
    assert claim==fm(batched_terminal,w_terminal)
    # The terminal ring message is reconstructed from t0,t1 and public M.
    assert w_terminal==poly_by_4([F1,F0,F0,F1],r0,r1)

    # Now the verifier samples fold challenges (we select a concrete valid pair;
    # probability statement constrains only the first challenge).
    z0=represent_challenge(first_signed)
    # Choose the second accepted challenge from a Galois orbit that is NOT
    # in the selected zero fibre: it is genuinely unconstrained by the attack.
    transformed=[0]*64
    for j,c in enumerate(first_signed):
        idx=(3*j)%128
        if idx>=64:transformed[idx-64]=-c
        else:transformed[idx]=c
    z1=tuple(c%Q for c in represent_challenge(transformed))
    assert poly_slot(z1,BETA)!=(0,0)
    assert mul(lam,z0)==ZERO
    wfold=(z0,z1)
    yfold=(add(mul(z0,y0[0]),mul(z1,y1[0])),add(mul(z0,y0[1]),mul(z1,y1[1])))
    assert matvec(F,wfold)==yfold
    assert sum(min(c,Q-c)**2 for c in z0)+sum(min(c,Q-c)**2 for c in z1)==46
    assert 46 <7*7
    # t_fold = z0*t0+z1*t1, and MLE[wfold](r1) is identical in Rq via
    # the canonical diagonal subfield embedding.
    # In selected slot the terminal equality can be checked in K.
    for s in range(64):
        z0s=CRT_field_image(z0,s);z1s=CRT_field_image(z1,s)
        tfs=fa(fm(z0s,t0),fm(z1s,t1))
        actuals=fa(fm(z0s,fs(F1,r1)),fm(z1s,r1))
        assert tfs==actuals
    return {'seed':seed,'accepted_internal_projection_trace_check':True,
            'random_finite_field_sumcheck_rounds':len(rounds),
            'all_sumcheck_round_consistency':True,
            'random_subfield_batching_slot_count':len(delta),
            'all_ring_claims_true_for_fake_w':True,
            'input0_relation_empty_for_fixed_key':True,
            'output_relation_true_for_two_short_ring_polynomials':True,
            'folded_witness_squared_norm':46,
            'folded_bound_squared':49,
            'sample_key_draws_until_invertible':draws,
            'terminal_r0':list(r0),'terminal_r1':list(r1),
            'sample_sumcheck_message_pair':[[list(pair[0]),list(pair[1])] for pair in rounds]}

def sum_poly(polys):
    out=[0]*N
    for p in polys:
        for i,a in enumerate(p):out[i]+=a
    return tuple(x%Q for x in out)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--trials',type=int,default=4)
    p.add_argument('--output',default=str(Path(__file__).with_name('actual_full_transcript_results.json')))
    a=p.parse_args()
    c=certify_zero_candidates(Path(__file__).with_name('actual_q50_candidate_codes_all.txt'),archive_examples=1)
    chosen=c['example_bases'][0]
    poly=[0]*64
    for i,s in zip(chosen['positions'],chosen['signs']):poly[i]=s
    result={'scope':'Original Figure2, true J/trace/ring batching/subfield batching/two sumcheck rounds; not Rust FS bytes',
            'trials':[run_one(seed,poly) for seed in range(a.trials)]}
    Path(a.output).write_text(json.dumps(result,indent=2))
    print(json.dumps({'n_trials':len(result['trials']), 'all_trials_accepted':True,
            'first':result['trials'][0]},indent=2))
