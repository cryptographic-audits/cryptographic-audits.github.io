#!/usr/bin/env python3
"""Exact-arithmetic conditional random-key attack ledger for original PikkuFold.

Parameters k=2, m=2^18 ring elements per fresh input, n=12 commitment rows,
d=3, mu=2, q=2^50-2687, phi=128, e=a=2, weight23, gamma=8.357.
Choose beta_in=1 (NOT the benchmark's 1024 sqrt(M)), beta_acc=1,
beta_out_prime=7. No SIS estimator, no Rust/Fiat-Shamir forgery.
All decisive inequalities use integers/Fraction, no floating point tests.
"""
from fractions import Fraction as F
from math import comb,log2,sqrt,gcd,isqrt
from pathlib import Path
import json,sys

Q=(1<<50)-2687
PHI=128
M=1<<18
DIM=M*PHI
NCOM=12
K=2
GAMMA=F(8357,1000)
WEIGHT=23
SOURCE_CANDIDATES=int(sys.argv[1]) if len(sys.argv)>1 else 4337664
BASE=2**23*comb(128,23)
assert Q>2**49 and Q%256==129
# An exact Pocklington certificate for q, and the selected 128th root.
P_FACTOR=13470280279
assert Q-1==128*653*P_FACTOR and P_FACTOR*P_FACTOR>Q
assert all(P_FACTOR%d for d in range(2,isqrt(P_FACTOR)+1))
assert pow(2,Q-1,Q)==1 and gcd(pow(2,(Q-1)//P_FACTOR,Q)-1,Q)==1
BETA=739582794740178
assert pow(BETA,64,Q)==Q-1 and pow(BETA,128,Q)==1
assert pow(BETA,(Q-1)//2,Q)==Q-1
assert M==1<<18 and DIM==1<<25

# Three successive 256-row JL layers, including two coarse layers and a final fine layer:
N_b=[2*M, 1<<13, 256,256]
nu=[19,13,8,8]
rows=[256]*3
widths=[16384,8192,256]
reps=[32,1,1]
assert reps[0]*widths[0]==N_b[0]
assert reps[1]*widths[1]==N_b[1]==reps[0]*rows[0]
assert reps[2]*widths[2]==N_b[2]==reps[1]*rows[1]
assert reps[2]==1 and N_b[3]==rows[2]
L_SC=sum(nu[:-1])
assert L_SC==40
KAPPA_PROJ=F(PHI*reps[0]+PHI*reps[1]+1,2**128)
assert KAPPA_PROJ==F(4225,2**128)

# JL coefficients are squared constants from the paper's 128-bit Table 1.
JL_U2=F(1716,5)
JL_LO2=F(2737,100)
BETA_IN=F(1)
BETA_INP_SQUARED=2*(JL_U2/JL_LO2)**3
assert F(3943)<BETA_INP_SQUARED<F(3944)<F(63*63)
# Any norm <= beta_in_prime integral candidate w differs from fake e0 by h with ||h||<64.
assert 64**128==2**768
assert Q**16>2**768  # 8 nonzero CRT roots impossible for h with norm <64.
# For any nonzero component h_i, at most 7 of 64 quadratic CRT slots can vanish.
MAX_H_ZERO_SLOTS=7
MIN_X_ACTIVE_SLOTS=64-1-MAX_H_ZERO_SLOTS
assert MIN_X_ACTIVE_SLOTS==56

# Count all integral vectors in dimension DIM with coefficient norm squared <3944:
# coefficientwise theta bound at t=14 ln 2:
#   #Ball <= 2^(14*3944) (1+2/(2^14-1))^DIM
#         <= 2^(14*3944 + 3*DIM/(2^14-1)), using ln(2)>2/3.
BALL_BITS_UPPER=14*3944 + F(3*DIM,2**14-1)
assert BALL_BITS_UPPER < 61361
# For a fixed candidate w, if h=w-e0 !=0, then x=w-(e0-lambda/2*e0)
# has at least MIN_X_ACTIVE_SLOTS nonzero CRT slots.  Random F is 12xm, hence
# Pr[F x=0] <= q^(-2*n*MIN_X_ACTIVE_SLOTS)=q^(-1344).
BAD_KEY_PROB_UPPER=F(1,Q**(2*NCOM)) + F(2**61361,Q**(2*NCOM*MIN_X_ACTIVE_SLOTS))
assert BAD_KEY_PROB_UPPER<F(1,2**1175)

# Norm and SIS: beta_in=1, beta_acc=1, extraction beta_out_prime=7.
BETA_OUT=1+2*GAMMA
BETA_OUTP=F(7)
RHO=(2*GAMMA)**K
BETA_BIND=(K+1)*BETA_OUTP*RHO
BETA_SIS=max(8*GAMMA*BETA_OUTP,2*BETA_BIND*RHO)
assert BETA_SIS<Q
BETA_ACCP_SQUARED=None  # beta_out_prime + k*gamma*sqrt(BETA_INP_SQUARED)
assert BETA_INP_SQUARED*126**2 <Q*Q  # strongest modular constraint (j=0), check all next
assert BETA_INP_SQUARED*JL_LO2**2*126**2<Q*Q

# H1's nominal instance ONLY, conditioned on its unproved |C|>=q^2 prerequisite.
EPS_H1=F(64,Q**2)
KAPPA_MAIN=F(276,Q**2)+KAPPA_PROJ
KAPPA_APP=F(406,Q**2)+KAPPA_PROJ
# From certified explicit zero-fibre list, uniform post-rejection support C
# satisfies Pr[z0 in this fibre]>=SOURCE_CANDIDATES / (2^23 binom(128,23)).
P_CERTIFIED=F(SOURCE_CANDIDATES,BASE)
JOINT_LOWER=(1-BAD_KEY_PROB_UPPER)*(1-KAPPA_PROJ)*P_CERTIFIED
assert 0<JOINT_LOWER<1
assert JOINT_LOWER>KAPPA_MAIN
assert JOINT_LOWER>KAPPA_APP
assert JOINT_LOWER>F(1,2**90)

out={
 'scope':'Original Figure2/Theorem1 conditional H1 quantitative attack: full benchmark m=2^18,d=3,n=12 shapes, but beta_in=1 and no real Rust/FS execution; no unconditional SIS break claimed',
 'q':Q,'phi':PHI,'slot_degree':2,'subfield_degree':2,
 'm_ring_elements':M,'total_integer_coefficients_per_source':DIM,
 'commitment_rows':NCOM,'k':K,'d':3,'mu':2,
 'boundary_lengths':N_b,'boundary_logs':nu,'layer_widths_ring_elements':widths,
 'layer_repetitions':reps,'sumcheck_rounds_excluding_output_boundary':L_SC,
 'beta_in':1,'beta_acc':1,'beta_out':str(BETA_OUT),'beta_out_prime':str(BETA_OUTP),
 'beta_in_prime_squared':str(BETA_INP_SQUARED),
 'beta_in_prime_approx_display':sqrt(float(BETA_INP_SQUARED)),
 'nonzero_h_norm_squared_strict_upper':4096,
 'maximum_vanishing_quadratic_slots_for_nonzero_h':MAX_H_ZERO_SLOTS,
 'minimum_active_slots_for_x_outside_idempotent_slot':MIN_X_ACTIVE_SLOTS,
 'lattice_ball_count_log2_upper_exact':str(BALL_BITS_UPPER),
 'lattice_ball_count_strictly_below_2_pow_61361':True,
 'random_F_source_has_short_opening_prob_strict_bound':'q^-24 + 2^61361 / q^1344 < 2^-1175',
 'jl_projection_failure_upper':str(KAPPA_PROJ),
 'beta_sis':str(BETA_SIS),'beta_sis_less_q':True,
 'challenge_fibre_certified_count':SOURCE_CANDIDATES,
 'challenge_base_cardinality':BASE,
 'challenge_success_lower_exact':str(P_CERTIFIED),
 'key_and_JL_joint_lower_formula':'(1 - (q^-24+2^61361/q^1344))*(1-4225/2^128)*%d/N0' % SOURCE_CANDIDATES,
 'nominal_H1_eps':str(EPS_H1),
 'nominal_kappa_main_upper_exact':str(KAPPA_MAIN),
 'nominal_kappa_appendix_upper_exact':str(KAPPA_APP),
 'attack_exceeds_nominal_main':True,'attack_exceeds_nominal_appendix':True,
 'ratio_attack_to_main_lower_display':float(JOINT_LOWER/KAPPA_MAIN),
 'ratio_attack_to_appendix_lower_display':float(JOINT_LOWER/KAPPA_APP),
 'attack_success_lower_bits_display':-log2(float(JOINT_LOWER)),
 'conditional_SIS_statement':'If this random-key SIS instance satisfies 128-bit hardness, a black-box extractor satisfying the nominal H1-instantiated kappa would break that hardness; no SIS estimator was run.',
 'important_conditions':['H1 uses |C|>=q^2, still not independently established for exact gamma=8.357','beta_in=1, not the actual benchmark value 1024 sqrt(2^25)','CRT zero-fibre support count is a finite lower bound; it does not rely on population acceptance rate','No claim to have run full d3 Rust/Fiat-Shamir prover']
}
path=Path(__file__).resolve().parent/'rank12_d3_exact_ledger.json'
path.write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(json.dumps({k:out[k] for k in ('sumcheck_rounds_excluding_output_boundary','beta_in_prime_squared','random_F_source_has_short_opening_prob_strict_bound','challenge_fibre_certified_count','attack_success_lower_bits_display','ratio_attack_to_main_lower_display','ratio_attack_to_appendix_lower_display')},indent=2))
