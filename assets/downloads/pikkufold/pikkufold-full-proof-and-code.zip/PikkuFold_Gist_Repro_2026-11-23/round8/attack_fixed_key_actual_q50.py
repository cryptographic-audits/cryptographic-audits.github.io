#!/usr/bin/env python3
"""Actual-parameter fixed-key adversarial PikkuFold witness/proof attack.

ORIGINAL paper, not the author's proposed repair. Ring dimension 128,
q=2^50-2687, fixed-weight23 and operator-norm rejection Gamma=8.357.

Theorem 1 instance: k=2, m=2, n_com=2, d=1 (one fine layer), 256 JL rows,
mu=2, e=a=2, beta_in=2, beta_acc=1, beta'_out=7.

An invertible random public commitment key F is fixed before all verifier
randomness. The first public source statement has NO opening satisfying its
public multilinear evaluation, yet the prover knows a fake source witness
satisfying every internal (projection and sumcheck) constraint. With probability
at least K/N_base over uniformly accepted weight23 challenges, the folding
commitment residual lies in one CRT ideal annihilated by z0 and the final
output has a valid short opening.

K is a deterministic count of distinct norm-certified accepted challenges.
The assertion that |C|>=q^2 is explicitly conditional: if the original
H1 instantiation assumes it, its nominal epsilon_C=64/q^2 is smaller than
our rigorous actual error lower bound. This does NOT falsify Theorem 1 with
the TRUE (and larger) sampler epsilon_C, and does not implement the fixed
k=2,d=3,high-dimensional Rust Fiat-Shamir schemelet binary.
"""
from fractions import Fraction as Fr
from pathlib import Path
from random import Random
import math,json,argparse
from math import gcd
import numpy as np
from reproduce_enumeration import certified_unit_table,SCALE
from verify_actual_q50_zeros import decode,run as certify_search

Q=(1<<50)-2687
N=128
BETA=739582794740178
WEIGHT=23
GAMMA=Fr(8357,1000)
ZERO=(0,)*N
ONE=(1,)+(0,)*(N-1)

def add(x,y):return tuple((a+b)%Q for a,b in zip(x,y))
def neg(x):return tuple(-a%Q for a in x)
def sub(x,y):return add(x,neg(y))
def scale(x,c):return tuple((a*c)%Q for a in x)
def mul(x,y):
    out=[0]*N
    for i,a in enumerate(x):
        if a==0:continue
        for j,b in enumerate(y):
            if b==0:continue
            h=i+j
            if h<N:out[h]+=a*b
            else:out[h-N]-=a*b
    return tuple(v%Q for v in out)

def poly_slot(f,root):
    a=b=0;power=1
    for j in range(N//2):
        a+=f[2*j]*power;b+=f[2*j+1]*power
        power=power*root%Q
    return (a%Q,b%Q)

def unit(x,slot_roots):return all(poly_slot(x,r)!=(0,0) for r in slot_roots)

def ring_sum(xs):
    accum=ZERO
    for x in xs:accum=add(accum,x)
    return accum

def matvec(F,w):return tuple(ring_sum(mul(f,a) for f,a in zip(row,w)) for row in F)
def det2(F):return sub(mul(F[0][0],F[1][1]),mul(F[0][1],F[1][0]))

def make_idempotent(beta):
    assert pow(beta,64,Q)==Q-1 and pow(beta,128,Q)==1
    inv=pow((64*pow(beta,63,Q))%Q,-1,Q)
    lam=[0]*N
    for j in range(64):lam[2*(63-j)]=inv*pow(beta,j,Q)%Q
    lam=tuple(lam)
    assert lam!=ONE and lam!=ZERO
    assert mul(lam,lam)==lam
    half=pow(2,-1,Q)
    dinv=sub(ONE,scale(lam,half))
    assert mul(add(ONE,lam),dinv)==ONE
    return lam,dinv

def accepted_example(coeffs,root_re,root_im):
    supp=[i for i,v in enumerate(coeffs) if v]
    sign=np.array([coeffs[i] for i in supp],dtype=np.int64)
    vr=np.sum(root_re[supp]*sign[:,None],axis=0)
    vi=np.sum(root_im[supp]*sign[:,None],axis=0)
    upper=int(np.max((np.abs(vr)+WEIGHT)**2+(np.abs(vi)+WEIGHT)**2))
    limit=(8357**2*SCALE**2)//10**6
    assert upper<=limit
    full=[0]*N
    for i,x in enumerate(coeffs):full[2*i]=x
    return tuple(full),upper

def random_invertible_key(roots,seed=20261123):
    random=Random(seed)
    for draws in range(1,16):
        F=tuple(tuple(tuple(random.randrange(Q) for _ in range(N)) for _ in range(2)) for _ in range(2))
        if unit(det2(F),roots):return F,draws
    raise AssertionError('failed to find invertible random F')

def run(source,skip_finite_certificate=False):
    # Compact Pocklington certificate for the actual 50-bit prime.
    r_cert=13470280279
    assert Q-1==128*653*r_cert and r_cert*r_cert>Q
    assert all(r_cert % d for d in range(2,math.isqrt(r_cert)+1))
    assert pow(2,Q-1,Q)==1 and gcd(pow(2,(Q-1)//r_cert,Q)-1,Q)==1
    assert Q%256==129 and (Q-1)%256==128
    assert pow(BETA,(Q-1)//2,Q)==Q-1 # X^2-BETA irreducible over F_q.
    # Exact uniform sampler support membership and zero-slot population subset.
    if not skip_finite_certificate:
        census=certify_search(source,archive_examples=2)
        K=census['distinct_certified_accepted_zero_slot_challenges']
        assert census['ambiguous_candidates']==0 and K>=276992
    else:
        record=Path(__file__).with_name('actual_q50_zero_cert_results_multi.json')
        census=json.loads(record.read_text())
        K=census['distinct_certified_accepted_zero_slot_challenges']
    codes=next(x for x in Path(source).read_text().splitlines() if x.strip())
    # To ensure chosen candidate is an accepted challenge, use the first
    # independently certified example rather than the first generated item.
    eb=census['example_bases'][0]
    a=[0]*64
    for p,s in zip(eb['positions'],eb['signs']):a[p]=s
    root_re,root_im=certified_unit_table(64)
    z0,example_high=accepted_example(a,root_re,root_im)
    assert (sum(v*pow(BETA,j,Q) for j,v in enumerate(a))%Q)==0
    assert sum(int(t!=0) for t in z0)==WEIGHT
    assert sum(x*x for x in z0)==WEIGHT
    assert pow(BETA,64,Q)==Q-1
    roots=[pow(BETA,2*j+1,Q) for j in range(64)]
    assert len(set(roots))==64
    assert all(pow(r,64,Q)==Q-1 for r in roots)
    lam,dinv=make_idempotent(BETA)
    assert poly_slot(lam,BETA)==(1,0)
    assert all(poly_slot(lam,r)==((1,0) if r==BETA else (0,0)) for r in roots)
    assert mul(lam,z0)==ZERO
    # A norm-preserving Galois transform constructs an accepted challenge
    # OUTSIDE the selected CRT zero fibre, as a negative-control test.
    alternate=[0]*64
    for j,c in enumerate(a):
        jj=(3*j)%128
        if jj>=64: alternate[jj-64]=-c
        else: alternate[jj]=c
    z0_outside=tuple(value for c in alternate for value in (c,0))
    assert sum(c!=0 for c in z0_outside)==WEIGHT
    assert poly_slot(z0_outside,BETA)!=(0,0)
    assert mul(lam,z0_outside)!=ZERO
    z_outside_cert,_=accepted_example(alternate,root_re,root_im)
    assert z0_outside==z_outside_cert

    # Fixed public random key F, selected before any verifier coins/challenges.
    F,draws=random_invertible_key(roots)
    assert unit(det2(F),roots)
    utrue=(dinv,ZERO)
    wfake0=(ONE,ZERO)
    wtrue1=(ZERO,ONE)
    y0=matvec(F,utrue)
    y1=matvec(F,wtrue1)
    assert y0!=matvec(F,wfake0)
    assert dinv!=ONE
    # Principal relation for input0 claims t0=1 at s0=0, but the unique
    # preimage of y0 has its first coordinate 1-lambda/2 != 1.
    assert matvec(F,utrue)==y0
    assert utrue[0]!=ONE
    # Input1 claims t1=0 at s1=0 and genuinely uses (0,1).
    assert wtrue1[0]==ZERO
    # Accumulator is zero, all original evaluate/trace/sumcheck claims are
    # true for wfake0 and wtrue1; only Fwfake0=y0 fails.
    z1=tuple(c%Q for c in z0_outside) # Accepted independently of the zero-slot condition.
    wfold=(z0,z1)
    yfold=(add(mul(z0,y0[0]),mul(z1,y1[0])),
           add(mul(z0,y0[1]),mul(z1,y1[1])))
    assert matvec(F,wfold)==yfold
    # For the Galois-moved accepted challenge, the same fake strategy does
    # NOT give the verifier a valid output opening under the fixed key.
    yfold_bad=tuple(add(mul(z0_outside,y0[i]),mul(z1,y1[i])) for i in range(2))
    wfold_bad=(z0_outside,z1)
    assert matvec(F,wfold_bad)!=yfold_bad
    assert sum(z*z for z in z0)==23
    assert sum(z!=0 for z in z1)==23 and all(z in (0,1,Q-1) for z in z1)
    assert sum(min(c%Q,(-c)%Q)**2 for ring in (z0,z1) for c in ring)==46<7*7
    assert matvec(F,wfold)==tuple(add(mul(z0,y0[i]),mul(z1,y1[i])) for i in range(2))
    # Output evaluation is correct for every random sumcheck point r (in Fq2),
    # by the universal identity MLE[z0*e0+z1*e1](r)=z0*(1-r)+z1*r.
    r=17
    t_fold=add(scale(z0,1-r),scale(z1,r))
    assert t_fold == add(mul(z0,scale(ONE,1-r)),mul(z1,scale(ONE,r)))

    k=2;d=1;mu=2;nu0=2;nu1=8;a_subfield=e=2
    omega_sq=k*Fr(2)**2*Fr('343.2')
    beta_inp_sq=omega_sq/Fr('27.37')
    assert 126**2*omega_sq<Q**2
    assert (256*4)<omega_sq  # Any ternary projection of the sparse fake W.
    betaprimeout=Fr(7)
    rho=(2*GAMMA)**k
    betabind=(k+1)*betaprimeout*rho
    beta_sis_main=max(8*GAMMA*betaprimeout,2*betabind*rho)
    beta_sis_appendix=6*GAMMA*betaprimeout
    assert beta_sis_main <Q and beta_sis_appendix <Q
    # A unit determinant means every F-kernel vector is divisible by q.
    # Thus neither SIS-break relation contains a nonzero vector of norm <q.

    Nbase=2**23*math.comb(128,23)
    assert K<=Nbase
    p_lower=Fr(K,Nbase)
    pointwise_lower=Fr(K-1,Nbase)
    nominal_eps=Fr(64,Q*Q)
    assert pointwise_lower>nominal_eps
    # Conditional on the original Heuristic 1 cardinality precondition |C|>=q^2,
    # we can strictly UPPER-bound the nominal Theorem 1 knowledge-error claim
    # despite not knowing |C| or the true acceptance probability.
    kappa_main_nominal_upper=(Fr(k,Q*Q)+k*nominal_eps+Fr(1,2**128)
         +Fr(nu1**mu,Q**mu)+Fr(1,Q**e)+Fr(2*nu0+1,Q**a_subfield))
    # The Appendix A bound uses 2k(1/|C|+eps) for final challenge layer.
    kappa_app_nominal_upper=(Fr(2*k,Q*Q)+2*k*nominal_eps+Fr(1,2**128)
         +Fr(nu1**mu,Q**mu)+Fr(1,Q**e)+Fr(2*nu0+1,Q**a_subfield))
    key_unit_prob_lower=1-Fr(64,Q*Q)-Fr(64,Q**4)
    attack_prob_lower=p_lower*key_unit_prob_lower
    assert attack_prob_lower > kappa_main_nominal_upper
    assert attack_prob_lower > kappa_app_nominal_upper
    assert attack_prob_lower > Fr(1,2**90)

    result={
      'target':'Original PikkuFold Fig.2 / Theorem1; FIXED uniformly random public key, actual q, weight23,gamma8.357',
      'scope':'Knowledge-error attack against Heuristic-1-instantiated quantitative claims, not against true-epsilon conditional theorem or compiled Rust schemelet.',
      'q':Q,'ring':'Z[X]/(X^128+1)','phi':N,'slot_degree_e':e,'subfield_degree_a':a_subfield,
      'k':k,'m':2,'n_commitment':2,'d':d,'mu':mu,'JL_rows':256,
      'challenge_fixed_weight':WEIGHT,'challenge_gamma':'8357/1000','CRT_root_beta':BETA,
      'challenge_zero_fiber_certified_lower':K,
      'challenge_sample_base_count':Nbase,
      'challenge_accepted_set_cardinality_condition':'Unknown; if >=q^2 paper H1 applies but nominal error invalid; if <q^2 paper H1 assumption fails.',
      'certified_zero_fiber_candidate_orbits':census['accepted_distinct_signed_shift_orbits'],
      'certified_candidate_zero_errors':census['ambiguous_candidates'],
      'explicit_zero_challenge_support':[2*j for j,x in enumerate(a) if x],
      'explicit_zero_challenge_signs':[x for x in a if x],
      'explicit_zero_challenge_norm_upper_scaled_sq':example_high,
      'challenge_norm_limit_scaled_sq':(8357**2*SCALE**2)//10**6,
      'example_folding_challenge_z1':'accepted Galois transform of z0, NONZERO at the selected slot; success event constrains only z0',
      'idempotent_64_coefficients_verified':True,
      'explicit_outside_zero_slot_accepted_challenge_fails_output_check':True,
      'random_key_fixed_before_challenges':True,
      'sample_key_draws_until_unit_determinant':draws,
      'key_det_unit':True,
      'public_input0_evaluation_claim':'s0=0; t0=1; y0=F*(1-lambda/2,0)',
      'public_input1_evaluation_claim':'s1=0; t1=0; y1=F*(0,1)',
      'input0_relation_empty_even_without_norm_bound':True,
      'input1_relation_true':True,
      'short_nonzero_SIS_relation_empty_if_key_unit':True,
      'all_internal_sumcheck_initial_claims_true_for_fake_w':True,
      'terminal_fold_commitment_valid_for_example':True,
      'terminal_fold_evaluation_valid_for_example':True,
      'example_fold_witness_norm_squared':46,
      'target_output_bound_squared':49,
      'omega_squared':str(omega_sq),'beta_in_prime_squared':str(beta_inp_sq),
      'SIS_radius_main':str(beta_sis_main),
      'SIS_radius_appendix':str(beta_sis_appendix),
      'H1_nominal_eps':str(nominal_eps),
      'actual_pointwise_epsilon_lower':'%s / %s'%(K-1,Nbase),
      'pointwise_lower_over_H1_nominal':float(pointwise_lower/nominal_eps),
      'conditional_main_knowledge_error_upper_if_C_ge_q2':str(kappa_main_nominal_upper),
      'conditional_appendix_knowledge_error_upper_if_C_ge_q2':str(kappa_app_nominal_upper),
      'attack_success_probability_lower_over_random_F_and_C':str(attack_prob_lower),
      'attack_success_probability_lower_display':float(attack_prob_lower),
      'attack_lower_negative_log2_display':-math.log2(float(attack_prob_lower)),
      'ratio_attack_to_paper_main_nominal_kappa_upper':float(attack_prob_lower/kappa_main_nominal_upper),
      'ratio_attack_to_paper_appendix_nominal_kappa_upper':float(attack_prob_lower/kappa_app_nominal_upper),
      'ratio_attack_to_2^-90':float(attack_prob_lower*2**90),
      'full_Rust_k2_d3_FS_binary_attack':False,
      'full_pdf_theorem_attack_algebraically_implemented':True,
    }
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',default=str(Path(__file__).with_name('actual_q50_candidate_codes_all.txt')))
    p.add_argument('--output',default=str(Path(__file__).with_name('fixed_key_actual_q50_results.json')))
    p.add_argument('--skip-finite-certificate',action='store_true')
    opts=p.parse_args()
    out=run(opts.source,opts.skip_finite_certificate)
    Path(opts.output).write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in out.items() if k not in ('explicit_zero_challenge_support','explicit_zero_challenge_signs')},ensure_ascii=False,indent=2))
