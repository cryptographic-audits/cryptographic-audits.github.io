#!/usr/bin/env python3
"""Exact-rational-root certified evaluation of generalized-birthday candidates.

No Monte Carlo population inference: all generated candidates are checked
coefficientwise (weight 23), exactly modulo q at a primitive 128th root,
then interval-certified to pass operator norm <=8.357. Signed rotations are
deduplicated explicitly, producing a rigorous FINITE lower bound on the
number of accepted challenges vanishing in a fixed quadratic CRT slot.

Reads actual_q50_candidate_codes.txt from the C++ deterministic search.
"""
import argparse,json,math
from pathlib import Path
import numpy as np
from reproduce_enumeration import certified_unit_table, SCALE

Q=(1<<50)-2687
BETA=739582794740178
N=64
WEIGHT=23

def decode(line):
    codes=[int(x) for x in line.split()]
    assert len(codes)==4
    out=[0]*N
    for group,code in enumerate(codes):
        supp=code&0xffff; negs=code>>16
        assert negs & ~supp==0
        assert supp.bit_count() == (5 if group==3 else 6)
        for j in range(16):
            if (supp>>j)&1: out[group*16+j]=-1 if (negs>>j)&1 else 1
    assert sum(v!=0 for v in out)==WEIGHT
    return tuple(out)

def rotate_full_even(a,t):
    # Signed monomial multiplication by X^t modulo X^128+1.
    out=[0]*128
    for j,c in enumerate(a):
        if not c:continue
        k=2*j+t
        k%=256
        if k>=128:out[k-128]=-c
        else:out[k]=c
    return bytes((x+1 for x in out))  # immutable 0/1/2 representation

def run(source,archive_examples=12):
    re,im=certified_unit_table(64)
    limit=(8357**2*SCALE*SCALE)//10**6
    powbeta=[1]
    for _ in range(1,N):powbeta.append(powbeta[-1]*BETA%Q)
    assert pow(BETA,64,Q)==Q-1
    candidates=[decode(line) for line in Path(source).read_text().splitlines() if line.strip()]
    accepted=[]; unknown=[]; rejected=0
    root_values_nonzero=[]
    for a in candidates:
        value=sum(ai*b for ai,b in zip(a,powbeta))%Q
        assert value==0, 'generalized birthday candidate is not a zero'
        support=[i for i,v in enumerate(a) if v]
        sg=np.array([a[i] for i in support],dtype=np.int64)
        vr=np.sum(re[support]*sg[:,None],axis=0)
        vi=np.sum(im[support]*sg[:,None],axis=0)
        high=int(np.max((np.abs(vr)+WEIGHT)**2+(np.abs(vi)+WEIGHT)**2))
        low=int(np.max(np.maximum(np.abs(vr)-WEIGHT,0)**2+np.maximum(np.abs(vi)-WEIGHT,0)**2))
        if high<=limit:
            accepted.append((a,high))
        elif low>limit:rejected+=1
        else:unknown.append((a,high,low))
    signed_rotations=set()
    orbits=[]
    for a,high in accepted:
        images={rotate_full_even(a,t) for t in range(256)}
        if not images.issubset(signed_rotations):orbits.append((a,high,len(images)))
        signed_rotations.update(images)
    # Parseval/canonical signed rotation preserves exact operator norm and
    # slot zero for every generated member, so all are certified accepted.
    full=len(signed_rotations)
    # Without a population acceptance estimate, |C| <= base cardinality.
    base=2**23*math.comb(128,23)
    eps_nominal_num=64;eps_nominal_denom=Q*Q
    # If the zero fiber includes a fixed anchor among our accepted members,
    # Definition 11 epsilon_C >= (full-1)/|C| >= (full-1)/base.
    surpasses_nominal=(full-1)*eps_nominal_denom > eps_nominal_num*base
    out={
     'source_candidates':len(candidates),
     'certified_accepted_candidates':len(accepted),
     'certified_rejected_candidates':rejected,
     'ambiguous_candidates':len(unknown),
     'accepted_distinct_signed_shift_orbits':len(orbits),
     'distinct_certified_accepted_zero_slot_challenges':full,
     'each_challenge_weight':23,'each_challenge_gamma':'8357/1000',
     'base_set_size_exact':base,
     'H1_nominal_epsilon':'64/q^2',
     'epsilon_C_lower_from_zero_fiber':'(%d-1)/%d'%(full,base),
     'epsilon_C_lower_exceeds_H1_nominal_without_any_population_estimate':surpasses_nominal,
     'example_bases':[{'positions':[i for i,v in enumerate(a) if v],
                       'signs':[v for v in a if v],
                       'certified_upper_scaled_sq':high,
                       'signed_shift_orbit_size':orb}
                      for a,high,orb in orbits[:archive_examples]],
     'unknown_candidates_examples':len(unknown),
     'notes':'No full-population count, no protocol attack security bound, no floating-norm acceptance decisions.'
    }
    return out

if __name__=='__main__':
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('--source',default=str(Path(__file__).with_name('actual_q50_candidate_codes.txt')))
    arg.add_argument('--output')
    opt=arg.parse_args()
    out=run(opt.source)
    if opt.output:Path(opt.output).write_text(json.dumps(out,indent=2))
    print(json.dumps({k:v for k,v in out.items() if k!='example_bases'},indent=2))
