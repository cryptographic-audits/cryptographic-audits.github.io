// Deterministic generalized-birthday search, exact integer arithmetic.
// Target: a(Y) in {-1,0,1}[Y]/(Y^64+1) of weight 23, a(beta)=0 mod q,
// q=2^50-2687, primitive128-th root beta=739582794740178.
// Split degree positions into 4 disjoint groups of 16, weights (6,6,6,5).
// Each group contribution uses exact integer residues mod q. Meet-in-middle
// bucket filtering + sorted AB pairs finds genuine zero-sum solutions.
// Membership in ||a||op<=8.357 is NOT decided here; Python exact-root
// certificate will subsequently classify outputs.
#include <bits/stdc++.h>
using namespace std;
using u64=uint64_t; using u32=uint32_t;
const u64 Q=1125899906839937ULL;
const u64 BETA=739582794740178ULL;
const u64 MASK=(1u<<16)-1;
static inline u64 mulmod(u64 a,u64 b){return (u64)((__uint128_t)a*b%Q);}
struct Item {u64 value;u32 code;};
struct Pair {u64 value;u32 first,second;bool operator<(Pair const& y) const{return value<y.value;}};

vector<Item> make_group(int group,int weight,const vector<u64>& powers){
    vector<Item> out;out.reserve(weight==6?512512:139776);
    for(u32 mask=0;mask<65536;mask++){
        if(__builtin_popcount(mask)!=weight)continue;
        int pos[16],k=0;
        for(int j=0;j<16;j++)if(mask>>j&1)pos[k++]=j;
        for(u32 signs=0;signs<(1u<<weight);signs++){
            long long val=0;
            u32 negative=0;
            for(int t=0;t<weight;t++){
                u64 p=powers[group*16+pos[t]];
                if(signs>>t&1)val+=(long long)p;
                else {val-=(long long)p;negative|=1u<<pos[t];}
            }
            long long v=val%(long long)Q;
            if(v<0)v+=(long long)Q;
            out.push_back({(u64)v, mask|(negative<<16)});
        }
    }
    return out;
}

int main(int argc,char**argv){
    string output=argc>1?argv[1]:"actual_q50_candidate_codes.txt";
    u64 targetAB=(argc>2?std::stoull(argv[2]):0)&MASK;
    auto t0=chrono::steady_clock::now();
    vector<u64> powers(64);powers[0]=1;
    for(int i=1;i<64;i++) powers[i]=mulmod(powers[i-1],BETA);
    if(mulmod(powers[63],BETA)!=Q-1){cerr<<"Root order check failed\n";return 1;}
    vector<Item>A=make_group(0,6,powers),B=make_group(1,6,powers),
                C=make_group(2,6,powers),D=make_group(3,5,powers);
    cerr<<"List sizes: "<<A.size()<<" "<<B.size()<<" "<<C.size()<<" "<<D.size()<<"\n";
    vector<vector<Item>> bucketB(1u<<16),bucketD(1u<<16);
    for(const auto &b:B)bucketB[b.value&MASK].push_back(b);
    for(const auto &d:D)bucketD[d.value&MASK].push_back(d);
    vector<Pair>AB;AB.reserve(4500000);
    for(const auto &a:A){
       u64 low=a.value&MASK;
       u64 keys[2]={(targetAB-low)&MASK,((targetAB+(Q&MASK))-low)&MASK};
       for(u64 key:keys){
           for(const auto& b:bucketB[key]){
               u64 v=a.value+b.value;if(v>=Q)v-=Q;
               if((v&MASK)==targetAB)AB.push_back({v,a.code,b.code});
           }
       }
    }
    cerr<<"Level1 AB records: "<<AB.size()<<"\n";
    sort(AB.begin(),AB.end());
    ofstream ofs(output);if(!ofs){cerr<<"Failed to create output";return 2;}
    u64 countCD=0,solutions=0;
    u64 targetLow=((Q&MASK)-targetAB)&MASK;
    for(const auto &c:C){
        u64 low=c.value&MASK;
        u64 keys[2]={(targetLow-low)&MASK,((targetLow+(Q&MASK))-low)&MASK};
        for(u64 key:keys){
            for(const auto &d:bucketD[key]){
                u64 v=c.value+d.value;if(v>=Q)v-=Q;
                if((v&MASK)!=targetLow)continue;
                countCD++;
                u64 required=v==0?0:(Q-v);
                Pair keyobj{required,0,0};
                auto it=lower_bound(AB.begin(),AB.end(),keyobj);
                for(;it!=AB.end() && it->value==required;it++){
                    // Each record is a full, exactly weight-23 signed polynomial.
                    ofs<<it->first<<' '<<it->second<<' '<<c.code<<' '<<d.code<<'\n';
                    solutions++;
                }
            }
        }
    }
    ofs.close();
    double elapsed=chrono::duration<double>(chrono::steady_clock::now()-t0).count();
    cerr<<"Level1 CD records: "<<countCD<<"\n";
    cerr<<"Exact zero-sum polynomials: "<<solutions<<"\n";
    cerr<<"Elapsed sec: "<<elapsed<<"\n";
    cout<<"{\"AB_records\":"<<AB.size()<<",\"CD_records\":"<<countCD
        <<",\"solutions\":"<<solutions<<",\"seconds\":"<<elapsed<<"}"<<endl;
}
