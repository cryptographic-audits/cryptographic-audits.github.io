# PikkuFold attack continuation — fixed-key, actual q (2026-11-23)

Read `ROUND8_ATTACK_REPORT_CN.md` first. Scope: a deterministic zero-fibre challenge subset and a new random-rank-12 large-dimension theoretical attack, **conditional on H1's nominal cardinality/pseudorandomness claims and the SIS hardness assumption for computational interpretation**. It is not a production Rust/Fiat–Shamir forgery.

Run `python verify_many_orbits.py candidates_0_511.txt` to recertify all 130,629 exact zero-sum candidates and count 4,337,664 distinct accepted challenges. Run `python certify_rank12_large_instance.py` to verify the 40-round three-layer dimension bookkeeping, random-key short-opening union bound, SIS radius comparison, and conditional knowledge-error gap using exact integers and rationals. `precision_26_check.log` records an independent 26-bit-table recalculation matching the 24-bit result exactly. NumPy is required only for the finite norm certificate. The mathematical parameter ledger script uses only the Python standard library.

`attack_actual_full_transcript.py --trials 4` and `attack_fixed_key_actual_q50.py` are included from the prior, much smaller k2/d1 exact algebraic model; they are not claimed to run the full 3-layer benchmark. Run them on the retained 8,106-candidate `actual_q50_candidate_codes_all.txt`, not on the expanded 130,629-candidate file.

To generate more candidates, compile `actual_q50_zero_sum_many.cpp` with C++17 and invoke it with distinct 16-bit bucket offsets; all newly generated candidates must be independently certified and orbit-deduplicated. The expanded source includes offsets 0 through 511.

All files are self-contained relative to this directory; scripts neither require a network connection nor modify the original author project.
