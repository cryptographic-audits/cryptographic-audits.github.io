// Deterministic algebraic PoC: a 256x257 biased-ternary JL submatrix,
// and coefficients a with a_0=1, J*a=0 mod q.
// This tests the projection-kernel stage, NOT complete Rust Fiat-Shamir forgery.
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <vector>
using u64=uint64_t; using u128=__uint128_t;
static constexpr u64 Q=(1ULL<<50)-2687;
static constexpr int R=256, C=257;
inline u64 mul(u64 x,u64 y){return (u64)((u128)x*y%Q);}
inline u64 sub(u64 x,u64 y){return x>=y?x-y:x+Q-y;}
inline u64 add(u64 x,u64 y){u64 z=x+y; return z>=Q?z-Q:z;}
u64 powq(u64 a,u64 n){u64 x=1;while(n){if(n&1)x=mul(x,a);a=mul(a,a);n>>=1;}return x;}
int main(int argc,char**argv){
 try{
  const char* dest=argc>1?argv[1]:"first_layer_kernel_certificate.txt";
  u64 seed=argc>2?std::stoull(argv[2]):20261123ULL;
  std::mt19937_64 rng(seed);
  std::vector<std::vector<int>> J(R,std::vector<int>(C));
  std::vector<std::vector<u64>> A(R,std::vector<u64>(C));
  for(int i=0;i<R;i++)for(int j=0;j<C;j++){
    unsigned b=(unsigned)(rng()&3ULL); int v=b==0?1:(b==1?-1:0);
    J[i][j]=v;
    if(j>=1)A[i][j-1]=v==-1?Q-1:(u64)v;
  }
  for(int i=0;i<R;i++)A[i][R]=(J[i][0]==1?Q-1:(J[i][0]==-1?1:0));
  for(int col=0;col<R;col++){
    int piv=col;
    while(piv<R && A[piv][col]==0)piv++;
    if(piv==R)throw std::runtime_error("selected 256 random columns singular; rerun with different seed");
    if(piv!=col)std::swap(A[piv],A[col]);
    u64 inv=powq(A[col][col],Q-2);
    for(int j=col;j<=R;j++)A[col][j]=mul(A[col][j],inv);
    for(int i=col+1;i<R;i++){
      u64 v=A[i][col]; if(v==0)continue;
      for(int j=col+1;j<=R;j++)A[i][j]=sub(A[i][j],mul(v,A[col][j]));
      A[i][col]=0;
    }
  }
  std::vector<u64> a(C);a[0]=1;
  for(int i=R-1;i>=0;i--){
    u64 rhs=A[i][R];
    for(int j=i+1;j<R;j++)rhs=sub(rhs,mul(A[i][j],a[j+1]));
    a[i+1]=rhs;
  }
  for(int i=0;i<R;i++){
    u64 v=0;for(int j=0;j<C;j++){
      if(J[i][j]==1)v=add(v,a[j]); else if(J[i][j]==-1)v=sub(v,a[j]);
    }
    if(v!=0)throw std::runtime_error("nonzero first layer projection");
  }
  std::ofstream f(dest);if(!f)throw std::runtime_error("output open failed");
  f<<Q<<" "<<R<<" "<<C<<" "<<seed<<"\n";
  for(int i=0;i<R;i++){for(int j=0;j<C;j++)f<<J[i][j]<<(j+1==C?'\n':' ');}
  f<<"coeff";for(u64 v:a)f<<" "<<v;f<<"\n";
  std::cout<<"PASS: rank256, a0=1, exact 256x257 zero image mod q; seed="<<seed<<"\n";
 }catch(const std::exception& e){std::cerr<<"ERROR: "<<e.what()<<"\n";return 1;}
}
