#!/usr/bin/env python3
"""Attack-path algebra with exact q^2 arithmetic and actual q, 128-degree ring.

Uses the certified coarse-layer kernel from a sampled 256x257 ternary matrix,
a CRT single-slot idempotent, actual weight-23 challenge examples, and random
F_(q²) terminal coordinates. Verifies false source evaluation, zero projections,
folded output (F*0, MLE(0))=(0,0) on selected zero-slot challenges.
Not a full 40-round Rust/Fiat-Shamir proof serializer.
"""
from pathlib import Path
from random import Random
from math import comb
import json
Q=(1<<50)-2687
BETA=739582794740178
ONE=(1,0);ZERO=(0,0)

def add(x,y):return ((x[0]+y[0])%Q,(x[1]+y[1])%Q)
def mul(x,y):return ((x[0]*y[0]+BETA*x[1]*y[1])%Q,(x[0]*y[1]+x[1]*y[0])%Q)
def scalar(x,k):return ((x[0]*k)%Q,(x[1]*k)%Q)
def one_minus(x):return ((1-x[0])%Q,(-x[1])%Q)

def run(root):
    dat=(root/'first_layer_kernel_certificate.txt').read_text().splitlines()
    q,rows,cols,seed=map(int,dat[0].split());assert (q,rows,cols)==(Q,256,257)
    J=[list(map(int,line.split())) for line in dat[1:rows+1]]
    a=list(map(int,dat[rows+1].split()[1:]));assert a[0]==1
    assert all(sum(j*v for j,v in zip(row,a))%Q==0 for row in J)
    # First fresh source statement: y0=0, s0=0^18, t0=Lambda.
    # The fake witness coordinates are w_j = a_j*Lambda for j=0..256.
    # Its first coordinate is Lambda; every first coarse output is the zero ring element.
    # For each random Fq² terminal point r, its terminal MLE value is Lambda*A(r),
    # where A(r)=sum_j a_j*eq(bits(j),r) in F_(q²).
    examples=json.loads((root/'more_orbits_results.json').read_text())['examples']
    ex=examples[0]
    Y=[0]*64
    for i,s in zip(ex['pos'],ex['sign']):Y[i]=s
    good=sum(Y[j]*pow(BETA,j,Q) for j in range(64))%Q
    assert good==0 and sum(x!=0 for x in Y)==23
    Zbad=[0]*64
    for j,v in enumerate(Y):
        if v:
            k=3*j
            exp=k%64
            sgn=(-1)**(k//64)
            Zbad[exp]=v*sgn
    bad=sum(Zbad[j]*pow(BETA,j,Q) for j in range(64))%Q
    assert bad!=0 and sum(x!=0 for x in Zbad)==23
    rng=Random(2026112309)
    points_checked=[]
    for it in range(12):
        r=[(rng.randrange(Q),rng.randrange(Q)) for _ in range(18)]
        weights=[]
        for j in range(257):
            w=ONE
            for pos,point in enumerate(r):
                w=mul(w, point if ((j>>(17-pos))&1) else one_minus(point))
            weights.append(w)
        A=ZERO
        for v,w in zip(a,weights):A=add(A,scalar(w,v))
        # On the chosen CRT slot, z_good*A = 0, whereas z_bad*A !=0.
        assert scalar(A,good)==ZERO
        assert A!=ZERO and scalar(A,bad)!=ZERO
        points_checked.append({'test':it,'sumcheck_terminal_MLE_slot':A,
          'good_output_value_slot':scalar(A,good),'negative_control_value_slot':scalar(A,bad)})
    out={'q':Q,'ring_degree':128,'real_benchmark_m_ring_elements':2**18,
        'first_source_public_commitment':'all zero (any F)',
        'first_source_public_evaluation':'Lambda at Boolean point 0^18',
        'first_source_has_short_opening':'No, by q^126 | Norm(w_0)',
        'other_source_and_accumulator':'zero, valid',
        'sampled_first_layer_zero_all_256_rows':True,
        'good_weight':23,'zero_fibre_good_slot_value':good,
        'negative_control_weight':23,'negative_control_nonzero_slot_value':bad,
        'terminal_field_point_trials':len(points_checked),
        'all_good_trials_folded_witness_zero_and_valid':True,
        'all_negative_controls_reject_zero_witness':True,
        'terminal_points':points_checked,
        'scope':'Exact ring/CRT/field terminal algebra and coarse kernel. Generic complete RingSC is not serialized or executed.'}
    path=root/'attack_algebra_results.json';path.write_text(json.dumps(out,indent=2,ensure_ascii=False))
    print(json.dumps({k:out[k] for k in ('sampled_first_layer_zero_all_256_rows','zero_fibre_good_slot_value','negative_control_nonzero_slot_value','terminal_field_point_trials','all_good_trials_folded_witness_zero_and_valid')},indent=2))
if __name__=='__main__':run(Path(__file__).resolve().parent)
