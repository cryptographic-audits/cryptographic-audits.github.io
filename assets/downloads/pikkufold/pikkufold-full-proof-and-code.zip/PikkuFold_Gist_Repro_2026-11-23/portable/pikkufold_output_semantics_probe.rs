//! Test-only semantic check for verify_output with a *scalar* commitment kernel.
//! Invoke with --features scalar-commit-audit; does not call AVX-512 commit_pass.
//! This module tests the output relation; it is NOT a Fiat-Shamir forgery.
use crate::commitment::CommitmentKey;
use crate::config::commitment_rank;
use crate::output::verify_output;
use crate::statement::EvalClaim;
use rokoko::common::init_common;
use rokoko::common::matrix::VerticallyAlignedMatrix;
use rokoko::common::ring_arithmetic::{Representation, RingElement};

fn setup() -> (CommitmentKey, VerticallyAlignedMatrix<RingElement>, EvalClaim, usize) {
    init_common();
    let m = 1usize << 10; // Keep the scalar reference small; no 3 GiB CRS.
    let rank = commitment_rank(m);
    let zero = RingElement::zero(Representation::IncompleteNTT);
    let key = CommitmentKey::sample(m, rank);
    let witness = VerticallyAlignedMatrix {
        data: vec![zero.clone(); m],
        width: 1,
        height: m,
        used_cols: 1,
    };
    let claim = EvalClaim {
        point: vec![zero.clone(); m.ilog2() as usize],
        value: zero,
    };
    (key, witness, claim, rank)
}

#[test]
fn complete_output_accepts_correct_zero_opening() {
    let (key, witness, claim, rank) = setup();
    let zero = RingElement::zero(Representation::IncompleteNTT);
    let commitment = vec![zero; rank];
    assert!(verify_output(&key, &witness, &commitment, &claim, 1.0).is_ok());
    println!("PASS: verify_output accepts rank-{rank} zero commitment with zero witness (scalar backend)");
}

#[test]
fn complete_output_rejects_nonzero_commitment_for_zero_witness() {
    let (key, witness, claim, rank) = setup();
    let mut commitment = vec![RingElement::zero(Representation::IncompleteNTT); rank];
    commitment[0] = RingElement::constant(1, Representation::IncompleteNTT);
    let outcome = verify_output(&key, &witness, &commitment, &claim, 1.0);
    assert!(outcome.is_err(), "a false full-length commitment was accepted");
    println!("PASS: full-length commitment mismatch rejected: {}", outcome.err().unwrap());
}

#[test]
fn empty_commitment_is_accepted_by_current_output_api() {
    let (key, witness, claim, rank) = setup();
    let empty: Vec<RingElement> = Vec::new();
    let outcome = verify_output(&key, &witness, &empty, &claim, 1.0);
    assert!(outcome.is_ok(), "the existing API has unexpectedly been hardened");
    println!("CONFIRMED SHAPE BUG: verify_output accepts length 0 where rank {rank} is required; this is a malformed-input test, not a valid-relation forgery");
}

#[test]
fn complete_output_rejects_wrong_evaluation_for_zero_witness() {
    let (key, witness, mut claim, rank) = setup();
    let commitment = vec![RingElement::zero(Representation::IncompleteNTT); rank];
    claim.value = RingElement::constant(1, Representation::IncompleteNTT);
    let outcome = verify_output(&key, &witness, &commitment, &claim, 1.0);
    assert!(outcome.is_err(), "a false full-length MLE evaluation was accepted");
    println!("PASS: incorrect MLE value rejected: {}", outcome.err().unwrap());
}
