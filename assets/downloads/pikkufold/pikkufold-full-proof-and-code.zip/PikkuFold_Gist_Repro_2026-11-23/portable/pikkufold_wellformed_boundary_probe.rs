//! Verifier-only, AVX-512-free differential checks for **well-shaped** input statements.
//! These are not cryptographic attacks. In particular, verify_fold is a RoK reduction,
//! not a standalone commitment-opening verifier.
use crate::config::{commitment_rank, FOLD_INPUTS, FRESH_INPUTS, PROJECTION_ROWS};
use crate::projection::projection_shape;
use crate::prover::FoldProof;
use crate::statement::{EvalClaim, Instance};
use crate::verifier::verify_fold;
use rokoko::common::init_common;
use rokoko::common::matrix::HorizontallyAlignedMatrix;
use rokoko::common::ring_arithmetic::{QuadraticExtension, Representation, RingElement};
use rokoko::common::sumcheck_element::SumcheckElement;

fn zero_fixture(log_m: usize) -> (usize, Instance, FoldProof) {
    let m = 1usize << log_m;
    let rank = commitment_rank(m);
    let zero = RingElement::zero(Representation::IncompleteNTT);
    let instance = Instance {
        commitment: HorizontallyAlignedMatrix {
            data: vec![zero.clone(); rank * FOLD_INPUTS],
            width: FOLD_INPUTS,
            height: rank,
        },
        claims: (0..FOLD_INPUTS)
            .map(|_| EvalClaim {
                point: vec![zero.clone(); log_m],
                value: zero.clone(),
            })
            .collect(),
    };
    let coarse = projection_shape(m).expect("valid projection shape");
    let input_vars = (FRESH_INPUTS * m).ilog2() as usize;
    let middle_vars = input_vars - coarse[0].ilog2() as usize;
    let output_vars = PROJECTION_ROWS.ilog2() as usize;
    let rounds = input_vars + middle_vars + output_vars;
    let proof = FoldProof {
        projection_trace: vec![zero.clone(); PROJECTION_ROWS / rokoko::common::config::DEGREE],
        batched_projection: vec![zero.clone(); crate::config::PROJECTION_BATCH_POINTS],
        round_polynomials: vec![[QuadraticExtension::zero(), QuadraticExtension::zero()]; rounds],
        terminal_values: vec![zero; FOLD_INPUTS],
    };
    (m, instance, proof)
}

fn test_log_m() -> usize {
    let log_m = std::env::var("PIKKU_ZERO_LOG_M")
        .ok().and_then(|v| v.parse().ok()).unwrap_or(10);
    assert!((10..=18).contains(&log_m));
    log_m
}

#[test]
fn rejects_false_evaluation_with_valid_shapes() {
    init_common();
    let (m, mut instance, proof) = zero_fixture(test_log_m());
    instance.claims[0].value = RingElement::constant(1, Representation::IncompleteNTT);
    assert_eq!(instance.claims.len(), FOLD_INPUTS);
    assert_eq!(instance.commitment.height, commitment_rank(m));
    assert_eq!(instance.commitment.data.len(), commitment_rank(m) * FOLD_INPUTS);
    match verify_fold(m, &instance, &proof) {
        Err(err) => println!("EXPECTED REJECTION for false complete evaluation claim: {err}"),
        Ok(_) => panic!("WARNING: zero-proof accepted a false evaluation with valid shapes"),
    }
}

#[test]
fn commitment_mismatch_requires_output_opening_check() {
    init_common();
    let (m, mut instance, proof) = zero_fixture(test_log_m());
    let zero = RingElement::zero(Representation::IncompleteNTT);
    // All dimensions and all three evaluation claims remain valid; only a
    // commitment entry is changed. verify_fold computes a new commitment, it
    // does not prove that the resulting commitment has a short opening.
    instance.commitment.data[0] = RingElement::constant(1, Representation::IncompleteNTT);
    let result = verify_fold(m, &instance, &proof)
        .expect("verify_fold should only produce the folded output statement");
    assert_eq!(result.folded_commitment.len(), commitment_rank(m));
    assert_ne!(result.folded_commitment[0], zero);
    assert_eq!(result.folded_claim.value, zero);
    println!("EXPECTED: verify_fold returned nonzero folded commitment; a zero output witness is NOT valid. Must call verify_output / check the target relation.");
}
