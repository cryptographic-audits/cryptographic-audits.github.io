//! Verifier-only zero transcript smoke test.
//! This is NOT an attack proof and does not call the AVX-512 prover.
use crate::config::{commitment_rank, FOLD_INPUTS, FRESH_INPUTS, PROJECTION_ROWS};
use crate::projection::projection_shape;
use crate::prover::FoldProof;
use crate::statement::{EvalClaim, Instance};
use crate::verifier::verify_fold;
use rokoko::common::init_common;
use rokoko::common::matrix::HorizontallyAlignedMatrix;
use rokoko::common::ring_arithmetic::{QuadraticExtension, Representation, RingElement};
use rokoko::common::sumcheck_element::SumcheckElement;

#[test]
fn zero_transcript_verifier_only_without_native_prover() {
    init_common();
    let log_m = std::env::var("PIKKU_ZERO_LOG_M")
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .unwrap_or(10);
    assert!((10..=18).contains(&log_m));
    let m = 1usize << log_m;
    let rank = commitment_rank(m);
    let zero = RingElement::zero(Representation::IncompleteNTT);
    let instance = Instance {
        commitment: HorizontallyAlignedMatrix {
            data: vec![zero.clone(); rank * FOLD_INPUTS],
            width: FOLD_INPUTS,
            height: rank,
        },
        claims: (0..FOLD_INPUTS)
            .map(|_| EvalClaim {
                point: vec![zero.clone(); log_m],
                value: zero.clone(),
            })
            .collect(),
    };

    let coarse = projection_shape(m).expect("projection shape");
    let input_vars = (FRESH_INPUTS * m).ilog2() as usize;
    let middle_vars = input_vars - coarse[0].ilog2() as usize;
    let output_vars = PROJECTION_ROWS.ilog2() as usize;
    let rounds = input_vars + middle_vars + output_vars;
    if log_m == 18 {
        assert_eq!(rounds, 40);
    }
    let proof = FoldProof {
        projection_trace: vec![zero.clone(); PROJECTION_ROWS / rokoko::common::config::DEGREE],
        batched_projection: vec![zero.clone(); crate::config::PROJECTION_BATCH_POINTS],
        round_polynomials: (0..rounds)
            .map(|_| [QuadraticExtension::zero(), QuadraticExtension::zero()])
            .collect(),
        terminal_values: vec![zero.clone(); FOLD_INPUTS],
    };

    let accepted = verify_fold(m, &instance, &proof).expect("zero transcript must verify");
    assert_eq!(accepted.folded_commitment.len(), rank);
    assert!(accepted.folded_commitment.iter().all(|value| value == &zero));
    assert_eq!(accepted.folded_claim.value, zero);
    assert_eq!(accepted.folded_claim.point.len(), log_m);
    println!("verifier-only OK: m=2^{log_m}, sumcheck rounds={rounds}, rank={rank}");
}
