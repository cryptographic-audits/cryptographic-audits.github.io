#!/usr/bin/env bash
set -euo pipefail
: "${1:?Usage: bash install_pikkufold_verifier_smoke.sh /path/to/pikku-fold-schemelet /path/to/pikkufold_zero_verifier_smoke.rs}"
: "${2:?Provide the Rust source file as second argument}"
project="$(realpath "$1")"
source="$(realpath "$2")"
if [[ ! -f "$project/src/main.rs" || ! -f "$project/Cargo.toml" ]]; then
  echo 'ERROR: first argument must be the pikku-fold-schemelet root' >&2
  exit 1
fi
if [[ -e "$project/src/zero_verifier_smoke.rs" ]] || grep -q 'mod zero_verifier_smoke;' "$project/src/main.rs"; then
  echo 'ERROR: smoke test already installed; refusing to overwrite' >&2
  exit 1
fi
cp "$project/src/main.rs" "$project/src/main.rs.before_zero_smoke"
cp "$source" "$project/src/zero_verifier_smoke.rs"
printf '\n#[cfg(test)]\nmod zero_verifier_smoke;\n' >> "$project/src/main.rs"
echo "Installed zero-transcript verifier-only smoke test into $project"
echo 'To uninstall: mv src/main.rs.before_zero_smoke src/main.rs && rm src/zero_verifier_smoke.rs'
