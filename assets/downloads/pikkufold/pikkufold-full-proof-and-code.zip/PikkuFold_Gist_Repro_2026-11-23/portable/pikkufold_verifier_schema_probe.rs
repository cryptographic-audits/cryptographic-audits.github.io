//! Test-only probe for PikkuFold verifier input-shape validation.
//! This does not modify the verifier, generate a cryptographic forgery,
//! call the native AVX-512 prover, or test the output commitment opening.
use crate::config::{commitment_rank, FOLD_INPUTS, FRESH_INPUTS, PROJECTION_ROWS};
use crate::projection::projection_shape;
use crate::prover::FoldProof;
use crate::statement::{EvalClaim, Instance};
use crate::verifier::verify_fold;
use rokoko::common::init_common;
use rokoko::common::matrix::HorizontallyAlignedMatrix;
use rokoko::common::ring_arithmetic::{QuadraticExtension, Representation, RingElement};
use rokoko::common::sumcheck_element::SumcheckElement;

fn zero_fixture(log_m: usize) -> (usize, Instance, FoldProof) {
    let m = 1usize << log_m;
    let rank = commitment_rank(m);
    let z = RingElement::zero(Representation::IncompleteNTT);
    let instance = Instance {
        commitment: HorizontallyAlignedMatrix {
            data: vec![z.clone(); rank * FOLD_INPUTS],
            width: FOLD_INPUTS,
            height: rank,
        },
        claims: (0..FOLD_INPUTS)
            .map(|_| EvalClaim {point: vec![z.clone(); log_m], value: z.clone()})
            .collect(),
    };
    let coarse = projection_shape(m).expect("projection shape");
    let input_vars = (FRESH_INPUTS * m).ilog2() as usize;
    let middle_vars = input_vars - coarse[0].ilog2() as usize;
    let output_vars = PROJECTION_ROWS.ilog2() as usize;
    let rounds = input_vars + middle_vars + output_vars;
    let proof = FoldProof {
        projection_trace: vec![z.clone(); PROJECTION_ROWS / rokoko::common::config::DEGREE],
        batched_projection: vec![z.clone(); crate::config::PROJECTION_BATCH_POINTS],
        round_polynomials: vec![[QuadraticExtension::zero(), QuadraticExtension::zero()]; rounds],
        terminal_values: vec![z; FOLD_INPUTS],
    };
    (m, instance, proof)
}

#[test]
fn rejects_shortened_sumcheck_transcript() {
    init_common();
    let (m, instance, mut proof) = zero_fixture(10);
    proof.round_polynomials.pop();
    let err = match verify_fold(m, &instance, &proof) {
        Ok(_) => panic!("truncated sumcheck was accepted"),
        Err(e) => e,
    };
    println!("EXPECTED REJECTION (round count): {err}");
}

#[test]
fn rejects_wrong_terminal_length() {
    init_common();
    let (m, instance, mut proof) = zero_fixture(10);
    proof.terminal_values.pop();
    let err = match verify_fold(m, &instance, &proof) {
        Ok(_) => panic!("truncated terminal values were accepted"),
        Err(e) => e,
    };
    println!("EXPECTED REJECTION (terminal length): {err}");
}

#[test]
fn probe_missing_input_claims() {
    init_common();
    let (m, mut instance, proof) = zero_fixture(10);
    instance.claims.clear();
    match verify_fold(m, &instance, &proof) {
        Ok(msg) => println!(
            "ACCEPTED MALFORMED INPUT: 0 claims instead of {}, returned {} commitment rows; not a valid-relation attack",
            FOLD_INPUTS, msg.folded_commitment.len()
        ),
        Err(e) => println!("REJECTED MALFORMED INPUT: {e}"),
    }
}

#[test]
fn probe_zero_height_commitment() {
    init_common();
    let (m, mut instance, proof) = zero_fixture(10);
    instance.commitment = HorizontallyAlignedMatrix {
        data: vec![], width: FOLD_INPUTS, height: 0,
    };
    match verify_fold(m, &instance, &proof) {
        Ok(msg) => println!(
            "ACCEPTED MALFORMED INPUT: rank=0 instead of {}, returned {} commitment rows; not a valid-relation attack",
            commitment_rank(m), msg.folded_commitment.len()
        ),
        Err(e) => println!("REJECTED MALFORMED INPUT: {e}"),
    }
}
