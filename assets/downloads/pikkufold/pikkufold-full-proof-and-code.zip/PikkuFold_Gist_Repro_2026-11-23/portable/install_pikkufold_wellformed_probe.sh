#!/usr/bin/env bash
set -euo pipefail
DIR="${1:-$HOME/pikkufold-lab/original/pikku-main/pikku-fold-schemelet}"
FILE="${2:-$HOME/pikkufold-lab/pikkufold_wellformed_boundary_probe.rs}"
test -f "$DIR/src/main.rs" || { echo "Missing project at $DIR" >&2; exit 1; }
test -f "$FILE" || { echo "Missing Rust module at $FILE" >&2; exit 1; }
cp "$FILE" "$DIR/src/wellformed_boundary_probe.rs"
if ! grep -Eq '^mod wellformed_boundary_probe;' "$DIR/src/main.rs"; then
  printf '\n#[cfg(test)]\nmod wellformed_boundary_probe;\n' >> "$DIR/src/main.rs"
fi
printf 'Installed independent well-shaped regression tests. No verifier logic modified.\n'
