#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
( cd "$ROOT/round9" && bash verify_all.sh )
python3 "$ROOT/round12/verify_round12_static.py"
echo 'PASS: finite challenge set, CRT, sampled JL kernel, algebra controls and challenge support checked'
